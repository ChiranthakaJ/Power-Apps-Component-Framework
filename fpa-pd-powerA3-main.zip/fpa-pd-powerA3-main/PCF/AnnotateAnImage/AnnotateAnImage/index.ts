import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { AnnotationEditor } from "@markerjs/markerjs-ui"
import * as React from "react";
import * as ReactDOM from "react-dom/client";

export class AnnotateAnImage implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    /**
     * Empty constructor.
     */
    private container: HTMLDivElement;
    private parentcontainer: HTMLDivElement;
    private context: ComponentFramework.Context<IInputs>;
    private notifyOutputChanged: () => void;
    private image: HTMLImageElement;
    private pasteimage: HTMLImageElement;
    private rasterizedImage: string;
    private editorState: string;
    private eventType: string;
    private currentImageData: string;
    private pastedImageData: string;
    private lastResetValue: boolean | undefined;
    private allowPaste: boolean | undefined;
    constructor() {
        // Empty
    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Add control initialization code
        this.context = context;
        this.parentcontainer = container
        this.lastResetValue = context.parameters.ResetSignal.raw;
        this.allowPaste = context.parameters.AllowPaste.raw;
        this._updateImage(container, context)
        this.notifyOutputChanged = notifyOutputChanged;


    }

    private _updateImage(container: HTMLDivElement, context: ComponentFramework.Context<IInputs>){
        const existing = this.currentImageData
        const restoredstate = context.parameters.RestoredState.raw || "";
        //console.log("Existing is " + existing)
        //console.log("Restored State is " + restoredstate)
        let maState = null;
        if (restoredstate  && restoredstate !== "val") {
            try{
                maState = JSON.parse(restoredstate);
            } catch {
                console.log("Failed to parse restored state");
            }
        }
        //console.log("Allow Paste: " + this.allowPaste);
        if ((existing && existing !== "val") || this.allowPaste == false){
            //let imgtext = existing;
            //if (existing.startsWith('"')){
            //    imgtext = existing.replace('"', '').replace('"', '');
            //}
            const editor = new AnnotationEditor();
            this.container = document.createElement("div");
            this.container.style.display = "flex";
            this.container.style.flexDirection = "column";
            this.container.style.alignItems = "center";
            this.image = document.createElement("img");
            this.image.crossOrigin = "anonymous";
            this.image.src = existing;
            this.image.style.cursor = "crosshair";
            this.image.style.maxWidth = "100%";
            editor.targetImage = this.image;  
            
            editor.addEventListener("editorsave", (event) => {
                const dataUrl = event.detail.dataUrl;
                if (dataUrl) {
                    this.rasterizedImage = dataUrl;
                    this.editorState = JSON.stringify(event.detail.state);
                    this.eventType = "Save"
                } else {
                    this.eventType = "Failed"
                }
                this.notifyOutputChanged();
            });
            
            editor.addEventListener("editorclose", (event) => {
                this.eventType = "Close"
                this.notifyOutputChanged();
            });

            if (maState) {
                editor.restoreState(maState);
            }

            container.innerHTML = "";
            container.appendChild(editor);
            container.appendChild(this.container);
        } else {
            if (this.allowPaste){
                this.container = document.createElement("div");
                this.container.innerText = "Click here and Paste an image (Ctrl + V)";
                this.container.style.display = "flex";
                this.container.style.flexDirection = "column";
                this.container.style.alignItems = "center";
                this.container.style.height = "auto";
                this.container.style.minHeight = "300px";
                this.container.style.backgroundColor = "#EDEDED";
                this.container.style.padding = "20px"
                this.container.tabIndex = 0
                this.container.style.display = "flex";

                //const lblPaste = document.createElement("label");
                //lblPaste.textContent = "Paste an image (Ctrl + V)";
                //lblPaste.id = "pasteLabel";
                

                this.pasteimage = document.createElement("img");
                this.pasteimage.crossOrigin = "anonymous";
                this.pasteimage.style.cursor = "crosshair";
                this.pasteimage.style.maxWidth = "100%";

                this.container.addEventListener("paste", async (e) => {
                    const items = e.clipboardData?.items;
                    if (items){
                        for (let i = 0; i < items.length; i++) {
                            if (items[i].type.indexOf("image") !== -1) {
                                const blob = items[i].getAsFile();
                                if (blob){
                                    const reader = new FileReader();
                                    reader.onload = (event) => {
                                        if (event.target){
                                            const pastedImageDataUrl = event.target?.result as string;
                                            if(pastedImageDataUrl){
                                                this.pasteimage.src = pastedImageDataUrl;
                                                const btnContainer = document.getElementById("btnContainer") as HTMLDivElement | null;
                                                if (btnContainer){
                                                    btnContainer.style.display = "flex";
                                                }
                                                //this.container.innerText = ""
                                                //const lbl = document.getElementById("pasteLabel") as HTMLLabelElement | null;
                                                //if (lbl){
                                                //    lbl.style.display = "none";
                                                //}


                                            }
                                        }
                                    };
                                    reader.readAsDataURL(blob);
                                }
                                e.preventDefault(); // prevent text paste
                                break;

                            }

                        }
                    }
                });

                const btnContainer = document.createElement("div");
                btnContainer.id = "btnContainer";
                btnContainer.style.display = "none";
                btnContainer.style.gap = "10px"; // spacing between buttons
                btnContainer.style.margin = "10px";

                const editBtn = document.createElement("button");
                editBtn.id = "editbtn";
                editBtn.textContent = "Annotate";
                editBtn.style.marginTop = "10px";
                editBtn.style.padding = "6px 12px";
                editBtn.style.backgroundColor = "#0078d4";
                editBtn.style.color = "#fff";
                editBtn.style.border = "none";
                editBtn.style.cursor = "pointer";

                const cancelBtn = document.createElement("button");
                cancelBtn.id = "cancelbtn";
                cancelBtn.textContent = "Cancel";
                cancelBtn.style.marginTop = "10px";
                cancelBtn.style.padding = "6px 12px";
                cancelBtn.style.backgroundColor = "#0078d4";
                cancelBtn.style.color = "#fff";
                cancelBtn.style.border = "none";
                cancelBtn.style.cursor = "pointer";

                editBtn.addEventListener("click", async () => {
                    if (!this.pasteimage.src) return;
                    this.currentImageData = this.pasteimage.src;
                    this.rasterizedImage = "";
                    this.pastedImageData = this.currentImageData;
                    this.notifyOutputChanged();
                    this._updateImage(container, context);
                });

                cancelBtn.addEventListener("click", async () => {
                    this.pasteimage.src = ""
                    this.currentImageData = "";
                    this.rasterizedImage = "";
                    this._updateImage(container, context);
                });


                container.innerHTML = "";
            
                btnContainer.appendChild(editBtn);
                btnContainer.appendChild(cancelBtn);
                //this.container.appendChild(lblPaste);
                this.container.appendChild(btnContainer);
                this.container.appendChild(this.pasteimage);
                //this.container.append(dropArea);
                container.appendChild(this.container);
                console.log("1.0.1")
            }
        }
    }
    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Add code to update control view
        this.context = context;
        const newurl = context.parameters.AnnotatedImage.raw || "";
        const resetNow = context.parameters.ResetSignal.raw;
        const allowPasteNow = context.parameters.AllowPaste.raw;
        if (newurl && newurl !== this.currentImageData || (resetNow !== this.lastResetValue) || (allowPasteNow !== this.allowPaste) ) {
            this.currentImageData = newurl;
            this.allowPaste = allowPasteNow;
            this._updateImage(this.parentcontainer, context);
        }
        this.lastResetValue = resetNow;
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        console.log("Outputs");
        return {
            AnnotatedImage: this.currentImageData || "",
            RasterizedImage: this.rasterizedImage || "",
            EditorState: this.editorState || "", 
            EventType: this.eventType || "",
            PastedImage: this.pastedImageData || ""
        };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        // Add code to cleanup control if necessary
    }
}

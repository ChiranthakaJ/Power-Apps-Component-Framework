// LinkDialog.tsx
import * as React from "react";
import {
    Dialog,
    DialogType,
    DialogFooter,
    PrimaryButton,
    DefaultButton,
    TextField,
    Dropdown,
    IDropdownOption,
    Stack
} from "@fluentui/react";



export interface AIDialogProps {
  open: boolean;
  defaultText?: string;
  defaultAI?: string;
  onCancel: () => void;
  onSave: (text: string, url: string) => void;
  aioptions: string; 
  aiurl:string, 
  aikey: string, 
  aimodel: string,
  setIsLoading: (show:boolean) => void;
}

export const AIDialog: React.FC<AIDialogProps> = ({
  open,
  defaultText = "",
  defaultAI = "",
  onCancel,
  onSave, 
  aioptions, 
  aiurl, 
  aikey, 
  aimodel, 
  setIsLoading
}) => {
    const [text, setText] = React.useState(defaultText);
    const [ai, setAI] = React.useState(defaultAI);
    const [selected, setSelected] = React.useState("");
    const [loading, setLoading] = React.useState(false);
    const [ailist, setAIList] = React.useState(false);
    const options = aioptions.split(",").map(o => o.trim());
    const dropdownOptions: IDropdownOption[] = options.map((o) => ({
    key: o,
    text: o
  }));
    const callExternalAPI = async (value: string) => {
        console.log("External API")
        setIsLoading(true);
        setLoading(true);
        try {
            const response = await fetch(aiurl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + aikey
                },
                body: JSON.stringify({
                    model: aimodel,
                    messages: [
                        {
                        role: "user",
                        content: selected + " " + value
                        }
                    ]
                })
            });

            const data = await response.json()
            if (data){
                setAI(data.choices[0].message.content);
            }

        } catch (error) {
            console.error("API Error:", error);
        } finally {
            setIsLoading(false);
            setLoading(false);
        }
  };

  React.useEffect(() => {
    setText(defaultText);
    setAI(defaultAI);
    if (aioptions){
        if (options.length > 0){
            setAIList(true);
            setSelected(options[0])
        }
    }

  }, [defaultText, defaultAI, open]);

  return (
     <Dialog
      hidden={!open || loading}
      onDismiss={onCancel}
      dialogContentProps={{
        type: DialogType.normal,
        title: "AI Assistant"
      }}
      modalProps={{ isBlocking: true }}
      minWidth={700}
    >
      <Stack tokens={{ childrenGap: 12 }}>
        <TextField
          label="Current Text"
          multiline
          rows={12}
          value={text}
          onChange={(_, newValue) => setText(newValue || "")}
        />

        <Stack horizontal tokens={{ childrenGap: 12 }} verticalAlign="end">
          <Dropdown
            placeholder="Select a category"
            selectedKey={selected}
            options={dropdownOptions}
            onChange={(_, option) =>
              setSelected(option?.key as string)
            }
            styles={{ root: { width: 250 } }}
          />

          <PrimaryButton
            text="Call AI"
            onClick={() => callExternalAPI(text)}
            disabled={!text}
          />
        </Stack>

        <TextField
          label="Returned Text"
          multiline
          rows={12}
          value={ai}
          onChange={(_, newValue) => setAI(newValue || "")}
        />
      </Stack>

      <DialogFooter>
        <DefaultButton onClick={onCancel} text="Cancel" />
        <PrimaryButton
          onClick={() => onSave(text, ai)}
          text="Insert"
          disabled={!ai || !text}
        />
      </DialogFooter>
    </Dialog>

  );
};

import React, { forwardRef, useImperativeHandle, useRef, useEffect, useState, useMemo } from "react";
import Quill from "quill/core";

type Delta = { ops?: Array<{ insert?: unknown; delete?: number; retain?: unknown; attributes?: Record<string, unknown> }> };
type QuillRange = { index: number; length: number };
import TableUp, { defaultCustomSelect, TableAlign, TableResizeLine, TableMenuContextmenu, TableResizeBox, TableResizeScale, TableSelection, TableVirtualScrollbar, tableMenuTools } from 'quill-table-up';
import { faHandSpock} from '@fortawesome/free-regular-svg-icons';
import QuillImageResizer from '@mouseoverllc/quill-image-resizer';
import QuillImageDropAndPaste from 'quill-image-drop-and-paste';
import 'quill/dist/quill.snow.css';
import 'quill-table-up/index.css';
import 'quill-table-up/table-creator.css';
import '@mouseoverllc/quill-image-resizer/dist/style.css';
import BlotFormatter2 from '@enzedonline/quill-blot-formatter2';
import '@enzedonline/quill-blot-formatter2/dist/css/quill-blot-formatter2.css';

import { LinkDialog } from "./LinkDialog";
import { LucidDialog } from "./LucidDialog";
import { AIDialog } from "./AIDialog";
export type CardEditorHandle = {
  reset: (html: string) => void;
};
Quill.register('modules/blotFormatter2', BlotFormatter2);
delete Quill.imports["formats/size"]; // remove cached default
const Size = Quill.import('attributors/style/size') as any;
const icons = Quill.import("ui/icons") as any;
icons["a3mode"] = `
<svg fill="#000000" width="16px" height="16px" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg"><path d="M1,6 L3,6 C3.55228475,6 4,6.44771525 4,7 C4,7.55228475 3.55228475,8 3,8 L1,8 C0.44771525,8 0,7.55228475 0,7 C0,6.44771525 0.44771525,6 1,6 Z M11,6 L13,6 C13.5522847,6 14,6.44771525 14,7 C14,7.55228475 13.5522847,8 13,8 L11,8 C10.4477153,8 10,7.55228475 10,7 C10,6.44771525 10.4477153,6 11,6 Z M6,6 L8,6 C8.55228475,6 9,6.44771525 9,7 C9,7.55228475 8.55228475,8 8,8 L6,8 C5.44771525,8 5,7.55228475 5,7 C5,6.44771525 5.44771525,6 6,6 Z M0,1 C0,0.44771525 0.44771525,-2.26485497e-13 1,-2.26485497e-13 C1.55228475,-2.26485497e-13 2,0.44771525 2,1 L2,3.0142458 L12,3.0142458 L12,1 C12,0.44771525 12.4477153,-2.26485497e-13 13,-2.26485497e-13 C13.5522847,-2.26485497e-13 14,0.44771525 14,1 L14,3.0142458 C14,4.1188153 13.1045695,5.0142458 12,5.0142458 L2,5.0142458 C0.8954305,5.0142458 0,4.1188153 0,3.0142458 L0,1 Z M0,13.0142458 L0,11 C0,9.8954305 0.8954305,9 2,9 L12,9 C13.1045695,9 14,9.8954305 14,11 L14,13.0142458 C14,13.5665305 13.5522847,14.0142458 13,14.0142458 C12.4477153,14.0142458 12,13.5665305 12,13.0142458 L12,11 L2,11 L2,13.0142458 C2,13.5665305 1.55228475,14.0142458 1,14.0142458 C0.44771525,14.0142458 0,13.5665305 0,13.0142458 Z"/></svg>
`;
icons["lucid"] = `
<svg width="16px" height="16px" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path fill="#000000" d="M128 896V128h768v768H128zm291.712-327.296 128 102.4 180.16-201.792-47.744-42.624-139.84 156.608-128-102.4-180.16 201.792 47.744 42.624 139.84-156.608zM816 352a48 48 0 1 0-96 0 48 48 0 0 0 96 0z"/></svg>`;
icons["ai"] = `
<svg width="16px" height="16px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 490 490" style="enable-background:new 0 0 490 490;" xml:space="preserve">
<g>
	<g>
		<path d="M416,0H74C33.3,0,0,33.4,0,74v342c0,40.7,33.4,74,74,74h342c40.7,0,74-33.4,74-74V74C490,33.4,456.6,0,416,0z M449.3,416
			c0,18.8-14.6,33.4-33.4,33.4H74c-18.8,0-33.4-14.6-33.4-33.4V74c0-18.8,14.6-33.4,33.4-33.4h342c18.8,0,33.4,14.6,33.4,33.4v342
			H449.3z"/>
		<g>
			<path d="M234.8,169.8c-2.4-5.5-7.8-9-13.8-9s-11.4,3.5-13.8,9L147,308.3c-3.3,7.6,0.2,16.4,7.8,19.7c2,0.9,4,1.3,6,1.3
				c5.8,0,11.3-3.4,13.8-9l13.2-30.2h66.9l13.2,30.2c3.3,7.6,12.1,11.1,19.7,7.8c7.6-3.3,11.1-12.2,7.8-19.7L234.8,169.8z
				 M200.7,260l20.4-46.8l20.4,46.8H200.7z"/>
			<path d="M329.3,217.9c-8.3,0-15,6.7-15,15v81.4c0,8.3,6.7,15,15,15s15-6.7,15-15v-81.4C344.3,224.6,337.6,217.9,329.3,217.9z"/>
			<path d="M329.3,166.4c-8.3,0-15,6.7-15,15v4c0,8.3,6.7,15,15,15s15-6.7,15-15v-4C344.3,173.1,337.6,166.4,329.3,166.4z"/>
		</g>
	</g>
</g>
</svg>`;
const customFontSizes = ['8px', '10px', '12px', '14px', '16px', '18px', '24px', '32px'];
Size.whitelist = customFontSizes;
Quill.register(Size, true);

const Font = Quill.import('formats/font') as any;
Font.whitelist = [
    'sans-serif',
    'serif',
    'monospace',
    'arial',
    'times-new-roman',
    'comic-sans'
];
Quill.register(Font, true);
Quill.register('modules/imageDropAndPaste', QuillImageDropAndPaste);
Quill.register({ [`modules/${TableUp.moduleName}`]: TableUp }, true);

if (!Quill.imports["modules/imageResizer"]) {
  Quill.register("modules/imageResizer", QuillImageResizer);
}

const BlockEmbed = Quill.import("blots/block/embed") as any;

class Base64Video extends BlockEmbed {
  static blotName = "video";
  static tagName = "video";

  static create(value: string) {
    const node = super.create(value) as HTMLVideoElement;
    node.setAttribute("controls", "true");
    node.setAttribute("src", value);
    node.style.maxWidth = "100%";
    node.style.height = "auto";
    return node;
  }

  static value(node: HTMLVideoElement) {
    return node.getAttribute("src")!;
  }
}
Quill.register(Base64Video, true);

class IframeBlotLucid extends BlockEmbed {
  static blotName = "lucid";
  static tagName = "div";
  static className = "lucid-container";

  static create(value: { html: string }) {
    const node = super.create() as HTMLDivElement;
    // Inject HTML content
    const wrapper = document.createElement('div');
    wrapper.innerHTML = value.html;

    // Find the <div> and <iframe>
    const divNode = wrapper.querySelector<HTMLDivElement>('div');
    const iframeNode = wrapper.querySelector<HTMLIFrameElement>('iframe');
    if (divNode) {
      divNode.style.width = '100%';
      //divNode.style.height = 'auto';
      divNode.style.margin = '0px';
      //divNode.style.minHeight = '480px'
    }
    if (iframeNode) {
      iframeNode.style.width = '100%';
      //iframeNode.style.height = 'auto';
      //iframeNode.style.minHeight = '480px'
    }
    const updatedHTML = wrapper.innerHTML;
    node.innerHTML = updatedHTML;

    return node;
  }

  static value(node: HTMLDivElement) {
    return {
      html: node.innerHTML
    };
  }
}
Quill.register(IframeBlotLucid);

class AIBlot extends BlockEmbed {
  static blotName = "ai";
  static tagName = "div";
  static className = "lucid-container";

  static create(value: { text: string, ai: string }) {
    const node = super.create() as HTMLDivElement;
    // Inject HTML content
    node.innerHTML = value.ai;

    return node;
  }

  static value(node: HTMLDivElement) {
    return {
      html: node.innerHTML
    };
  }
}
Quill.register(AIBlot);

class CenteredImage extends BlockEmbed {
  static create(value: any) {
    const node = super.create();
    const img = document.createElement('img');
    img.setAttribute('src', value.src);
    img.style.width = value.width ?? '100%';
    img.style.height = 'auto';
    node.style.textAlign = 'center';
    node.appendChild(img);
    return node;
  }

  static value(node: HTMLElement) {
    const img = node.querySelector('img');
    return { src: img?.getAttribute('src'), width: img?.style.width };
  }
}

CenteredImage.blotName = 'centeredImage';
CenteredImage.tagName = 'div';

Quill.register(CenteredImage);

class A3Blot extends BlockEmbed {
  static blotName = "a3mode";
  static tagName = "div";
  static className = "a3breaker";

  static create() {
    const node = super.create() as HTMLDivElement;
    node.style.border = "none";
    node.style.border = "3px solid #ffffff";
    node.style.backgroundColor = "#c0dbf0"
    node.style.margin = "0px";
    node.style.height = "30px";
    node.style.borderRadius = "10px"
    node.style.color = "black"
    node.innerHTML = "A3 Break Point (any content after here is ignored in A3 Mode)"
    node.style.textAlign = "center"
    //node.innerHTML = "<hr clas />"
    
    node.style.maxWidth = "100%";
    node.style.height = "auto";

    return node;
  }

  static value(node: HTMLDivElement) {
    return {
      html: node.innerHTML
    };
  }
}
Quill.register(A3Blot);

type CardEditorProps = {
  item: CardItem;
  onChange: (id: number, field: string, value: string) => void;
  readonly: boolean;
  settings: CardSettings;
};
const formats = [
    "bold", "italic", "underline", "strike", "color", "background", "align", "list", "bullet", "link", "image"
];

const CardEditor: React.FC<CardEditorProps> = ({item, onChange, readonly, settings}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const quillRef = useRef<Quill>();
  const [content, setContent] = useState(item.Explanation);
  const savedRangeRef = useRef<any>(null);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [showLucidDialog, setShowLucidDialog] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [defaultText, setDefaultText] = useState("");
  const [defaultUrl, setDefaultUrl] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [menuPos, setMenuPos] = useState({ x: 0, y: 0 });
  const [menuVisible, setMenuVisible] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);


  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuVisible(false);
      }
    };

    if (menuVisible) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuVisible]);



  const isDirtyRef = useRef(false);
  const headingLevels: (number | false)[] = [1, 2, 3, 4, false];
  const toolbar: any[] = [];
  toolbar.push([{ header: headingLevels }]);

  if (settings.showfont) toolbar.push([{ font: Font.whitelist }]);
  if (settings.showsize) toolbar.push([{ size: Size.whitelist }]);
  const inline: string[] = [];
  if (settings.showbold) inline.push("bold");
  if (settings.showitalic) inline.push("italic");
  if (settings.showunderline) inline.push("underline");
  if (inline.length) toolbar.push(inline);
  if (settings.showcolor) toolbar.push([{ color: [] }, { background: [] }]);
  const block: string[] = [];
  if (settings.showlink) block.push("link");
  if (settings.showblockquote) block.push("blockquote");
  if (settings.showcodeblock) block.push("code-block");
  if (settings.showimage) block.push("image");
  if (settings.showvideo) block.push("video");
  if (settings.showlucid) block.push("lucid");
  if (block.length) toolbar.push(block);
  if (settings.showalign) toolbar.push([{ align: [] }]);
  const lists: any[] = [];
  if (settings.showorderedlist) lists.push({ list: "ordered" });
  if (settings.showbulletlist) lists.push({ list: "bullet" });
  if (settings.showindent) lists.push({ indent: "-1" }, { indent: "+1" });
  if (lists.length) toolbar.push(lists);
  if (settings.showclean) toolbar.push(["clean"]);
  if (settings.showundo) toolbar.push(['undo', 'redo']);
  if (settings.showtable) toolbar.push([{ [TableUp.toolName]: [] }]);
  if (settings.showa3mode) toolbar.push(["a3mode"]);
  if (settings.showai) toolbar.push(["ai"]);

  const handleToolbarEnable = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.enable();
    setShowLinkDialog(false);
  };

  const handleToolbarEnableLucid = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.enable();
    setShowLucidDialog(false);
  };

  const handleToolbarEnableAI = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.enable();
    setShowAIDialog(false);
  };

  const handleToolbarDisable = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.disable();
    setShowLinkDialog(true);
  };

  const handleToolbarDisableLucid = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.disable();
    setShowLucidDialog(true);
  };

  const handleToolbarDisableAI = () => {
    const quill = quillRef.current;
    if (!quill) return;
    quill.disable();
    setShowAIDialog(true);
  };

  const handleInsertLink = () => {
    const quill = quillRef.current;
    if (!quill) return;
    const range = quill.getSelection();
    if (!range) return;
    savedRangeRef.current = range;
    const selectedText = quill.getText(range.index, range.length);
    setDefaultText(selectedText || "");
    setDefaultUrl("");
    handleToolbarDisable()
  };

  const handleInsertLucid = () => {
    const quill = quillRef.current;
    if (!quill) return;
    const range = quill.getSelection();
    if (!range) return;
    savedRangeRef.current = range;
    setDefaultText("");
    handleToolbarDisableLucid()

  };

  const handleInsertAI = () => {
    const quill = quillRef.current;
    if (!quill) return;
    const range = quill.getSelection();
    if (!range) return;
    savedRangeRef.current = range;
    const selectedText = quill.getText(range.index, range.length);
    setDefaultText(selectedText || "");
    handleToolbarDisableAI();
  };

  const handleInsertA3Mode = () => {
    const quill = quillRef.current;
    if (!quill) return;
    const text = quill.root.innerHTML;
    try{
      const breaker = '<div class="a3breaker"';
      const index = text.indexOf(breaker);
      if (index !== -1) {
        return;
      }
    } catch {
      console.log("Error")
    }

    const range = quill.getSelection();
    if (!range) return;
    quill.insertEmbed(range.index, "a3mode", true, "user");
    quill.setSelection(range.index + 1);
  };


  const insertLink = (text: string, url: string) => {
    const quill = quillRef.current;
    if (!quill || !savedRangeRef.current) return;
    const range = savedRangeRef.current;
    quill.focus(); // restore focus
    quill.setSelection(range.index, range.length);
    quill.deleteText(range.index, range.length);
    quill.insertText(range.index, text, "link", url);
    quill.setSelection(range.index + text.length);
    const updatedhtml = quill.root.innerHTML
    //console.log("Insert Link");
    onChange(item.ID, "Explanation", updatedhtml);
    handleToolbarEnable()
  };

  const insertLucid = (html: string) => {
    const quill = quillRef.current;
    if (!quill || !savedRangeRef.current) return;
    const range = savedRangeRef.current;
    quill.focus(); // restore focus
    quill.insertEmbed(range.index, "lucid", {
      html: html
    });
    quill.setSelection(range.index + 1);
    const updatedhtml = quill.root.innerHTML;
    //console.log("Insert Lucid");
    onChange(item.ID, "Explanation", updatedhtml);
    //setIsUploading(false);
    handleToolbarEnableLucid()
  };

  const insertAI = (text: string, ai: string) => {
      const quill = quillRef.current;
      if (!quill || !savedRangeRef.current) return;
      const range = savedRangeRef.current;
      quill.focus(); // restore focus
      quill.setSelection(range.index, range.length);
      quill.deleteText(range.index, range.length);
      quill.insertEmbed(range.index, "ai", {
        text: text, ai: ai
      });
      quill.setSelection(range.index + 1);
      const updatedhtml = quill.root.innerHTML
      //console.log("Insert AI");
      onChange(item.ID, "Explanation", updatedhtml);
      handleToolbarEnableAI()
  };

  const handleImageUpload = () => {
    const input = document.createElement('input');  
    input.setAttribute('type', 'file');  
    input.setAttribute('accept', 'image/*');  
    input.click(); 
    
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      setIsUploading(true);
      requestIdleCallback(() => {
        processFileUpload(file);
      });
    };
  }

  const handleVideoUpload = () => {
    const input = document.createElement("input");
    input.setAttribute("type", "file");
    input.setAttribute("accept", "video/*");
    input.click();

    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      setIsUploading(true);

      requestIdleCallback(() => {
        processVideoUpload(file);
      });
    };
  };

  const processVideoUpload = async (file: File) => {
    //console.log("Video Upload Fired");
    if(!file) return;
    try {
      await new Promise((resolve) => setTimeout(resolve, 0));
      // Convert file to base64 if needed
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result!.toString().split(",")[1]);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Upload to SharePoint via Power Automate Flow
      const uniqueName = `${crypto.randomUUID()}_${file.name}`;
      const response = await fetch(settings.uploadurl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          FileName: uniqueName,
          FileContent: base64, 
          SectionID: item.ID.toString()
        })
      });
      if (!response.ok) throw new Error("Upload failed");
      const data = await response.json();
      const fileUrl = data.fileURL;
      // Insert into Quill
      const quill = quillRef.current;
      const range = quill?.getSelection(true);
      if (range && quill) {
        quill.insertEmbed(range.index, "video", fileUrl, "user");
        quill.setSelection(range.index + 1);
        const updatedHTML = quill.root.innerHTML;
        onChange(item.ID, "Explanation", updatedHTML);
      }
    } catch (err) {
      console.error(err);
      //alert("Upload failed. Check console.");
    } finally {
      setIsUploading(false); // hide loader
    }
  };

  const processFileUpload = async (file: File) => { 
    if(!file) return;
    try{ 
      await new Promise((resolve) => setTimeout(resolve, 0));
      //const reader = new FileReader(); 
      const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string); // data:image/png;base64,...
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const quill = quillRef.current; 
      const range = quill?.getSelection(true); 
      if (range && quill) {
        setTimeout(() => { 
              const leafTuple = quill?.getLeaf(range.index); 
              if (!leafTuple) return; 
              const [leaf] = leafTuple; 
              if (!leaf) return; 
              let domNode = leaf.domNode as Node; 
              if (domNode.nodeType !== 1) { 
                domNode = domNode.nextSibling!; 
              } 
              console.log(domNode);
              const imgNode = (domNode as HTMLElement).closest("img") as HTMLImageElement | undefined; 
              console.log("In Img Node" + imgNode)
              if (imgNode && imgNode.tagName === "IMG") { 
                if (imgNode.dataset.resized === "true") return; 
                const tdAncestor = imgNode.closest("td"); 
                if (!tdAncestor){ 
                  imgNode.setAttribute("width", settings.reduceimage ?? "50%"); 
                  imgNode.setAttribute("height", "auto");
                  imgNode.style.display = "block";
                  imgNode.style.margin = "0 auto";
                  imgNode.dataset.resized = "true"; 
                } else { 
                  imgNode.setAttribute("width", "100%"); 
                  imgNode.setAttribute("height", "auto"); 
                  imgNode.style.display = "block";
                  imgNode.style.margin = "0 auto";
                  imgNode.dataset.resized = "true"; 
                } 
              } 
            }, 0); 
        quill.insertEmbed(range.index, "image", base64, "user"); 
        //quill.insertEmbed(range.index, "centeredImage", {src: base64, width:settings.reduceimage ?? "50%"}); 
        quill.setSelection(range.index + 1);
        const updatedHTML = quill.root.innerHTML;
        onChange(item.ID, "Explanation", updatedHTML);
      }
    } catch (err) { 
      //console.error("Upload failed", err); 
      alert("Upload failed, try again"); 
    } 
    finally { 
      //console.log("finished loading");
      setIsUploading(false); // hide modal 
    } 
  };
  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;

    if (target.closest("td, th")) {
      return; // ❌ Don't show menu
    }
    e.preventDefault();
    setMenuPos({ x: e.clientX, y: (e.clientY - settings.mouseoveradjust!) });
    setMenuVisible(true);
  };

  const handleMenuClick = (action: string) => {
    const quill =  quillRef.current;
    if (!quill) return;
    if (action === 'undo')  quill.history.undo();
    if (action === 'redo')  quill.history.redo();
    if (action === 'copy')  {
      const range = quill.getSelection();
      if (!range) return;
      const selectedText = quill.getText(range.index, range.length);
      navigator.clipboard.writeText(selectedText);
    }
    setMenuVisible(false);
  };

  const modules = useMemo(() => ({
    toolbar: {
    container: toolbar,
    handlers: {
      undo: () => {
        const quill = quillRef.current;
        if (quill) {
          quill.history.undo();
        }
      },
      redo: () => {
        const quill = quillRef.current;
        if (quill) {
          quill.history.redo();
        }
      },
    },
  },
  blotFormatter2: {
      resize: {
        allowResizing: true,
        allowResizeModeChange: true, // show % toggle
        useRelativeSize: true        // default to % mode
      }
    },
  /*imageResizer: {
      keepAspectRatio: true
    },*/
    imageDropAndPaste: {
      // add an custom image handler
      //handler: imageHandler,
    },
    history: {
      delay: 1000,
      maxStack: 500,
      userOnly: true
    },
    table: true,
    [TableUp.moduleName]: {
            full: true,
            formats: formats,
            autoMergeCell: true,
            fullSwitch: true,
            customSelect: defaultCustomSelect,
            modules: [
              { module: TableVirtualScrollbar },
              { module: TableAlign },
              { module:TableResizeBox},
              { module: TableResizeLine },
              {
                module: TableResizeScale,
                options: {
                  blockSize: 12,
                },
              },
              {
                module: TableSelection,
                options: {
                  selectColor: '#00ff8b4d',
                },
              },
              {
                module: TableMenuContextmenu,
                  options: {
                    localstorageKey: 'used-color',
                    tipText: true,
                    tools: [
                      tableMenuTools.InsertCaption,
                      tableMenuTools.InsertTop,
                      tableMenuTools.InsertRight,
                      tableMenuTools.InsertBottom,
                      tableMenuTools.InsertLeft,
                      tableMenuTools.Break,
                      tableMenuTools.MergeCell,
                      tableMenuTools.SplitCell,
                      tableMenuTools.Break,
                      tableMenuTools.DeleteRow,
                      tableMenuTools.DeleteColumn,
                      tableMenuTools.DeleteTable,
                      tableMenuTools.Break,
                      tableMenuTools.BackgroundColor,
                      tableMenuTools.BorderColor,
                      tableMenuTools.Break,
                      tableMenuTools.CopyCell,
                      tableMenuTools.CutCell,
                      tableMenuTools.Break,
                      tableMenuTools.SwitchWidth,
                      tableMenuTools.Break,
                      tableMenuTools.ToggleTdBetweenTh,
                      tableMenuTools.ConvertTothead,
                      tableMenuTools.ConvertTotfoot
                    ],
                  defaultColorMap: [
                    [
                        'rgb(255, 255, 255)',
                        'rgb(0, 0, 0)',
                        'rgb(72, 83, 104)',
                        'rgb(41, 114, 244)',
                        'rgb(0, 163, 245)',
                        'rgb(49, 155, 98)',
                        'rgb(222, 60, 54)',
                        'rgb(248, 136, 37)',
                        'rgb(245, 196, 0)',
                        'rgb(153, 56, 215)',
                    ],
                    [
                      'rgb(242, 242, 242)',
                      'rgb(127, 127, 127)',
                      'rgb(243, 245, 247)',
                      'rgb(229, 239, 255)',
                      'rgb(229, 246, 255)',
                      'rgb(234, 250, 241)',
                      'rgb(254, 233, 232)',
                      'rgb(254, 243, 235)',
                      'rgb(254, 249, 227)',
                      'rgb(253, 235, 255)',
                    ],
                  ],
                },
              },
      ],
    }
  }), []);

  useEffect(() => {
    if (editorRef.current && !quillRef.current) {
      quillRef.current = new Quill(editorRef.current, {
        theme: "snow",
        bounds: '#quill-container',
        modules: modules
      });
      const toolbarpi = (quillRef.current as any).getModule('toolbar');
      toolbarpi.addHandler('link', handleInsertLink);
      toolbarpi.addHandler('video', handleVideoUpload);
      toolbarpi.addHandler('image', handleImageUpload);
      toolbarpi.addHandler('lucid', handleInsertLucid);
      toolbarpi.addHandler('ai', handleInsertAI);
      toolbarpi.addHandler('a3mode', handleInsertA3Mode);

      const quill = quillRef.current;
      if (quill){
        quill.root.addEventListener("keydown", (e: KeyboardEvent) => {  
          if (e.key === "Tab") {
            const tableModule = (quillRef.current as any).getModule("table-up");
            if (!tableModule) return;
            const range = quill.getSelection();
            if (!range) return;
            const leaf = quill.getLeaf(range.index)[0]; // get Quill leaf
            if (!leaf) return;
            let domNode = leaf.domNode as Node;
            if (domNode.nodeType === Node.TEXT_NODE) {
              domNode = domNode.parentNode!;
            }
            const cell = (domNode as HTMLElement).closest("td, th") as HTMLElement | null;
            if (!cell) return;
            e.preventDefault(); // stop default tab
            let nextCell: HTMLElement | null = null;
            if (e.shiftKey) {
              nextCell =
              (cell.previousElementSibling as HTMLElement | null) ||
              (cell.parentElement?.previousElementSibling?.lastElementChild as HTMLElement | null);
            } else {
              nextCell =
              (cell.nextElementSibling as HTMLElement | null) ||
              (cell.parentElement?.nextElementSibling?.firstElementChild as HTMLElement | null);
            }
            if (nextCell) {
              const blotOrQuill = Quill.find(nextCell);
              if (blotOrQuill && "domNode" in blotOrQuill) {
                const index = quill.getIndex(blotOrQuill as any);
                quill.setSelection(index, 0);
              }
            }
          }
        });

        quill.root.addEventListener("paste", (e: ClipboardEvent) => {
            const html = e.clipboardData?.getData("text/html") || "";
            if (!html) return;
            if (!html.includes("<table")) return;
            setTimeout(() => {
                // Track insertion point
                if (quill){
                    const selection = window.getSelection() //this.quill.getSelection();
                    if (!selection || selection.rangeCount === 0) return;
                    
                    const range = selection.getRangeAt(0);
                    const rangeq = quill.getSelection();
                    const contents = quill.getContents(0, rangeq?.index);
                    const ops = contents.ops ?? [];
                    const lastOp = ops[ops.length - 1];
                    if (typeof lastOp.insert === "object") {
                      if (
                        lastOp &&
                        typeof lastOp.insert === "object" &&
                        lastOp.insert !== null &&
                        "image" in lastOp.insert
                      ) {
                        const imageSrc = lastOp.insert.image;
                        try{
                          let index = 0;
                          for (const op of ops) {
                            if (
                              typeof op.insert === "object" &&
                              op.insert !== null &&
                              "image" in op.insert &&
                              op.insert.image === imageSrc
                            ) {
                              quill.deleteText(index, 1, "user");
                              break;
                            }
                            index += typeof op.insert === "string" ? op.insert.length : 1;
                          }
                        } catch {
                          console.log("Error in Excel Paste")
                        }
                      }
                    }
                    
                }
            }, 50);
        });
        const toolbar = document.querySelector('.ql-toolbar');
        if (!toolbar) return;

          // ---- Buttons ----
        toolbar.querySelectorAll<HTMLButtonElement>('button').forEach(button => {
            const classList = button.classList;

            if (classList.contains('ql-bold')) button.title = 'Bold';
            if (classList.contains('ql-italic')) button.title = 'Italic';
            if (classList.contains('ql-underline')) button.title = 'Underline';
            if (classList.contains('ql-strike')) button.title = 'Strikethrough';
            if (classList.contains('ql-link')) button.title = 'Insert Link';
            if (classList.contains('ql-image')) button.title = 'Insert Image';
            if (classList.contains('ql-video')) button.title = 'Insert Video';
            if (classList.contains('ql-blockquote')) button.title = 'Blockquote';
            if (classList.contains('ql-code-block')) button.title = 'Code Block';
            if (classList.contains('ql-clean')) button.title = 'Clear Formatting';
            if (classList.contains('ql-lucid')) button.title = 'Insert Lucid';
            if (classList.contains('ql-ai')) button.title = 'Insert AI';
            if (classList.contains('ql-a3mode')) button.title = 'Insert A3 Break';
            if (classList.contains('ql-redo')) button.title = 'Redo';
            if (classList.contains('ql-undo')) button.title = 'Undo';
            // Lists
            if (classList.contains('ql-list')) {
              const value = button.getAttribute('value');
              if (value === 'ordered') button.title = 'Numbered List';
              if (value === 'bullet') button.title = 'Bullet List';
            }

            // Indent / Outdent
            if (classList.contains('ql-indent')) {
              const value = button.getAttribute('value');
              if (value === '+1') button.title = 'Indent';
              if (value === '-1') button.title = 'Outdent';
            }

            // Alignment
            if (classList.contains('ql-align')) {
              const value = button.getAttribute('value');
              if (!value) button.title = 'Align Left';
              if (value === 'center') button.title = 'Align Center';
              if (value === 'right') button.title = 'Align Right';
              if (value === 'justify') button.title = 'Justify';
            }
          });

          // ---- Pickers (color, size, font etc.) ----
          toolbar.querySelectorAll<HTMLElement>('.ql-picker').forEach(picker => {
            const label = picker.querySelector<HTMLElement>('.ql-picker-label');
            if (!label) return;

            if (picker.classList.contains('ql-color')) label.title = 'Text Color';
            if (picker.classList.contains('ql-background')) label.title = 'Background Color';
            if (picker.classList.contains('ql-size')) label.title = 'Font Size';
            if (picker.classList.contains('ql-font')) label.title = 'Font Family';
            if (picker.classList.contains('ql-header')) label.title = 'Heading';
            if (picker.classList.contains('ql-table-up')) label.title = 'Insert Table';
            if (picker.classList.contains('ql-align')) label.title = 'Align Text';
           
          });

      }

      
      // Set initial content in Quill
      if (content === undefined){
        quillRef.current.root.innerHTML = "";
      } else {
        quillRef.current.root.innerHTML = content;
      }
      // Listen for changes

      quillRef.current.on("text-change", (delta: Delta, oldDelta: Delta, source: string) => {
        if (source !== "user") return; // only react to user input
        
        const html = quillRef.current!.root.innerHTML;
        if (html !== content){
              setContent(html);
              isDirtyRef.current = true;
              onChange(item.ID, "Explanation", html);
        }

      });

      if (quillRef.current) {
        const quill = quillRef.current;
        const defaultFontSize = settings.fontsize + "px";

        // Apply size to entire editor
        quill.root.style.fontSize = defaultFontSize;
        quill.format("size", defaultFontSize);

        // Apply size to existing content
        const length = quill.getLength();
        quill.formatText(0, length, "size", defaultFontSize);
        console.log("Applied default font size once");
      }

      let hasFocused = false;
      quillRef.current.on("selection-change", (range: QuillRange | null, oldrange: QuillRange | null, source: string) => {
        if (!hasFocused && range !== null && source === "user") {
          hasFocused = true;
          //console.log("First time user clicked into editor");
          const html = quillRef.current!.root.innerHTML;  
          onChange(item.ID, "Explanation", html);
          // do your logic here
          // e.g. mark dirty, enable save, notify parent once
        }
        
      });
    }
  }, [modules]);


  /*setTimeout(() => {
    if (quillRef.current){
        const quill = quillRef.current;
        const defaultFontSize = settings.fontsize + 'px'
        quill.root.style.fontSize = defaultFontSize;
        quill.format("size", defaultFontSize); 
        console.log("Set Size");
        const length = quill.getLength(); // total length including newline
        if (quill.getText().trim().length === 0 || quill.getText().trim() == "val"){
          quill.formatText(0, length, "size", defaultFontSize);
        }
    }  
  }, 0);*/

  return (
    <div style={{ 
          display: "contents", 
          overflow: "auto"
        }} >
    <div style={{ 
          height: "auto", 
          overflow: "100%"
        }} >
      <div spellCheck={"true"}
        ref={editorRef} 
        style={{ 
          height: "auto", 
          overflow: "100%"
        }} 
        onContextMenu={handleContextMenu }
        
      />
      <LinkDialog
        open={showLinkDialog}
        defaultText={defaultText}
        defaultUrl={defaultUrl}
        onCancel={handleToolbarEnable}
        onSave={insertLink}
      />
      <LucidDialog
        open={showLucidDialog}
        defaultText={defaultText}
        onCancel={handleToolbarEnableLucid}
        onSave={insertLucid}
      />
      <AIDialog
        open={showAIDialog}
        defaultText={defaultText}
        onCancel={handleToolbarEnableAI}
        onSave={insertAI}
        aioptions={settings.aioptions} 
        aiurl={settings.aiurl}
        aikey={settings.aikey}
        aimodel={settings.aimodel}
        setIsLoading={setIsUploading}
      />
    </div>
    {isUploading && (
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0,0,0,0.5)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 2147483647
        }}
      >
        <div
          style={{
            padding: "20px",
            backgroundColor: "white",
            borderRadius: "8px",
            textAlign: "center"
          }}
        >
          <p>Processing, please wait...</p>
          <div className="loader" /> {/* optional spinner */}
        </div>
      </div>
    )}
    {menuVisible && (
      <div
        ref={menuRef}  
        style={{
          position: 'fixed',
          top: menuPos.y,
          left: menuPos.x,
          breakInside: "avoid",
          backgroundColor: "#f0f0f0",       // light grey Windows-style
          border: "1px solid #ccc",         // thin border
          boxShadow: "2px 2px 6px rgba(0,0,0,0.2)", // subtle shadow
          borderRadius: "2px",              // small rounded corners
          minWidth: "150px",
          zIndex: 1000,
          fontFamily: "Segoe UI, sans-serif",
          fontSize: "14px",
          userSelect: "none",
          padding: "10px 10px",
          gap: "10px"
        }}
      >
        <div className="menuItem" onClick={() => handleMenuClick('undo')}>Undo</div>
        <div className="menuItem" onClick={() => handleMenuClick('redo')}>Redo</div>
        <div className="menuItem" onClick={() => handleMenuClick('copy')}>Copy</div>
      </div>
    )}
    </div>
  )
  };

export default CardEditor;
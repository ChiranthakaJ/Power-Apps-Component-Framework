interface CardItem {
  Title: string;
  ID: number;
  ExplanationStakeholder: string;
  ExplanationChecklist: string;
  Explanation: string;
  Hidden: boolean;
  A3Hidden: boolean;
  canedit: boolean;
  showeditor: boolean;
  isdirty: boolean;
  PreventBreak: boolean;
  quillkey: number;
  Sequence: number;
}

import React, { FC, CSSProperties, useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFolderOpen, faTrashCan, faFolderClosed, faCircleDown, faCircleUp, faEdit, faKeyboard, faComment, faCommentAlt,  faWindowRestore, faArrowAltCircleUp, faArrowAltCircleDown, faEyeSlash, faEye, faSave, faTrashAlt, faQuestionCircle  } from '@fortawesome/free-regular-svg-icons';
import "./CardItem";
import "./CardSettings";
import CardEditor, { CardEditorHandle } from "./CardEditor";
import "./css/A3View.css";
import "react-quill/dist/quill.snow.css";
const listStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(200px, 1fr))",
  gap: "10px",
  padding: "10px",
  backgroundColor: "#f9f9f9"
};

const headerandIconStyle: React.CSSProperties = {
  display: "flex", 
  width :"100%"
};

const headerStyle: React.CSSProperties = {
  fontWeight: "bold",
  textAlign: "left", 
  margin:"0px", 
  width:"50%"
};

const iconStyle: React.CSSProperties = {
  textAlign: "right", 
  display: "flex",
  width:"50%",
  justifyContent: "end"
};

const textStyle: React.CSSProperties = {
  fontWeight: "normal",
  textAlign: "left",
  margin:"0px"
};


// Props type for DragCardList
export interface DragCardListProps {
  initialitems: CardItem[];
  items: CardItem[];
  settings: CardSettings;
  onReorder: (items: CardItem[]) => void;
  onAction: (action: any,  itemid: number) => void;
  onRequestSave: (action: any,  updateitems: CardItem[]) => void;
  markDirty: (dirty: boolean, runtextchange: boolean)=> void;
}


export const DragCardList: FC<DragCardListProps> = ({ initialitems = [], items = [], settings, onReorder = () => {}, onAction = () => {}, onRequestSave = () => {}, markDirty = () => {} }) => {
    const [columns, setColumns] = useState<number>(settings.defaultcolumns);
    const dragIndex = React.useRef<number | null>(null);
    const [hoveredId, setHoveredId] = React.useState<string | null>(null);
    const [showAll, setShowAll] = React.useState<boolean>(false); // checkbox state
    
    const [showTopMenu, setShowTopMenu] = React.useState<boolean>(false); // checkbox state
    const [hasReordered, setHasReordered] = React.useState<boolean>(false); // checkbox state
    const [showDragDrop, setShowDragDrop] = React.useState<boolean>(settings.dragdropvisible); // checkbox state
    const [showQuickEdit, setShowQuickEditVisible] = React.useState<boolean>(settings.quickeditvisible); // checkbox state
    const [showA3, setShowA3] = React.useState<boolean>(settings.a3mode); // checkbox state
    const canEdit = settings.canedit;
    const [preOrderedArray, setPreOrderedArray] = React.useState<CardItem[]>([]); // checkbox state
    const latestItemsRef = React.useRef<CardItem[]>([]);

    //console.log("Set: " + showA3 + ", " + settings.a3mode + " : " + canEdit + ", " + settings.canedit)
    //const [updatedArray, setUpdatedArray] = React.useState<CardItem[]>(items);
    //setShowTopMenu(false);
    const [updatedArray, setUpdatedArray] = React.useState<CardItem[]>(() =>
        structuredClone(items)
    );
    const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);
    const [lightboxSrcChecklist, setLightboxSrcChecklist] = useState<string | null>(null);
    const [menuOffset, setMenuOffset] = React.useState({ x: 0, y: 0 });
    
    React.useEffect(() => {
        setShowA3(settings.a3mode);
    }, [settings.a3mode]);

    React.useEffect(() => {
        // Inject Font Awesome CDN stylesheet
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href =
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css";
        link.crossOrigin = "anonymous";
        document.head.appendChild(link);

        // Optional: cleanup
        return () => {
        document.head.removeChild(link);
        };
    }, []);

    const handleImageClick = (e: React.MouseEvent<HTMLDivElement>, index: number, quickedit: boolean, item: CardItem) => {
        const target = e.target as HTMLElement;
        //console.log(target.tagName);
        const anchor = target.closest("a");
       if (anchor) {
            const url = anchor.getAttribute('href');
            if (url) {
            // Open in new window/tab explicitly
            window.open(url, '_blank', 'noopener,noreferrer');
            }
            return;
        }

        if (target.tagName === "IMG" && (target.id !== "checklist" && target.id !== "stakeholder")) {
            setLightboxSrc((target as HTMLImageElement).src);
        } else if (target.tagName === "IMG" && target.id === "checklist") {
            setLightboxSrcChecklist(item.ExplanationChecklist);
        } else if (target.tagName === "IMG" && target.id === "stakeholder") {
            setLightboxSrcChecklist(item.ExplanationStakeholder);
        } else {
            //console.log("Quickedit");
            quickEdit(index, quickedit, item);
        }
    };

    React.useEffect(() => {
        setUpdatedArray(structuredClone(items));
    }, [items]);
    

    function getCardClass(
        item: CardItem,
        showAll: boolean, 
        showA3: boolean
    ): string {
        let className: string;
        if (settings.singlemode){
            className = "A3ViewCardSingleMode";
        } else {
            if (item.Hidden) {
                if (showAll) {
                    if (item.PreventBreak) {
                        className = "A3ViewCardHiddenNoBreak";
                    } else {
                        className = "A3ViewCardHidden";
                    }
                } else {
                    className = "A3ViewCardHiddenFull";
                }
            } else if (item.A3Hidden){
                if (!showA3 && !settings.a3mode) {
                    if (item.PreventBreak) {
                        className = "A3ViewCardHiddenNoBreakA3";
                    } else {
                        className = "A3ViewCardA3";
                    } 
                } else {
                    className = "A3ViewCardA3HiddenFull";
                }
            } 
            else {
                if (item.PreventBreak) {
                    className = "A3ViewCardNoBreak";
                } else {
                    className = "A3ViewCard";
                }
            }
        }
        return className;
    }

    function getHTML(item: CardItem, showA3: boolean): string {
        if(!item.Explanation) {
            return "";
        }
        if (settings.a3mode || showA3) {
            const breaker = '<div class="a3breaker"';
            try{
                const index = item.Explanation.indexOf(breaker);
                if (index !== -1) {
                    return item.Explanation.substring(0, index);
                }
            } catch {
                return item.Explanation;
            }
            return item.Explanation;
        }

        return item.Explanation;
    }

    const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>, item: CardItem) => {
        const card = e.currentTarget.parentElement?.parentElement;
        // parent container
        const parent = card?.parentElement?.parentElement; 
        if (!parent) return;
        const parentRect = parent.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        setHoveredId("MENU" + item.ID)
        const menuWidth = 180;
        let menuHeight = 330;

        if (!settings.canedit){
            menuHeight = 100;
        }
        let offsetX = 0;
        let offsetY = 0;
        // Use pageX/Y if your container scrolls
        const x = e.pageX;
        const y = e.pageY;
        // Adjust if menu would overflow viewport
        if (cardRect.right + menuWidth > parentRect.right) {
            offsetX = parentRect.right - (cardRect.right + menuWidth) - 4; // small padding
        }
        // check vertical overflow relative to parent
        if (cardRect.top + menuHeight > parentRect.bottom) {
            offsetY = parentRect.bottom - (cardRect.top + menuHeight) - 4;
        }
        setMenuOffset({ x: offsetX - 10, y: offsetY - 10 });
    };

    const setToggleTopMenu = () => {
        setShowTopMenu(!showTopMenu);
    };

    const updateShowA3 = (
        show: boolean
    )=> { 
        setShowA3(show);
    }

    const updateItemFieldFromEditor = (
        id: number,
        field: string,
        value: string
        ) => { 
        //console.log(id + " : " + value);
        if (settings.singlemode){
            const newArray = [...updatedArray];
            newArray[0] = {
                ...newArray[0],
                [field]: value, 
                isdirty: true
            };
            onRequestSave({
                type: "saveTriggered",
                cardId: newArray[0].ID,
                cardTitle: newArray[0].Title,
                timestamp: new Date().toISOString()
                }, newArray
            );
        } else {
            setUpdatedArray(prev =>
                prev.map(item =>
                    item.ID === id
                    ? { ...item, [field]: value, isdirty: true }
                    : item
                )   
            );
        }
        markDirty(true, true); // PCF notifyOutputChanged wrapper
    };

    const quickEdit = (index: number, quickedit: boolean, item: CardItem) => {
        //.log(showQuickEdit + " : " + showDragDrop)
        if(!item.showeditor && canEdit && item.canedit && !showQuickEdit){
            setUpdatedArray(prev => {
                const copy = [...prev];
                copy[index] = {
                ...copy[index],
                ["showeditor"]: quickedit,  
                isdirty: true
                };
                return copy;
            });
            setShowQuickEditVisible(true);
            setShowDragDrop(false);
        }
    };

    const moveItems = (toIndex: number, fromIndex: number) => {
        //console.log("In move items");
        if(!hasReordered){
            setPreOrderedArray(structuredClone(updatedArray));
        }
        const updated = [...updatedArray];

        const [moved] = updated.splice(fromIndex, 1);
        updated.splice(toIndex, 0, moved);

        dragIndex.current = toIndex;

        const normalized = updated.map((item, idx) => {
            const newSequence = idx + 1;
            const sequenceChanged = item.Sequence !== newSequence;

            return {
                ...item,
                Sequence: newSequence,
                isdirty: sequenceChanged ? true : item.isdirty
            };
        });
        latestItemsRef.current = normalized;
        setUpdatedArray(normalized);
        setShowTopMenu(true);
        setHasReordered(true);
    };

    const quickSave = (item: CardItem, index: number) => {
        const newArray = [...updatedArray];
        newArray[index] = {
            ...newArray[index],
            showeditor: false
        };
        setUpdatedArray(newArray);
        onRequestSave({
	        type: "saveClicked",
            cardId: item.ID,
            cardTitle: item.Title,
            timestamp: new Date().toISOString()
            }, newArray
        );
        setHasReordered(false);
        setShowDragDrop(true);
        setShowQuickEditVisible(false);

    };

    const quickSaveReordered = () => {
            //console.log(latestItemsRef.current);
            onRequestSave({
                type: "saveClicked",
                cardId: 0,
                cardTitle: "",
                timestamp: new Date().toISOString()
                }, latestItemsRef.current
            );
            setHasReordered(false);
            setShowTopMenu(false);
            setShowQuickEditVisible(false);
            markDirty(false, false);
        
    };

    const preventBreak = (index: number, item: CardItem, preventbreak: boolean) => {
        setUpdatedArray(prev => {
            const copy = [...prev];
            copy[index] = {
            ...copy[index],
            ["PreventBreak"]: preventbreak,  
            isdirty: true
            };
            return copy;
        });
        onAction({
                type: preventbreak ? "itemPreventBreakClicked" : "itemAllowedBreakClicked",
                cardId: item.ID,
                cardTitle: item.Title,
                timestamp: new Date().toISOString()
            }, 
            item.ID
        )
    };
    
    const hideItem = (index: number, item: CardItem, hide: boolean) => {
        setUpdatedArray(prev => {
            const copy = [...prev];
            copy[index] = {
            ...copy[index],
            ["Hidden"]: hide, 
            ["A3Hidden"]: hide,   
            isdirty: true
            };
            return copy;
        });
        onAction({
                type: hide ? "itemHideClicked" : "itemShowClicked",
                cardId: item.ID,
                cardTitle: item.Title,
                timestamp: new Date().toISOString()
            }, 
            item.ID
        );
        setShowTopMenu(hide);
        setShowAll(hide)
        //markDirty(true, false);
    };

    const hideItemA3 = (index: number, item: CardItem, hide: boolean) => {
        setUpdatedArray(prev => {
            const copy = [...prev];
            copy[index] = {
            ...copy[index],
            ["A3Hidden"]: hide,  
            isdirty: true
            };
            return copy;
        });
        onAction({
                type: hide ? "itemHideA3Clicked" : "itemShowA3Clicked",
                    cardId: item.ID,
                    cardTitle: item.Title,
                    timestamp: new Date().toISOString()
                    }, 
                    item.ID
        )
        //markDirty(true, false);
    };


    // Insert item at index
    const insertItem = (index: number) => {
        if(index == -1){
            index = 0
        };
        const randomNegative = -Math.floor(Math.random() * 1000000);
        const newItem: CardItem = {
            ID: randomNegative,
            Title: "Enter Title Here",
            Explanation: "",
            ExplanationStakeholder: "",
            ExplanationChecklist: "",
            isdirty: true, 
            canedit: true, 
            Hidden: false, 
            A3Hidden: false,
            showeditor: true, 
            PreventBreak: false, 
            quillkey: randomNegative,
            Sequence: index + 1
        };
        setUpdatedArray(prev => {
            const copy = [...prev];
            copy.splice(index, 0, newItem);
            
            const normalized = copy.map((item, idx) => ({
                ...item,
                Sequence: idx + 1, // or idx
                isdirty: true
            }));
            return normalized;
        });
        setShowQuickEditVisible(true);
        markDirty(true, false); 
    };

    // Remove item
    const removeItem = (index: number) => {
        const item = updatedArray[index];
        if (item){
            if (item.ID < 0){
                setUpdatedArray(prev => {
                    const remove = prev.filter((_, i) => i !== index);
                    const normalized = remove.map((item, idx) => ({
                        ...item,
                        Sequence: idx + 1, // or idx
                        isdirty: true
                }));
            return normalized;
        });
            } else {
                onAction({
                    type: "itemDeleteClicked",
                    cardId: item.ID,
                    cardTitle: item.Title,
                    timestamp: new Date().toISOString()
                    }, 
                    item.ID
                )
            }
        } 
    };

    const resetItem = (id: number) => {
        setUpdatedArray(
            initialitems.map(i =>
                i.ID === id
                ? { ...i, quillkey: Math.floor(Math.random() * 1000000) }
                : i
            )
        );
        setShowQuickEditVisible(false);
        setShowDragDrop(true);
        markDirty(false, false);
        
    };

    const resetReorder = () => {
        setUpdatedArray(preOrderedArray);
        setHasReordered(false);
        setShowTopMenu(false);
        setShowQuickEditVisible(false);
        markDirty(false, false);
    };
    const handleInputBlur = (
        index: number, 
        field: string, 
        item: CardItem,
        e: React.FormEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        const newHtml = e.currentTarget.innerHTML;
        setUpdatedArray(prev => {
            const copy = [...prev];
            copy[index] = {
            ...copy[index],
            [field]: newHtml,      // 👈 header OR body
            isdirty: true
            };
            return copy;
        });
        //quickEdit(index, true, item)
        //markDirty(true, true);
    };
    const containerHeightAdjust = showTopMenu ? 22 : 0;
    //console.log(containerHeightAdjust);
    const containerHeight = settings.viewportsize && settings.viewportsize > 0 ? `${(settings.viewportsize) - containerHeightAdjust}px` : "100vh"; // fallback for debug

    return (
    <div style={{ pointerEvents: "auto", textAlign: "left",  height: "100%", width: "100%" }}>
        {!settings.singlemode && (
        <div style={{display: "flex", paddingTop: "1px"}} >
            <div style={{display: "flex", paddingTop: "0px"}} onClick={(e) => setToggleTopMenu()}>
                {showTopMenu && (
                    <FontAwesomeIcon 
                        icon={faCircleUp} 
                        title="Hide Top Menu"
                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer", height: "10px"  }} />
                )}
                {!showTopMenu && (
                    <FontAwesomeIcon 
                        icon={faCircleDown}
                        title="Show Top Menu"
                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer", height: "10px"  }} />
                )}
            </div>
            {showTopMenu && (
            <div className="controlHolder" style={{fontSize: settings.fontsize + "px", alignContent:"center"}}>
                <div style={{textAlign: "left", width: "auto", float:"left", alignContent:"center"}}>
                    <div style={{ marginBottom: 3, paddingLeft: 10, marginRight: "10px", float:"left" }}>
                        <label>
                        Columns in View:{" "}
                        <select className="modern-select"
                            style={{width:"100px"}}
                            value={columns}
                            onChange={(e) => setColumns(Number(e.target.value))}>
                            {[...Array(settings.numbercolumns).keys()].map(n => n + 1).map((n) => (
                            <option key={n} value={n}>
                                {n}
                            </option>
                            ))}
                        </select>
                        </label>
                    </div>
                    {(settings.a3mode ? true : (!showA3 && !showQuickEdit) && !hasReordered) && (
                    <div style={{marginTop:"3px", float:"left", paddingRight: "13px"}}>
                        <label className="checkbox-inline" >
                                <input
                                    type="checkbox"
                                    checked={showAll}
                                    onChange={(e) => setShowAll(e.target.checked)}
                                />
                                <span className="checkmark"></span>
                                Show Hidden Blocks
                        </label>
                    </div>
                    )}
                    {(!showAll && !showQuickEdit && !settings.a3mode && !hasReordered) && (
                    <div style={{marginTop:"3px", float:"left", paddingRight: "13px"}}>
                        <label className="checkbox-inline" >
                                <input
                                    type="checkbox"
                                    checked={showA3}
                                    onChange={(e) => updateShowA3(e.target.checked)}
                                />
                                <span className="checkmark"></span>
                                Show A3 Mode
                        </label>
                    </div>
                    )}
                </div>
                 <div style={{width:"auto",textAlign:"center", alignContent: "center", float: "left", paddingLeft: "10px"}}>
                        {(hasReordered) && (
                            <div style={{width:"450px", float:"left"}}>
                                <div className="qe-item" style={{float:"left", paddingTop: "2px"}}
                                    onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        quickSaveReordered()
                                    }} 
                                >
                                    <FontAwesomeIcon 
                                        icon={faSave} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Save
                                </div>
                                <div className="qe-item" style={{float:"left", paddingTop: "2px"}}
                                    onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            resetReorder();
                                        }} 
                                >
                                <FontAwesomeIcon 
                                        icon={faTrashAlt} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Reset
                                </div>
                                <div style={{width:"auto", paddingLeft: "25px", paddingRight: "25px", paddingTop: "5px", paddingBottom: "5px",float: "left", textAlign: "left", backgroundColor: "#dddddd", borderRadius: "20px", border:"solid 1px gray"}}><b>You must select Save to apply these changes</b></div>
                            </div>
                            
                         )}
                </div>
                <div title="Help" style={{paddingLeft: "20px"}}  onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        onAction({
                            type: "showHelpClicked",
                            cardId: 0,
                            cardTitle: "",
                            timestamp: new Date().toISOString()
                        }, 0)
                    }}>
                    <FontAwesomeIcon 
                        icon={faQuestionCircle} 
                        style={{ pointerEvents: "auto", cursor: "pointer", height:"30px", paddingRight: "25px", color:"black"  }} />
                </div>
            </div>
            )}
        </div>
        )}
        
        <div  style={{
            /*height: settings.viewportsize + "vh",*/              /* constrain to window height */
            height: containerHeight,
            width: "99.5%",
            columnCount:  settings.singlemode ? 0 : columns,
            columnGap: settings.singlemode ?  "0px" : "10px",
            columnFill: "auto",            /* flow into next column when full */          /* prevent page scroll */
            paddingLeft: "3px",
            paddingRight: "7px",
            paddingTop: "3px",
            paddingBottom: "3px",
            overflowX: settings.singlemode ? "hidden" : "auto",          /* horizontal scroll when columns exceed width */
            overflowY: settings.singlemode ? "auto" : "auto"
        }}>
        {updatedArray
        .map((item, i) => (
            <div
                key={i}
                data-index={i}
                style={{border: item.showeditor && !settings.singlemode ? "orange 3px solid": "none"}}
                className={ getCardClass(item, showAll, showA3)}
                onDrop={(e) => {
                    e.preventDefault();
                    //e.stopPropagation();
                    if (dragIndex.current === null) return;
                    if (i !== dragIndex.current) {
                        moveItems(i, dragIndex.current);
                    }          
                }}
            > 
            {!settings.singlemode && (
                <div style={headerandIconStyle}>
                {settings.showdebug && (
                    <div style={{width: "30px", fontWeight: "bold"}}>
                        {item.Sequence}: 
                    </div>
                )}
                <div  className="contentDiv" 
                    contentEditable={!settings.singlemode && item.showeditor} 
                    suppressContentEditableWarning style={headerStyle}
                    onBlur={(e) => handleInputBlur(i, "Title", item, e)}
                    >
                    {item.Title}
                </div>
                
                <div style={iconStyle}>
                    <div style={{minWidth:"180px"}}>
                        {(!item.showeditor && canEdit && item.canedit && !hasReordered && !showQuickEdit) && (
                                <div className="qe-item" style={{paddingRight: "30px"}}
                                    onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            quickEdit(i, true, item);
                                        }} 
                                >
                                    <FontAwesomeIcon 
                                        icon={faKeyboard} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Quick Edit 
                                </div>
                            )}
                            <div style={{width:"auto", float:"right"}}>
                            {(item.showeditor && item.isdirty) && (
                                <div className="qe-item" style={{float:"left"}}
                                    onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            quickSave(item, i);
                                        }} 
                                >
                                    <FontAwesomeIcon 
                                        icon={faSave} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Save
                                </div>
                            )}
                            {(item.showeditor) && (
                                <div className="qe-item" style={{float:"right"}}
                                    onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            resetItem(item.ID);
                                        }} 
                                >
                                <FontAwesomeIcon 
                                        icon={faTrashAlt} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Reset
                                </div>
                            )}
                            </div>
                    </div>
                    <div style={{minWidth:"60px"}}></div>
                    {(!showQuickEdit && !hasReordered) && (
                    <div
                        key={"MENU" + item.ID}
                        style={{ position: "relative", display: "inline-block", width:"30px" }}
                        onMouseEnter={(e) => handleMouseEnter(e, item)}
                        onMouseLeave={(e) => {
                            e.stopPropagation();
                            setHoveredId(null)
                            }
                        }
                    >
                    
                        <button className="menu-trigger">
                        ⋮
                        </button>
                    {(hoveredId === "MENU" + item.ID) && (
                        <div 
                            className="hover-menu"
                            style={{
                                position: "absolute",
                                top: menuOffset.y,
                                left: `calc(100% + ${menuOffset.x}px)`,
                                zIndex: 1000,
                                whiteSpace: "nowrap",
                            }}
                            >
                            {(!settings.isdirty && canEdit) && (
                                <div className="menu-item"
                                onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        onAction({
                                            type: "editClicked",
                                            cardId: item.ID,
                                            cardTitle: item.Title,
                                            timestamp: new Date().toISOString()
                                        }, item.ID)
                                        }}>
                                    <FontAwesomeIcon 
                                        icon={faEdit} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Advanced Edit 
                                </div>
                            )}
                            {!settings.isdirty && (
                            <div className="menu-item"
                                onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        onAction({
                                            type: "commentClicked",
                                            cardId: item.ID,
                                            cardTitle: item.Title,
                                            timestamp: new Date().toISOString()
                                        }, item.ID)
                                }}> 
                                <FontAwesomeIcon 
                                    icon={faComment} 
                                    style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Add Comment
                            </div>
                            )}
                            {!settings.isdirty && (
                            <div className="menu-item"
                                onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        onAction({
                                            type: "viewCommentsClicked",
                                            cardId: item.ID,
                                            cardTitle: item.Title,
                                            timestamp: new Date().toISOString()
                                        }, item.ID)
                                    }}> 
                                <FontAwesomeIcon 
                                    icon={faCommentAlt} 
                                    style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; View Comments 
                            </div>
                            )}
                            {(!settings.isdirtytextchanged && canEdit) && (
                            <div className="menu-item"
                                onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        insertItem(i);
                                    }}> 
                                <FontAwesomeIcon 
                                    icon={faArrowAltCircleUp} 
                                    style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Insert Block Before
                            </div>
                            )}
                            {(item.Hidden == false && canEdit) && (
                            <div className="menu-item" 
                                onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                       insertItem(i + 1);
                                    }}> 
                                <FontAwesomeIcon 
                                    icon={faArrowAltCircleDown} 
                                    style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                    &nbsp; Insert Block After
                            </div>
                            )}
                            {(!item.Hidden && canEdit) && (
                                <div className="menu-item" 
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            hideItem(i, item, true);
                                        }}>
                                        
                                        <FontAwesomeIcon 
                                            icon={faEyeSlash} 
                                            style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Hide Block 
                                </div>
                            )}
                            {(item.Hidden && canEdit) && (
                                    <div className="menu-item"
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            hideItem(i, item, false);
                                        }}>
                                        
                                        <FontAwesomeIcon 
                                            icon={faEye} 
                                            style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Show Block 
                                    </div>
                            )}
                             {(item.A3Hidden == false && item.Hidden == false && canEdit) && (
                                <div className="menu-item" 
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            hideItemA3(i, item, true);
                                        }}>
                                        
                                        <FontAwesomeIcon 
                                            icon={faEyeSlash} 
                                            style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Hide Block in A3
                                </div>
                            )}
                            {(item.A3Hidden && item.Hidden == false && canEdit) && (
                                    <div className="menu-item"
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            hideItemA3(i, item, false);
                                        }}>
                                        
                                        <FontAwesomeIcon 
                                            icon={faEye} 
                                            style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Show Block in A3
                                    </div>
                            )}
                            {(canEdit) && (
                            <div className="menu-item" 
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            removeItem(i);
                                        }}> 
                                    <FontAwesomeIcon 
                                        icon={faTrashCan} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Delete Block
                            </div>
                            )}
                            {(!item.PreventBreak && canEdit) && (
                                    <div className="menu-item"
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            preventBreak(i, item, true);
                                        }}>
                                        
                                        <FontAwesomeIcon 
                                            icon={faFolderClosed} 
                                            style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Prevent Column Break 
                                    </div>
                            )}
                            {(item.PreventBreak && canEdit) && (
                                    <div className="menu-item" 
                                        onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            preventBreak(i, item, false);
                                        }}> 
                                    <FontAwesomeIcon 
                                        icon={faFolderOpen} 
                                        style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                                        &nbsp; Allow Column Break
                                    </div>
                            )}
                        </div>
                    )}
                    </div>
                    )}
                    {(showDragDrop && canEdit) && (
                        <div title="Drag to icon to reorder" style={{width: "30px"}} draggable
                                onDragStart={(e) => {
                                    dragIndex.current = i;
                                    // Required for IE / Power Apps to allow drop
                                    e.dataTransfer.effectAllowed = "move";
                                    e.dataTransfer.setData("text/plain", String(i));
                                }}
                                onDragOver={(e) => {
                                    e.preventDefault(); // Needed to allow drop
                                    e.stopPropagation();
                                }}>
                            <i className="fas fa-arrows-alt" style={{ color: "gray", cursor: "pointer", fontSize: "16px" }}></i>
                        </div>
                    )}
                </div>
                
            </div>
            )}
            {item.showeditor && (
                <div className={`quill-wrapper ${!item.showeditor ? "hide-toolbar" : ""}`} 
                >
                    <CardEditor
                        key={`${item.ID}-${item.quillkey}`}
                        item={item}
                        onChange={updateItemFieldFromEditor}
                        readonly={!item.canedit || !canEdit || !item.showeditor}
                        settings={settings}
                    />
                </div>
            )}
            {!item.showeditor && (
                <div className="contentDiv ql-editor" 
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        handleImageClick(e, i, true, item)
                    }}
                    style={{
                        width: "100%",
                        height: "auto",
                        overflow: "visible",
                        padding: "0px", 
                        fontSize: settings.fontsize + "px"
                    }}
                    contentEditable={false}
                    dangerouslySetInnerHTML={{ __html: getHTML(item, showA3)}}
                />
            )}
        </div>
      ))}
    </div>
    {lightboxSrc && (
        <div
            style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.8)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999,
            cursor: "pointer"
            }}
            onClick={() => setLightboxSrc(null)}
        >
        <img src={lightboxSrc} style={{ maxWidth: "90%", maxHeight: "90%", overflow: "auto" }} />
        </div>
    )}
    {lightboxSrcChecklist && (
        <div
            style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.8)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999,
            cursor: "pointer"
            }}
            onClick={() => setLightboxSrcChecklist(null)}
        >
        <div 
            contentEditable={false}
            dangerouslySetInnerHTML={{ __html: lightboxSrcChecklist}}
            style={{ backgroundColor: "white", maxWidth: "90%", maxHeight: "90%", padding: "10px", overflow: "auto" }} 
        />
        </div>
    )}
    </div>
  );
};

// LinkDialog.tsx
import * as React from "react";
import {
  Dialog,
  DialogType,
  DialogFooter,
  PrimaryButton,
  DefaultButton,
  TextField
} from "@fluentui/react";

export interface LinkDialogProps {
  open: boolean;
  defaultText?: string;
  defaultUrl?: string;
  onCancel: () => void;
  onSave: (text: string, url: string) => void;
}

export const LinkDialog: React.FC<LinkDialogProps> = ({
  open,
  defaultText = "",
  defaultUrl = "",
  onCancel,
  onSave
}) => {
  const [text, setText] = React.useState(defaultText);
  const [url, setUrl] = React.useState(defaultUrl);

  React.useEffect(() => {
    setText(defaultText);
    setUrl(defaultUrl);
  }, [defaultText, defaultUrl, open]);

  return (
       <Dialog
      hidden={!open}
      onDismiss={onCancel}
      dialogContentProps={{
        type: DialogType.normal,
        title: "Insert Link"
      }}
      modalProps={{
        isBlocking: true
      }}
    >
      <TextField
        label="Display Text"
        value={text}
        onChange={(_, newValue) => setText(newValue || "")}
      />

      <TextField
        label="URL"
        value={url}
        onChange={(_, newValue) => setUrl(newValue || "")}
      />

      <DialogFooter>
        <DefaultButton onClick={onCancel} text="Cancel" />
        <PrimaryButton
          onClick={() => onSave(text, url)}
          text="Insert"
          disabled={!text || !url}
        />
      </DialogFooter>
    </Dialog>
  );
};

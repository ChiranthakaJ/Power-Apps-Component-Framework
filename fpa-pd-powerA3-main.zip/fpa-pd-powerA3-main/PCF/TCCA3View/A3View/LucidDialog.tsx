// LinkDialog.tsx
import * as React from "react";
import {
  Dialog,
  DialogType,
  DialogFooter,
  PrimaryButton,
  DefaultButton,
  TextField
} from "@fluentui/react";

export interface LucidDialogProps {
  open: boolean;
  defaultText?: string;
  onCancel: () => void;
  onSave: (text: string) => void;
}

export const LucidDialog: React.FC<LucidDialogProps> = ({
  open,
  defaultText = "",
  onCancel,
  onSave
}) => {
  const [text, setText] = React.useState(defaultText);

  React.useEffect(() => {
    setText(defaultText);
  }, [defaultText, open]);

  return (
    <Dialog
      hidden={!open}
      onDismiss={onCancel}
      dialogContentProps={{
        type: DialogType.normal,
        title: "Insert Lucid"
      }}
      modalProps={{
        isBlocking: true,
        styles: {
          main: {
            width: "40vw",          // fixed width
            maxWidth: 800
          }
        }
      }}
      minWidth={400}
    >
      <TextField
        label="Lucid Embed Text"
        multiline
        rows={8}
        value={text}
        onChange={(_, newValue) => setText(newValue || "")}
        styles={{ root: { width: '100%' } }}
      />

      <DialogFooter>
        <DefaultButton onClick={onCancel} text="Cancel" />
        <PrimaryButton
          onClick={() => onSave(text)}
          text="Insert"
          disabled={!text}
        />
      </DialogFooter>
    </Dialog>
  );
};

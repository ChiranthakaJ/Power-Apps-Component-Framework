import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import "./CardItem";
import "./CardSettings";
import "./css/A3View.css";
import { createRoot, Root } from "react-dom/client";
import { DragCardList, DragCardListProps } from "./DragCardList"; // import props type
import QuillImageResizer from '@mouseoverllc/quill-image-resizer';
//import QuillImageDropAndPaste from 'quill-image-drop-and-paste';
import TableUp, { defaultCustomSelect, TableAlign, TableResizeLine, TableMenuContextmenu, TableResizeBox, TableResizeScale, TableSelection, TableVirtualScrollbar, tableMenuTools } from 'quill-table-up';
import 'quill/dist/quill.snow.css';
import 'quill-table-up/index.css';
import 'quill-table-up/table-creator.css';

export class A3View implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    /**
     * Empty constructor.
     */
    constructor() {
        // Empty
    }

    
    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */

    private container: HTMLDivElement;
    private context: ComponentFramework.Context<IInputs>;
    private notifyOutputChanged: () => void;
    private items: CardItem[] = [];
    private initialitems: CardItem[] = [];
    private updateditems: CardItem[] = [];

    private settings: CardSettings;
    private lastJson: string | null = null;
    private lastJsonSettings: string | null = null;
    private root: Root | null = null;
    private actionValue: string = "";
    private selectedBlockID: string = "";
    private value: string = "";
    private isDirty = false;
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Add control initialization code
        this.context = context;
        this.container = container;
        this.container.style.pointerEvents = "auto";
        this.container.tabIndex = 0;
        context.mode.trackContainerResize(true);
        this.container.style.height = "100%";
        this.container.style.width = "100%";
        this.container.style.display = "flex";
        this.container.style.flexDirection = "column";
        this.notifyOutputChanged = notifyOutputChanged;
    }

    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    private handleActionFromChild = (action: any, itemid: number) => {
        // Save action value
        this.actionValue = JSON.stringify(action);
        this.selectedBlockID = itemid.toString();
        this.value = Date.now().toString() + "_" + Math.random();
        this.settings.isdirty = false;
        //console.log("Action from Child: " + JSON.stringify(action));
        //console.log("Action from Child Signal: " + this.value);
        setTimeout(() => {
            this.notifyOutputChanged();
        }, 0);
        //this.notifyOutputChanged();
    };

    private onRequestSave = (action: any, updateditems: CardItem[]) => {
        // Save action value
        this.actionValue = JSON.stringify(action);
        this.updateditems = updateditems;        
        this.settings.isdirty = false;
        this.value = Date.now().toString() + "_" + Math.random();;
        //console.log("Request Save: " + JSON.stringify(action));
        //console.log("Request Save: " + this.value);
        setTimeout(() => {
            this.notifyOutputChanged();
        }, 0);
        
        //this.notifyOutputChanged();
    };

    private markDirty = (dirty: boolean, runtextchange: boolean) => {
        if (!this.settings.isdirty && dirty) {
            this.settings.isdirty = true
            if (runtextchange){
                //this.settings.isdirtytextchanged = true
            }
            this.notifyOutputChanged();
        } else {
            if (this.settings.isdirty && !dirty){
                this.settings.isdirty = false
                this.settings.isdirtytextchanged = false
                this.notifyOutputChanged();
            }
        }
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const json = context.parameters.items.raw;
        const jsonsettings = context.parameters.settings.raw;
        if (jsonsettings && jsonsettings !== this.lastJsonSettings){
            //console.log("In Settings");
            this.settings = jsonsettings ? JSON.parse(jsonsettings) : [];
            this.lastJsonSettings = jsonsettings;
            //console.log(jsonsettings);
        }
        if (json && json !== this.lastJson) {
            //console.log("No match")
            //console.log("In JSON");
            try {
                this.items = json ? JSON.parse(json) : [];
                this.initialitems = structuredClone(this.items);
                //console.log(this.initialitems);
                this.lastJson = json;
                if (jsonsettings){
                    //this.settings = json ? JSON.parse(jsonsettings) : [];
                }
            } catch {
                console.error("Invalid cardsJson");
                this.items = [];
            }
        }
        // onReorder callback
        const onReorder: DragCardListProps["onReorder"] = (newItems) => {
            //console.log("On Reorder");
            this.items = newItems;
            this.actionValue = "";
            this.selectedBlockID = "";
            this.settings.canedit = true;
            this.markDirty(true, false);
            this.notifyOutputChanged();
            //this.render(onReorder);
        };

        this.actionValue = ""
        this.render(onReorder);
    }

    private render(onReorder?: DragCardListProps["onReorder"]) {
        //console.log("render");
        console.log("1.0.0.10");
        if (!this.root) {
            this.root = createRoot(this.container);
        }
        this.root.render(
            
            React.createElement(DragCardList, { 
                initialitems: this.initialitems,
                items: this.items, 
                settings: this.settings, 
                onReorder: onReorder ?? (() => {}), 
                onAction: this.handleActionFromChild, 
                onRequestSave: this.onRequestSave ?? (() => {}), 
                markDirty: this.markDirty ?? (() => {})
            })
        );
    }
    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        //console.log("Get Outputs Run V3");
        return {
            html: this.updateditems.length > 0 ? this.updateditems[0].Explanation : "",
            itemsOut: JSON.stringify(this.updateditems),
            actionValue: this.actionValue, 
            Value: this.value,
            selectedBlockID: this.selectedBlockID,
            IsDirty: this.settings.isdirty
        };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        if (this.root) {
            this.root.unmount();
            this.root = null;
        }
    }
}


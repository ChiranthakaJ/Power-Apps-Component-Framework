// quill/core does not declare its exports in package.json exports map.
// Standalone type declaration covering all Quill v2 APIs used by this codebase.
declare module "quill/core" {
  interface QuillDelta {
    ops?: Array<{ insert?: unknown; delete?: number; retain?: unknown; attributes?: Record<string, unknown> }>;
  }

  class Quill {
    constructor(container: Element | string, options?: Record<string, unknown>);

    /** v1-compat: registered modules/formats cache */
    static imports: Record<string, unknown>;
    static register(name: string, target: unknown, overwrite?: boolean): void;
    static register(formats: Record<string, unknown>, overwrite?: boolean): void;
    static import(name: string): unknown;
    static find(node: Node | Element, bubble?: boolean): Quill | null;

    root: HTMLElement;
    clipboard: unknown;
    keyboard: unknown;
    scroll: unknown;
    /** history module (registered at runtime) */
    history: { undo(): void; redo(): void; clear(): void };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    on(event: string, handler: (...args: any[]) => void): this;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    off(event: string, handler: (...args: any[]) => void): this;

    getContents(index?: number, length?: number): QuillDelta;
    setContents(delta: unknown, source?: string): QuillDelta;
    updateContents(delta: unknown, source?: string): QuillDelta;

    getText(index?: number, length?: number): string;
    getLength(): number;
    insertText(index: number, text: string, source?: string): unknown;
    insertText(index: number, text: string, format: string, value: unknown, source?: string): unknown;
    insertText(index: number, text: string, formats: Record<string, unknown>, source?: string): unknown;
    deleteText(index: number, length: number, source?: string): unknown;
    insertEmbed(index: number, type: string, value: unknown, source?: string): unknown;

    getSelection(focus?: boolean): { index: number; length: number } | null;
    setSelection(index: number, length?: number, source?: string): void;
    setSelection(range: { index: number; length: number } | null, source?: string): void;

    focus(): void;
    blur(): void;
    hasFocus(): boolean;

    enable(enabled?: boolean): void;
    disable(): void;

    getFormat(index?: number, length?: number): Record<string, unknown>;
    format(name: string, value: unknown, source?: string): unknown;
    formatLine(index: number, length: number, name: string, value: unknown, source?: string): unknown;
    formatText(index: number, length: number, name: string, value: unknown, source?: string): unknown;
    removeFormat(index: number, length: number, source?: string): unknown;

    getBounds(index: number, length?: number): { top: number; left: number; width: number; height: number } | null;
    getIndex(blot: unknown): number;
    getLeaf(index: number): [{ domNode: Node; [key: string]: unknown } | null, number];
    getLine(index: number): [unknown, number];
    getLines(index?: number, length?: number): unknown[];
    update(source?: string): void;
  }

  export default Quill;
}

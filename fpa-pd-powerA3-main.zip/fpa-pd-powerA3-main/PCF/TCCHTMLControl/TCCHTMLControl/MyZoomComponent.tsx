import React, { useEffect, useRef, useState } from 'react';
import { TransformWrapper, TransformComponent, ReactZoomPanPinchHandlers } from "react-zoom-pan-pinch";
import 'quill/dist/quill.snow.css';
import 'quill-table-up/index.css';
import 'quill-table-up/table-creator.css';

export default function MyZoomComponent(props: { htmltext: string, zoomcontrols: boolean, innerheight: number}) {
  if (props.zoomcontrols){
    return (
      <div className="ql-editor" style={{
              width: "100%",
              height: "auto",
              padding: "5px 12px !important",
              overflow: "visible",
              //border: "5px solid #0078d4",
              borderRadius: "0px",
              boxSizing: "border-box",
              //background: "#f3f2f1",
              textAlign: "left"

          }}
          >
          <TransformWrapper
            initialScale={1}
            minScale={0.5}
            maxScale={5}
            limitToBounds={false}
            wheel={{ wheelDisabled: true }} 
          >
            {({ zoomIn, zoomOut, resetTransform }: ReactZoomPanPinchHandlers) => (
              <>
                <div style={{ marginBottom: 8, marginLeft: 10, marginRight: 10, textAlign: "center" }}>
                  <button onClick={() => zoomIn()}>+</button>
                  <button style={{marginLeft: 5, marginRight: 5}}  onClick={() => zoomOut()}>−</button>
                  <button onClick={() => resetTransform()}>Reset</button>
                </div>
                <div style={{ 
                  width: "100%", 
                  height: "auto", 
                  borderRadius: '8px', 
                  //border: "5px solid orange" 
                }}>
                <TransformComponent wrapperStyle={{ 
                  width: "100%", 
                  height: "auto",  
                  //border: "5px solid purple",
                  display: "block",     // use flexbox
                  //justifyContent: "flex-start", // left-align content
                  //alignItems: "flex-start"
                  }} contentStyle={{ width: "100%", height: "auto" }}>
                  <div id="dvHTMLControlInner"
                    style={{
                      width: "100%",
                      minHeight: `${props.innerheight}px`,
                      overflow: "visible",
                      padding: "0px",
                      //border: "5px solid green",
                      boxSizing: "border-box",
                      //background: "#f3f2f1",
                    }}
                    contentEditable={false}
                    dangerouslySetInnerHTML={{ __html: props.htmltext }}
                  />
                </TransformComponent>
                </div>
              </>
            )}
          </TransformWrapper>
      </div>
    )
  } else {
    const safeHtml = props.htmltext.replace(/contenteditable\s*=\s*["']true["']/gi, 'contenteditable="false"').replace(/content-editable\s*=\s*["']true["']/gi, 'contenteditable="false"');
    return <div className="ql-editor" style={{
      width: "100%",
      height: "auto",
      overflow: "visible",
      padding: "5px 12px !important",
              //border: "5px solid #0078d4",
      borderRadius: "0px",
      boxSizing: "border-box",
      //background: "#f3f2f1",
      textAlign: "left"
      }}
      >
        <div
          style={{
          width: "100%",
          height: "auto",
          overflow: "visible",
          padding: "0px",
          //border: "5px solid green",
          boxSizing: "border-box",
          //background: "#f3f2f1",
          }}
          contentEditable={false}
          dangerouslySetInnerHTML={{ __html: safeHtml}}
        />
    </div>
  }
}

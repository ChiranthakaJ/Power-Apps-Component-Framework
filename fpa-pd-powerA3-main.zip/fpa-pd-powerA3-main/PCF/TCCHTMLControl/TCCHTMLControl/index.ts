import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom/client";
import MyZoomComponent from "./MyZoomComponent";

export class TCCHTMLControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    /**
     * Empty constructor.
     */

    private container: HTMLDivElement;
    private context: ComponentFramework.Context<IInputs>;
    private notifyOutputChanged: () => void;
    private currentHTML: string;
    private root: ReactDOM.Root;
    private zoomControls: boolean;
    private componentHeight: number = 0
    constructor() {
        // Empty
    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Add control initialization code
        this.context = context;
        this.container = container;
        this.notifyOutputChanged = notifyOutputChanged;

        this.context.mode.trackContainerResize(true);
        this._updateHTML(container, context);

        /*const resizeObserver = new ResizeObserver(() => {
            const newHeight = this.container.offsetHeight;
            if (newHeight !== this.componentHeight) {
                this.componentHeight = newHeight;
                this.notifyOutputChanged(); // trigger update
            }
        });
        resizeObserver.observe(container);
        this.notifyOutputChanged(); // trigger update*/

    }

    private _updateHTML(container: HTMLDivElement, context: ComponentFramework.Context<IInputs>){
        console.log("1.0.1")
        this.context = context;
        this.container = container;
        const html = (context.parameters.HTMLText.raw || "");
        const zoom: boolean = context.parameters.ShowZoomControls.raw; 
        const Innerheight: number = context.parameters.InnerHeight.raw || 0; 
        if (!this.root) {
          this.root = ReactDOM.createRoot(this.container);
        }
        this.root.render(MyZoomComponent({ htmltext: html, zoomcontrols: zoom, innerheight: Innerheight}));

        setTimeout(()=> this.measure(), 10);
    }

    private measure(){
        const newHeight = this.container.scrollHeight;
        if (newHeight !== this.componentHeight) {
            console.log(newHeight + " : " + this.componentHeight)    
            this.componentHeight = newHeight;
            this.notifyOutputChanged(); // trigger update
        }
    }
    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Add code to update control view
        this.context = context;
        const newHTML = context.parameters.HTMLText.raw || "";
        const zoom: boolean = context.parameters.ShowZoomControls.raw; 
        if (newHTML !== this.currentHTML || zoom !== this.zoomControls) {
            this._updateHTML(this.container, context);
            this.currentHTML = newHTML;
            this.zoomControls = zoom; 
        }   
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        return {
            ComponentHeight: this.componentHeight, 
            Version: "0.0.39"
        };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        if (this.root) {
            this.root.unmount();
        }
    }
}

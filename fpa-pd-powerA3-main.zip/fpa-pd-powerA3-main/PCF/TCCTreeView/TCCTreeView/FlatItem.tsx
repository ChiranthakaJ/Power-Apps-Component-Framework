interface FlatItem {
  ID: number;
  Title: string;
  ParentID: number | null;
  Level: number;
}
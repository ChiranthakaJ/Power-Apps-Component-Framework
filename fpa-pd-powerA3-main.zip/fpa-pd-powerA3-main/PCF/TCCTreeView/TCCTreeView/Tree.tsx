import * as React from "react";
import { TreeNode } from "./TreeContainer";
import "./css/TCCTreeView.css";

interface Props {
  nodes: TreeNode[];
  selected: string[];//Set<string>;
  onToggle: (node: TreeNode) => void;
  searchmode: boolean;
}

export const Tree: React.FC<Props> = ({
  nodes,
  selected,
  onToggle, 
  searchmode
}) => {
   
  const buildParentMap = (
    nodes: TreeNode[],
    parentId: string | null = null,
    map = new Map<string, string | null>()
  ): Map<string, string | null> => {
    for (const node of nodes) {
      map.set(node.id, parentId);

      if (node.children?.length) {
        buildParentMap(node.children, node.id, map);
      }
    }
    return map;
  };

  const buildExpandedFromSelection = (
    ids: string[],
    parentMap: Map<string, string | null>
  ) => {
    const expanded = new Set<string>();
    ids.forEach(id => {
      console.log(id);
      let parent = parentMap.get(id);
      while (parent) {
        expanded.add(parent);
        parent = parentMap.get(parent) ?? null;
      }
    });
    return expanded;
  };
  
  console.log(selected);

  const parentMap = React.useMemo(() => buildParentMap(nodes), [nodes]);
  const [expanded, setExpanded] = React.useState<Set<string>>(
    () => buildExpandedFromSelection(selected, parentMap)
  );

  React.useEffect(() => {
  if (!selected || selected.length === 0) return;

  const expandedFromSelection = buildExpandedFromSelection(selected, parentMap);
  setExpanded(expandedFromSelection);

}, [selected, parentMap]);

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };
  return (
   <ul className="tree">
  {nodes.map((node) => {
    const isExpanded = searchmode ? true : expanded.has(node.id);

    return (
      <li key={node.id}>
        <div className="tree-node">

          {node.children && node.children?.length > 0 && (
            <span
              onClick={() => toggleExpand(node.id)}
              style={{
                cursor: "pointer",
                width: "16px",
                display: "inline-block"
              }}
            >
            {isExpanded ? "▼" : "▶"}
            </span>
          )}
          {node.children && node.children?.length == 0 && (
            <span>{"   "}</span>
          )}
          <input
            style={{ width: "40px" }}
            type="checkbox"
            checked={selected.includes(node.id)}
            onChange={() => onToggle(node)}
          />

          <span className="tree-label">{node.label}</span>
        </div>

        {node.children && (
          <div
            style={{
              display: isExpanded ? "block" : "none"
            }}
          >
            <Tree
              nodes={node.children}
              selected={selected}
              onToggle={onToggle} 
              searchmode={searchmode}
            />
          </div>
        )}
      </li>
    );
  })}
</ul>
  );
};
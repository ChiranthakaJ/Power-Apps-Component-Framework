import * as React from "react";
import { Tree } from "./Tree";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSave, faTrashAlt, } from '@fortawesome/free-regular-svg-icons';
import "./css/TCCTreeView.css";
import "./FlatItem"
export interface TreeNode {
  id: string;
  label: string;
  children?: TreeNode[];
  parentId?: string | null;
  level?: number;
}

interface Props {
  nodes: FlatItem[];
  singlemode: boolean;
  externalSelected: string[];
  onSelectionChange: (ids: string[], titles: string) => void;
}

export const TreeContainer: React.FC<Props> = ({
  nodes,
  singlemode,
  externalSelected,
  onSelectionChange
}) => {
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [selectedTitles, setSelectedTitles] = React.useState<string>("");
  const [original, setOriginal] = React.useState<Set<string>>(new Set());
  const [changed, setChanged] = React.useState<boolean>(false);

  const [searchText, setSearchText] = React.useState("");
  React.useEffect(() => {
    setSelected(new Set(externalSelected));
    setOriginal(new Set(externalSelected));
  }, [externalSelected]);

  const hierarchy = buildHierarchy(nodes);
  const { filteredTree, expandedIds } = React.useMemo(() => {
    const expanded = new Set<string>();

    const filtered = filterTreeWithExpansion(hierarchy, searchText, expanded);

    return {
      filteredTree: filtered,
      expandedIds: expanded
    };
  }, [hierarchy, searchText]);

  function buildHierarchy(data: FlatItem[]): TreeNode[] {
    const map = new Map<number, TreeNode>();
    const roots: TreeNode[] = [];
    // Step 1: Create all nodes
    data.forEach(item => {
      map.set(item.ID, {
        id: item.ID.toString(),
        label: item.Title,
        children: [], 
        parentId: item.ParentID?.toString(), 
        level: item.Level
      });
    });

    // Step 2: Link parent-child
    data.forEach(item => {
      const node = map.get(item.ID)!;
      if (item.ParentID === null) {
        roots.push(node);
      } else {
        const parent = map.get(item.ParentID);
        if (parent) {
          parent.children?.push(node);
        }
      }
    });

    return roots;
  }

  const buildParentMap = (nodes: TreeNode[], parentId: string | null = null, map = new Map<string, string | null>()): Map<string, string | null> => {
    for (const node of nodes) {
      map.set(node.id, parentId);
      if (node.children) {
        buildParentMap(node.children, node.id, map);
      }
    }
    return map;
  };
  const parentMap = React.useMemo(() => buildParentMap(hierarchy), [nodes]);

  const buildChildrenMap = (nodes: TreeNode[], map = new Map<string, string[]>()) => {
    for (const node of nodes) {
      if (node.children) {
        map.set(node.id, node.children.map(c => c.id));
        buildChildrenMap(node.children, map);
      } else {
        map.set(node.id, []);
      }
    }
    return map;
  };

  const buildNodeMap = (nodes: TreeNode[],map = new Map<string, TreeNode>()): Map<string, TreeNode> => {
    for (const node of nodes) {
      map.set(node.id, node);
      if (node.children && node.children.length > 0) {
        buildNodeMap(node.children, map);
      }
    }
    return map;
  };

  const childrenMap = React.useMemo(() => buildChildrenMap(hierarchy), [nodes]);
  const nodeMap = React.useMemo(
    () => buildNodeMap(hierarchy),
    [hierarchy]
  );
  
  function filterTreeWithExpansion(
    nodes: TreeNode[],
    search: string,
    expanded: Set<string>
  ): TreeNode[] {

    if (!search) return nodes;

    const lowerSearch = search.toLowerCase();

    return nodes
      .map(node => {
        const filteredChildren = node.children
          ? filterTreeWithExpansion(node.children, search, expanded)
          : [];

        const matches = node.label.toLowerCase().includes(lowerSearch);

        if (matches || filteredChildren.length > 0) {
          // expand parent if a child matched
          if (filteredChildren.length > 0) {
            expanded.add(node.id);
          }

          return {
            ...node,
            children: filteredChildren
          };
        }

        return null;
      })
      .filter(Boolean) as TreeNode[];
  }

  const toggle = (node: TreeNode) => {
    console.log("in toggle");
    setSelected(prevSelected => {
      const updated = new Set(prevSelected); // copy previous state

      if (updated.has(node.id)) {
        // Node is currently selected → deselect
        if (singlemode) {
          updated.clear();
        } else {
          // Deselect this node and all children recursively
          const stack = [node.id];
          while (stack.length > 0) {
            const current = stack.pop()!;
            updated.delete(current);

            const children = childrenMap.get(current) || [];
            stack.push(...children);
          }
        }
      } else {
        // Node is not selected → select
        if (singlemode) {
          updated.clear();
          updated.add(node.id);
        } else {
          updated.add(node.id);

          // Bubble up to parents
          let parentId = parentMap.get(node.id);
          while (parentId) {
            updated.add(parentId);
            parentId = parentMap.get(parentId);
          }
        }
      }

      const filtered = Array.from(updated).filter(id => {
        const children = childrenMap.get(id) || [];
        return !children.some(childId => updated.has(childId));
      });

      // Update other state values based on the new selection
      const selectedPathsString = Array.from(filtered)
        .map(id => getFullPath(id))
        .join(","); // comma-delimited string

      setChanged(false);
      setSelectedTitles(selectedPathsString);
      // Fire callback with IDs and string if needed
      onSelectionChange(Array.from(updated), selectedPathsString);
      return updated; // return updated Set to actually update React state
    });
  };

  const getFullPath = (nodeId: string): string => {
    const path: string[] = [];
    let currentId: string | null | undefined = nodeId;
    while (currentId) {
      const node = nodeMap.get(currentId);
      if (!node) break;
      path.unshift(node.label); // add to start
      currentId = parentMap.get(currentId);
    }
    return path.join(" -> ");
  } ;

  const saveTree = () => {
    const updated = new Set(selected);
    setChanged(false);
    onSelectionChange(Array.from(updated), selectedTitles);
  };

  const resetTree = () => {
    setSelected(new Set(original));
    setChanged(false);
  };

  return (
    <div style={{ fontFamily: "Segoe UI", fontSize: 14 }}>
       {(changed) && (
        <div>
        <div style={{width:"auto", textAlign:"center", alignContent: "center"}}>
          <div style={{width:"450px"}}>
            <div className="qe-item" style={{float:"left", paddingTop: "2px"}}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                saveTree()
              }} 
            >
            <FontAwesomeIcon 
              icon={faSave} 
              style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
              &nbsp; Save
            </div>
            <div className="qe-item" style={{float:"left", paddingTop: "2px"}}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                resetTree();
              }} 
              >
              <FontAwesomeIcon 
                icon={faTrashAlt} 
                style={{ color: 'gray', pointerEvents: "auto", cursor: "pointer"  }} />
                &nbsp; Reset
            </div>   
          </div>   
        </div>
        <div><hr style={{border: "2px solid lightgray"}}></hr></div> 
        </div>    
      )}
      <div style={{fontSize:"12px", width: "80%", paddingLeft: "15px"}}>
        <input
          className="inputSearch"
          type="text"
          placeholder="Search..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />
      </div>
      <div>
        <Tree 
          nodes={filteredTree} 
          selected={Array.from(selected)} 
          onToggle={toggle}
          searchmode = {searchText.trim().length > 0}
          />
      </div>
    </div>
  );
};
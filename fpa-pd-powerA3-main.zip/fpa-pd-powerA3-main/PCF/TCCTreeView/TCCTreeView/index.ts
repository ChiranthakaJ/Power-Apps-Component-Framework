import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom/client";
import { TreeContainer } from "./TreeContainer";
import "./FlatItem"

export class TCCTreeView implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    /**
     * Empty constructor.
     */
    constructor() {
        // Empty
    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    private container: HTMLDivElement;
    private notifyOutputChanged!: () => void;
    private selectedJson: string = "[]";
    private selectedJsonTitles: string;
    private root!: ReactDOM.Root;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Add control initialization code
        this.container = container;
        this.notifyOutputChanged = notifyOutputChanged;
        this.root = ReactDOM.createRoot(container);
    }


    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Add code to update control view
        console.log("1.0.0.4");
        const raw = context.parameters.HierarchyJson.raw;
        const selectedRaw = context.parameters.SelectedItemsInputJson.raw;
        const singleModeRaw = context.parameters.SingleMode.raw;
        //console.log(singleModeRaw);
        let selected: string[] = [];
        let hierarchy: FlatItem[] = [];

        try {
            hierarchy = raw ? (JSON.parse(raw) as FlatItem[]) : [];
        } catch {
            hierarchy = [];
        }
        try {
            selected = selectedRaw ? JSON.parse(selectedRaw) : [];
        } catch {
            console.log("Error")
        }
        this.root.render(
            React.createElement(TreeContainer, {
                nodes: hierarchy,
                singlemode: singleModeRaw,
                externalSelected: selected,
                onSelectionChange: this.onSelectionChange
            })
        );
    }
    private onSelectionChange = (selectedIds: string[], selectedIdsTitles: string) => {
        this.selectedJson = JSON.stringify(selectedIds);
        this.selectedJsonTitles = selectedIdsTitles;
        this.notifyOutputChanged();
    };
    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        return {
            SelectedItemsJson: this.selectedJson,
            SelectedItemsJsonTitles: this.selectedJsonTitles
        };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        // Add code to cleanup control if necessary
        this.root.unmount();
    }
}

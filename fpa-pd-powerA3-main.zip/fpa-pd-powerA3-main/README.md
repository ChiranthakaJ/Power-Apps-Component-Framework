# PowerA3 — Power Apps A3 Planning Tool

A Power Apps solution built at Fisher & Paykel for A3 problem-solving and K-Brief management. The project consists of four **PCF (Power Apps Component Framework)** custom controls and a set of **PowerShell migration scripts** for moving legacy TCC data into SharePoint.

---

## Repository Structure

```
PowerA3/
├── PCF/
│   ├── TCCA3View/          # A3 card view — rich text, drag-drop, AI assistant
│   ├── TCCTreeView/        # Hierarchical tree selector
│   ├── TCCHTMLControl/     # HTML viewer with zoom/pan/pinch
│   └── AnnotateAnImage/    # Image annotation with marker.js
└── Scripts/
    ├── config.example.ps1  # Configuration template (copy → config.ps1)
    ├── config.ps1          # ⚠️ Gitignored — fill in your credentials locally
    ├── README.md           # Scripts setup and usage docs
    ├── Migration/          # SQL → SharePoint K-Brief migration scripts
    ├── DesignStandardisation/ # Windchill → SharePoint document migration
    └── Certificates/       # ⚠️ Gitignored — cert files stored locally only
```

---

## PCF Controls

Each control lives in its own folder under `PCF/` and is an independent npm project.

### TCCA3View — A3 Card View
> `PCF/TCCA3View/`

The primary control for Power Apps. Renders a configurable grid of A3 cards with rich text editing (Quill), drag-and-drop reordering, and an AI assistant dialog.

**Inputs (from Power Apps):**

| Property | Type | Description |
|---|---|---|
| `items` | Text (JSON) | Array of `CardItem` objects to display |
| `settings` | Text (JSON) | `CardSettings` object controlling display & features |

**Outputs (to Power Apps):**

| Property | Type | Description |
|---|---|---|
| `itemsOut` | Text (JSON) | Updated array of cards after edits |
| `actionValue` | Text | Last user action (e.g. `"Edit"`, `"Delete"`) |
| `selectedBlockID` | Text | ID of the card the action was performed on |
| `IsDirty` | Boolean | Whether unsaved changes exist |
| `Value` | Text | Timestamp signal — use in Power Apps `OnChange` to detect events |

**CardItem JSON shape:**
```json
{
  "ID": 1,
  "Title": "Card Title",
  "Explanation": "<p>Rich HTML content</p>",
  "ExplanationStakeholder": "<p>Stakeholder notes</p>",
  "ExplanationChecklist": "<p>Checklist content</p>",
  "Hidden": false,
  "A3Hidden": false,
  "Sequence": 1
}
```

**CardSettings JSON shape:**
```json
{
  "canedit": true,
  "a3mode": false,
  "defaultcolumns": 3,
  "fontsize": 14,
  "showai": true,
  "aiurl": "https://your-openai-endpoint/v1/chat/completions",
  "aikey": "your-api-key",
  "aimodel": "gpt-4o",
  "aioptions": "Summarise,Improve,Translate",
  "uploadurl": "https://your-upload-endpoint",
  "dragdropvisible": true,
  "quickeditvisible": true,
  "showbold": true,
  "showitalic": true,
  "showimage": true,
  "showtable": true
}
```

---

### TCCTreeView — Hierarchy Tree Selector
> `PCF/TCCTreeView/`

Renders a collapsible tree from a flat JSON array with parent–child relationships. Supports single and multi-select modes.

**Inputs:**

| Property | Type | Description |
|---|---|---|
| `HierarchyJson` | Text (JSON) | Flat array of `FlatItem` nodes |
| `SelectedItemsInputJson` | Text (JSON) | Array of pre-selected item IDs |
| `SingleMode` | Boolean | If true, only one item can be selected at a time |

**Outputs:**

| Property | Type | Description |
|---|---|---|
| `SelectedItemsJson` | Text (JSON) | Array of selected item IDs |
| `SelectedItemsJsonTitles` | Text | Comma-separated titles of selected items |

**FlatItem JSON shape:**
```json
[
  { "id": "1", "title": "Parent", "parentId": null },
  { "id": "2", "title": "Child",  "parentId": "1" }
]
```

---

### TCCHTMLControl — HTML Viewer with Zoom
> `PCF/TCCHTMLControl/`

Renders HTML content safely inside Power Apps with optional zoom/pan controls. Outputs its own rendered height so the Power Apps container can resize automatically.

**Inputs:**

| Property | Type | Description |
|---|---|---|
| `HTMLText` | Text (Multiline) | HTML string to render |
| `ShowZoomControls` | Boolean | Show/hide zoom in/out controls |
| `InnerHeight` | Decimal | Override inner scroll height |

**Outputs:**

| Property | Type | Description |
|---|---|---|
| `ComponentHeight` | Decimal | Actual rendered height (use to resize the container) |
| `Version` | Text | Current control version |

---

### AnnotateAnImage — Image Annotation
> `PCF/AnnotateAnImage/`

Allows users to paste or load an image and annotate it using [marker.js](https://markerjs.com/). Saves annotation state so it can be restored.

**Inputs:**

| Property | Type | Description |
|---|---|---|
| `AnnotatedImage` | Text | Base64 data URL of the image to annotate |
| `RestoredState` | Text (JSON) | Previously saved annotation state (from `EditorState`) |
| `ResetSignal` | Boolean | Toggle to reset the control |
| `AllowPaste` | Boolean | If true, shows a paste area instead of loading an image |

**Outputs:**

| Property | Type | Description |
|---|---|---|
| `RasterizedImage` | Text | Base64 image with annotations flattened |
| `EditorState` | Text (JSON) | Annotation state to save for later restoration |
| `EventType` | Text | `"Save"`, `"Close"`, or `"Failed"` |
| `PastedImage` | Text | Base64 of the pasted image (before annotation) |

---

## Building & Deploying PCF Controls

### Prerequisites
- [Node.js](https://nodejs.org/) v18+
- [pnpm](https://pnpm.io/): `npm install -g pnpm`
- [Power Platform CLI](https://learn.microsoft.com/en-us/power-platform/developer/cli/introduction): `winget install Microsoft.PowerAppsCLI`

### Build a control
```powershell
cd PCF\TCCA3View
pnpm install
pnpm run build
```

### Test locally in browser
```powershell
pnpm run start
```

### Deploy to Power Apps environment
```powershell
# Push directly to a Dataverse environment
pac pcf push --publisher-prefix EZYAPPS
```

Or build the managed solution zip and import via Power Apps admin portal:
```powershell
cd PCF\TCCA3View\solution
dotnet build --configuration Release
# Output: solution/bin/Release/TCCTreeView.zip → import in make.powerapps.com
```

---

## Migration Scripts

See [`Scripts/README.md`](Scripts/README.md) for full setup and usage instructions.

**Quick start:**
```powershell
# 1. Set up credentials
Copy-Item Scripts\config.example.ps1 Scripts\config.ps1
# Edit Scripts\config.ps1 with real values

# 2. Test SharePoint connection
.\Scripts\Certificates\TestConnection.ps1

# 3. Run K-Brief migration
.\Scripts\Migration\ConnectSQLAttachments.ps1
```

---

## Security

- **No credentials are stored in this repository.**
- All secrets (SQL passwords, certificate passwords, Azure App Client IDs) live in `Scripts/config.ps1` which is excluded from source control.
- Certificate files (`.pfx`, `.cer`) are also excluded — store them in Azure Key Vault or a secure local path.
- See `Scripts/config.example.ps1` for the full list of required configuration values.

> ⚠️ If you need to rotate credentials, update `Scripts/config.ps1` locally and in your team's secure credential store. Do **not** commit `config.ps1`.

---

## Known Issues / Outstanding Items

### Security
- [ ] **XSS**: `dangerouslySetInnerHTML` in `TCCA3View` renders unsanitised user HTML — add [DOMPurify](https://github.com/cure53/DOMPurify) sanitisation before production use (`CardEditor.tsx`, `DragCardList.tsx`)
- [ ] **Quill XSS (low/moderate — no upstream fix available)**: `react-quill@2.0.0 > quill@1.3.7` (GHSA-4943-9vgg-gr5r) and `@mouseoverllc/quill-image-resizer > quill@2.0.3` (GHSA-v3m3-f69x-jf25) both have `Patched versions: <0.0.0`. The quill maintainers have not released a fix. Monitor [quill releases](https://github.com/quilljs/quill/releases).
- ℹ️ **Dependabot alerts**: All remaining alerts are in Microsoft's `pcf-scripts`/`pcf-start` **build toolchain** (devDependencies). These packages (`flatted`, `immutable`, `preact`, `serialize-javascript`, etc.) are not bundled into the compiled `.pcf` output and do not run inside Power Apps. They are development-only build tools maintained by Microsoft. Track the upstream fix via [microsoft/powerplatform-cli-wrapper](https://github.com/microsoft/powerplatform-cli-wrapper).

### Code
- [ ] `TCCTreeView/package.json` is missing an explicit `react` dependency entry
- [ ] React version mismatch: `TCCA3View` uses React 18, other controls use React 19 — standardise before deploying together
- [ ] Event listeners in `CardEditor.tsx` are not cleaned up on unmount (memory leak)
- [ ] AI endpoint config (`aiurl`, `aikey`) is passed from Power Apps — store in Power Apps environment variables, not hardcoded in canvas formulas
- [ ] `CardItem` and `CardSettings` use global ambient interfaces (side-effect imports) — refactor to use proper `export interface`

---

## Maintainers

Fisher & Paykel Product Development team  
Originally developed by **EzyApps** (external vendor)

﻿# -------------------------------
# CONFIGURATION
# -------------------------------
cls

$UPLOADDOCUMENT = $true

# Mapping: Windchill DOCPROPERTY -> SharePoint Quick Part
$propertyMap = @{
    "Document number" = @{
        Alias = "DocumentNumber"
        Tag = "DocumentNumber"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:DocumentNumber[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "Created By" = @{
        Alias = "CreatedByText"
        Tag = "CreatedByText"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:CreatedByText[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "Created On" = @{
        Alias = "CreatedDateText"
        Tag = "CreatedDateText"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:CreatedDateText[1"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "lifeCycleState" = @{
        Alias = "Status"
        Tag = "Status"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Status[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "RevisionInfo" = @{
        Alias = "Version"
        Tag = "Version"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Version[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}" 
    }
    "IBA|FunctionalTeam" = @{
        Alias = "FunctionalTeam"
        Tag = "FunctionalTeam"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:FunctionalTeam[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}" 
    }
    "IBA|ProductDTI" = @{
        Alias = "ProductGroup"
        Tag = "ProductGroup"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:ProductGroup[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|PlatformDTI" = @{
        Alias = "Platform"
        Tag = "Platform"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Platform[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}" 
    }
    "IBA|SubsystemDTI" = @{
        Alias = "Sub System"
        Tag = "SubSystem"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Sub_x0020_System[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|ComponentDTI" = @{
        Alias = "Component"
        Tag = "Component"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Component[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|KeywordsDTI" = @{
        Alias = "Keywords"
        Tag = "Keywords"
        XPath = "/ns1:coreProperties[1]/ns1:keywords[1]"
        StoreItemID = "{6C3C8BC8-F283-45AE-878A-BAB7291924A1}"
    }
    "IBA|Superseded" = @{
        Alias = "Superseded"
        Tag = "Superseded"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Superseded[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|ApprovedDate" = @{
        Alias = "RevisionDate"
        Tag = "RevisionDate"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:RevisionDate[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}" 
    }
    "IBA|CheckerDTI" = @{
        Alias = "Checker"
        Tag = "Checker"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Checker[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|ReviewerDTI" = @{
        Alias = "Reviewer"
        Tag = "Reviewer"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Reviewer[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}" 
    }
    "IBA|ApproverDTI" = @{
        Alias = "Approver"
        Tag = "Approver"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Approver[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|RevisionLong" = @{ #CHANGE TO REVISION LONG
        Alias = "Revision Long"
        Tag = "RevisionLong"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Revision_x0020_Long[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|RevisionShort" = @{ #CHANGE TO REVISION LONG
        Alias = "Revision Short"
        Tag = "RevisionShort"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Revision_x0020_Short[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "IBA|StandardsDTI" = @{ 
        Alias = "Standards"
        Tag = "Standards"
        XPath = "/ns0:properties[1]/documentManagement[1]/ns3:Standards[1]"
        StoreItemID = "{C0F8A192-6DC1-4972-AF3F-E15EF0B5FB3F}"
    }
    "wtname" = @{
        Alias = "Title"
        Tag = "Title"
        XPath = "/ns1:coreProperties[1]/ns0:title[1]"
        StoreItemID = "{6C3C8BC8-F283-45AE-878A-BAB7291924A1}" 
    }
}


$libDocuments = "Document Management"

# Load configuration from config.ps1 (excluded from source control)
$configPath = Join-Path $PSScriptRoot "..\..\config.ps1"
if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: config.ps1 not found. Copy Scripts/config.example.ps1 to Scripts/config.ps1 and fill in your values." -ForegroundColor Red
    exit 1
}
. $configPath

$idtoReplace = "19a216de-85a3-4bc2-b841-ff37fa6eb57a" # NOTE: This ID changes per SharePoint site

if ($environment -eq "DEV") {
    $siteURL = "https://fisherpaykel.sharepoint.com/sites/app-tcc-dev"
} elseif ($environment -eq "UAT") {
    $siteURL = "https://fisherpaykel.sharepoint.com/sites/app-tcc-uat"
} else {
    $siteURL = "https://fisherpaykel.sharepoint.com/sites/app_powera3"
}

$connection = Connect-PnPOnline -Url $siteURL -ClientId $clientID -Thumbprint $thumbprint -Tenant $tenantName -ReturnConnection -WarningAction Ignore

$rootFolder = Join-Path $PSScriptRoot "WindchillDocuments"
$docxFiles = Get-ChildItem -Path $rootFolder -Filter *.docx -File | Where-Object { $_.Name -notmatch "_PROCESSED_" }
$docxPath = ""


foreach ($file in $docxFiles) {
    
    $docxPath = $file.FullName
    $tempDir = "$($file.Directory)\Unzip"
    $rand = Get-Random -Minimum 1000 -Maximum 9999
    $fileNameParsed = $file.Name.Replace(".docx", "_PROCESSED_$rand.docx")
    $fileNameRaw = $file.Name


    $docxPathParsed = $file.Directory.ToString() + "\" +  $fileNameParsed
    Write-Host "File: " $file.FullName $tempDir $docxPathParsed -ForegroundColor Green
    # -------------------------------
    # PREPARE DOCUMENT
    # -------------------------------
    # Ensure temp directory exists
    if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
    New-Item -ItemType Directory -Path $tempDir | Out-Null

    # Copy DOCX and unzip
    $zipPath = Join-Path $tempDir "doc.zip"

    Copy-Item $docxPath $zipPath
    Expand-Archive $zipPath $tempDir

    # Load document.xml
    $docXmlPath = Join-Path $tempDir "word\document.xml"
    [xml]$docXml = Get-Content $docXmlPath

    # Namespace manager
    $ns = New-Object System.Xml.XmlNamespaceManager($docXml.NameTable)
    $ns.AddNamespace("w","http://schemas.openxmlformats.org/wordprocessingml/2006/main")

    # -------------------------------
    # PROCESS DOCPROPERTY FIELDS
    # -------------------------------

    $multiArray = @()

    foreach ($oldProp in $propertyMap.Keys) {
        
        $mapping = $propertyMap[$oldProp]
        # Find all <w:instrText> nodes containing the Windchill property
        $nodes = $docXml.SelectNodes("//w:instrText[contains(text(), '$($oldProp)')]", $ns)
        Write-Host "Found " $nodes.Count " for " $oldProp
        #if ($nodes.Count -eq 0){
        #    $nodes = $docXml.SelectNodes("//*[local-name()='fldSimple']")
        #    foreach ($node in $nodes){
        #        Write-Host $node -ForegroundColor Cyan
        #    }
        #    Write-Host $nodes.Count -ForegroundColor Cyan
        #}
        
        foreach ($instr in $nodes) {
            $rNode = $instr.ParentNode   # usually <w:r>
            $fldBegin = $instr.ParentNode.PreviousSibling   # usually <w:r><w:fldChar w:fldCharType="begin"/></w:r>
            $fldEnd   = $instr.ParentNode.NextSibling.NextSibling  # usually <w:r><w:fldChar w:fldCharType="end"/></w:r>
            $runsToReplace = @($fldBegin, $instr.ParentNode, $fldEnd)

            $rInstr = $instr.ParentNode
            $nextRun = $rInstr.NextSibling
            $existingValue = ""

            while ($nextRun -ne $null) {
                $tNode = $nextRun.SelectSingleNode("w:t", $ns)
                if ($tNode -ne $null -and $tNode.InnerText -ne "") {
                    $existingValue = $tNode.InnerText
                    break
                }
                $nextRun = $nextRun.NextSibling
            }

            $value = [PSCustomObject]@{
                        Name = $oldProp
                        Value = $existingValue 
            }

            if (!$multiArray.Contains($value)){
                $multiArray += $value
            }

            Write-Host $oldprop " : " $existingValue  -ForegroundColor Green
            $propertyMap[$oldProp].Value = $existingValue

            # Create <w:sdt> element
            $sdt = $docXml.CreateElement("w:sdt", $ns.LookupNamespace("w"))

            # <w:sdtPr>
            $sdtPr = $docXml.CreateElement("w:sdtPr", $ns.LookupNamespace("w"))

            # <w:alias w:val="..."/>
            $alias = $docXml.CreateElement("w:alias", $ns.LookupNamespace("w"))
            $alias.SetAttribute("val", $ns.LookupNamespace("w"), $mapping.Alias)
            $sdtPr.AppendChild($alias)

            # <w:tag w:val="..."/>
            $tag = $docXml.CreateElement("w:tag", $ns.LookupNamespace("w"))
            $tag.SetAttribute("val", $ns.LookupNamespace("w"), $mapping.Tag)
            $sdtPr.AppendChild($tag)

            # <w:dataBinding w:xpath=... w:storeItemID=.../>
            $dataBinding = $docXml.CreateElement("w:dataBinding", $ns.LookupNamespace("w"))
            $dataBinding.SetAttribute("prefixMappings", $ns.LookupNamespace("w"), "xmlns:ns0='http://schemas.microsoft.com/office/2006/metadata/properties' xmlns:ns3='$($idtoReplace)'")
            $dataBinding.SetAttribute("xpath", $ns.LookupNamespace("w"), $mapping.XPath)
            $dataBinding.SetAttribute("storeItemID", $ns.LookupNamespace("w"), $mapping.StoreItemID)
            $sdtPr.AppendChild($dataBinding)

            $sdt.AppendChild($sdtPr)

            $sdtContent = $docXml.CreateElement("w:sdtContent", $ns.LookupNamespace("w"))
            $rNew = $docXml.CreateElement("w:r", $ns.LookupNamespace("w"))
            $rPr = $docXml.CreateElement("w:rPr", $ns.LookupNamespace("w"))
            $b = $docXml.CreateElement("w:b", $ns.LookupNamespace("w"))  # Bold
            $rPr.AppendChild($b)
            $rNew.AppendChild($rPr)

            $t = $docXml.CreateElement("w:t", $ns.LookupNamespace("w"))
            $t.InnerText = if ($existingValue -ne "") { $existingValue } else { "Document Number" }  # default text
            $rNew.AppendChild($t)
            $sdtContent.AppendChild($rNew)
            $sdt.AppendChild($sdtContent)

            $parent = $fldBegin.ParentNode
            foreach ($run in $runsToReplace) {
                try{
                    $parent.RemoveChild($run)
                } catch{}
            }
            $parent.AppendChild($sdt)
        }
    }

    # -------------------------------
    # SAVE CHANGES
    # -------------------------------
    $docXml.Save($docXmlPath)

    # Re-zip to DOCX
    Remove-Item $zipPath -Force
    Compress-Archive "$tempDir\*" $zipPath
    Copy-Item $zipPath $docxPathParsed -Force

    $docNo = $multiArray | Where-Object { $_.Name -eq "Document number" }
    $createdby = $multiArray | Where-Object { $_.Name -eq "Created by" }
    $createdon = $multiArray | Where-Object { $_.Name -eq "Created On" }
    $status = $multiArray | Where-Object { $_.Name -eq "lifeCycleState" }
    $version = $multiArray | Where-Object { $_.Name -eq "RevisionInfo" }
    $functionalteam = $multiArray | Where-Object { $_.Name -eq "IBA|FunctionalTeam" }
    $product = $multiArray | Where-Object { $_.Name -eq "IBA|ProductDTI" }
    $platform = $multiArray | Where-Object { $_.Name -eq "IBA|PlatformDTI" }
    $subsystem = $multiArray | Where-Object { $_.Name -eq "IBA|SubsystemDTI" }
    $component = $multiArray | Where-Object { $_.Name -eq "IBA|ComponentDTI" }
    $superseded = $multiArray | Where-Object { $_.Name -eq "IBA|Superseded" }
    $revisiondate = $multiArray | Where-Object { $_.Name -eq "IBA|ApprovedDate" }
    $checker = $multiArray | Where-Object { $_.Name -eq "IBA|CheckerDTI" }
    $reviewer = $multiArray | Where-Object { $_.Name -eq "IBA|ReviewerDTI" }
    $approver = $multiArray | Where-Object { $_.Name -eq "IBA|ApproverDTI" }
    $revisionlong = $multiArray | Where-Object { $_.Name -eq "IBA|RevisionLong" }
    $revisionshort = $multiArray | Where-Object { $_.Name -eq "IBA|RevisionShort" }
    $title = $multiArray | Where-Object { $_.Name -eq "wtname" }
    $keywords = $multiArray | Where-Object { $_.Name -eq "IBA|KeywordsDTI" }
    $standards = $multiArray | Where-Object { $_.Name -eq "IBA|StandardsDTI" }

    $revisiontext = ""
    if ($revisionlong.Value -eq $null){
        $revisiontext = $revisionshort.Value
    } else {
        $revisiontext = $revisionlong.Value
    }

    $titleval = ""
    if ($title.Count -gt 1){
        $titleval = $title[0].Value 
    } else {
        $titleval = $title.Value
    }
    $metadata = @{
        "DocumentNumber" = $docNo.Value
        "DocumentType" = "Design Guide"
        "Document_x0020_SubType" = "Design Guide Template"
        "CreatedByText" = $createdby.Value
        "CreatedDateText" = $createdon.Value
        "Status" = $status.Value
        "State" = $status.Value
        "Version" = $version.Value
        "FunctionalTeam" = $functionalteam.Value
        "ProductGroup" = $product.Value
        "Platform" = $platform.Value
        "Sub_x0020_System" = $subsystem.Value
        "Component" = $component.Value
        "Superseded" = $superseded.Value
        "Checker" = $checker.Value
        "Reviewer" = $reviewer.Value
        "Approver" = $approver.Value
        "RevisionDate" = $revisiondate.Value
        "Revision_x0020_Long" = $revisiontext
        "Revision_x0020_Short" = $revisionshort.Value
        "Title" = $titleval
        "Keywords" = $keywords.Value
        "Standards" = $standards.Value
    }

    #Write-Host ($metadata | ConvertTo-Json)
    
    if($UPLOADDOCUMENT){
        if (Test-Path $docxPath){
           $file = Add-PnPFile -Path $docxPathParsed `
                -Folder $libDocuments `
                -CheckInComment $checkInComment `
                -ContentType "Design Guide Template" `
                -Values $metadata `
                -Connection $connection -NewFileName  $fileNameRaw
            if ($file){
                Set-PnPFileCheckedIn `
                -Url $file.ServerRelativeUrl `
                -CheckinType MajorCheckIn `
                -Comment "Uploaded by PnP script" `
                -Connection $connection
                $listItem = Get-PnPFile -Url $file.ServerRelativeUrl -AsListItem -Connection $connection
                Write-Host $listItem.Id
            }
        }
    }
    # Cleanup
    Remove-Item $tempDir -Recurse -Force

    Write-Host "All Windchill DOCPROPERTY fields replaced with SharePoint Quick Parts successfully! for " $file.FullName

}



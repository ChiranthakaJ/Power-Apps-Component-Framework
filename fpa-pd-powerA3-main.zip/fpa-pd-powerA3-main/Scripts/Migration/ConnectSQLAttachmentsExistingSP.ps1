﻿Import-Module PnP.PowerShell

. "$PSScriptRoot\Functions.ps1"
. "$PSScriptRoot\ProcessKBriefs.ps1"


$KBRIEF_DEBUG = 0 # 193745 #187075 #187075
$KBRIEF_DEBUG_MAX = 0 #187094
$KBRIEF_BLOCK_DEBUG = 0 #431076 #433776

$KBRIEF_SP_DEBUG_START = 180000
$KBRIEF_SP_DEBUG_END = 190000


#138
#202509221019

$RUNBLOCKS = $true
$PROJECTTYPE = "'project'"
$TOP = 500
$REPROCESS = $true
$REPROCESSBLOCK = $true
$DELETEBLOCKS = $true
$REMOVEFILES = $true
$ROWLIMIT = 5
$WORDMAX = 50

#189891 FAILED 5847 or 5893

$camlQuery = "<View>
      <Query>
        <OrderBy>
          <FieldRef Name='TCC_ID' Ascending='TRUE' />
        </OrderBy>
        <Where>
            <Eq>
                <FieldRef Name='TCC_ID' />
                <Value Type='Text'>101729</Value>
            </Eq>
        </Where>
      </Query>
      <RowLimit Paged='TRUE'>1000</RowLimit></View>"

      #104328 #START FROM "HERE

$items = Get-PnPListItem -List $listKBrief -PageSize 1000 -Query $camlQuery -Connection $connection | where-object {$_.FieldValues.Error -eq $true } # | Sort-Object -Property ID -Ascending

#if ($KBRIEF_DEBUG -gt 0){
#    $camlQuery = "<View>
#      <Query>
#        <Where>
#          <Eq>
#            <FieldRef Name='TCC_ID' />
#            <Value Type='Text'>$KBRIEF_DEBUG</Value>
#          </Eq>
#        </Where>
#      </Query>
#    </View>"
#    $items = Get-PnPListItem -List $listKBrief -Query $camlQuery -Connection $connection
#} else {
#    
#    $camlQuery = "<View>
#      <Query>
#        <OrderBy>
#          <FieldRef Name='TCC_ID' Ascending='TRUE' />
#        </OrderBy>
#      </Query>
#      <RowLimit Paged='TRUE'>1000</RowLimit></View>"
#
#    $items = Get-PnPListItem -List $listKBrief -PageSize 1000 -Query $camlQuery -Connection $connection | where-object {$_.FieldValues.TCC_ID -lt $KBRIEF_SP_DEBUG_START -or $_.FieldValues.TCC_ID -gt $KBRIEF_SP_DEBUG_END } # | Sort-Object -Property ID -Ascending
#}

cls
$importBatch = (Get-Date).ToString("yyyyMMddHHmm")
$dtOverAllStartTime = Get-Date
$totalcount = $items.Count
$counter = 0
$processcounter = 0
foreach ($spitem in $items){
    $counter++
    $KBRIEF_ID_EXISTING = $spitem["TCC_ID"]
    Write-Host "PROCESSING $counter of $totalcount $KBRIEF_ID_EXISTING - " $spitem["ID"] $spitem["TCC_ID"] -ForegroundColor Yellow
    $queryKBriefs = "SELECT 
	        KB.kbrief_id, 
	        kbrief_guid, 
	        kbrief_name, 
	        description, 
	        kbrief_type,
	        creation_date,
	        lead_teacher,
	        u.display_name as TeacherDisplayName,
	        u.email as TeacherEmail,
		    last_edited,
	        last_edited_categories,
	        last_edited_editors,
	        last_edited_teachers,
            status,
		    categories.category,
		    assigned_to,
		    ua.display_name as AssignedDisplayName,
	        ua.email as AssignedToEmail, 
		    document_mode,
		    due_date,
            ISNULL(kblockcount, 0) as kblockcount
        FROM kbriefs KB
        LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
        LEFT JOIN users u
        ON KB.lead_teacher = u.user_id
        LEFT JOIN users ua
        ON KB.assigned_to = ua.user_id
        LEFT JOIN (SELECT 
	        kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
          FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
          INNER JOIN categories c on kc.category_id = c.category_id
          GROUP BY kc.kbrief_id) categories
        ON categories.kbrief_id = kb.kbrief_id
        WHERE KB.kbrief_id = $KBRIEF_ID_EXISTING"

    try{
        $kbriefs = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryKBriefs -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 8000000
        processKBrief
    } catch {
        Write-Host "Caught a connection error Main " $_ -ForegroundColor Red
    }  
}

$dtOverAllEndTime = Get-Date
$overAllTimeDifference = New-TimeSpan -Start $dtOverAllStartTime -End $dtOverAllEndTime

Write-Host "**********************************************************************"
Write-Host "Overall Processing Time" $overAllTimeDifference.Minutes "minutes" -ForegroundColor Green
Write-Host "Average Processing Time" ($overAllTimeDifference.Seconds / $items.Count) "seconds" -ForegroundColor Green   





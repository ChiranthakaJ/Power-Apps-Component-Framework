﻿Import-Module PnP.PowerShell

cls

Write-Host $PSScriptRoot
. "$PSScriptRoot\Functions.ps1"
. "$PSScriptRoot\ProcessKBriefs.ps1"


$RUNBLOCKS = $true
$PROJECTTYPE = "'project'"
$TOP = 500
$REPROCESS = $true
$REPROCESSBLOCK = $true
$DELETEBLOCKS = $true
$REMOVEFILES = $true
$ROWLIMIT = 5
$WORDMAX = 50

$camlQuery = "<View>
      <Query>
        <Where>
            <And>
              <Eq>
                <FieldRef Name='Processed' />
                <Value Type='Boolean'>0</Value>
              </Eq>
              <Eq>
                <FieldRef Name='Status' />
                <Value Type='Text'>Created</Value>
              </Eq>
            </And>
        </Where>
      </Query>
</View>"

$items = Get-PnPListItem -List $listProcess -Query $camlQuery -Connection $connection


$importBatch = (Get-Date).ToString("yyyyMMddHHmm")
$dtOverAllStartTime = Get-Date
$totalcount = $items.Count
$counter = 0
$processcounter = 0
foreach ($spitem in $items){
    $counter++
    $KBRIEF_ID_EXISTING = $spitem["Title"]
    Write-Host "PROCESSING $counter of $totalcount $KBRIEF_ID_EXISTING - " $spitem["ID"] -ForegroundColor Yellow
    $queryKBriefs = "SELECT 
	        KB.kbrief_id, 
	        kbrief_guid, 
	        kbrief_name, 
	        description, 
	        kbrief_type,
	        creation_date,
	        lead_teacher,
	        u.display_name as TeacherDisplayName,
	        u.email as TeacherEmail,
		    last_edited,
	        last_edited_categories,
	        last_edited_editors,
	        last_edited_teachers,
            status,
		    categories.category,
		    assigned_to,
		    ua.display_name as AssignedDisplayName,
	        ua.email as AssignedToEmail, 
		    document_mode,
		    due_date,
            ISNULL(kblockcount, 0) as kblockcount
        FROM kbriefs KB
        LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
        LEFT JOIN users u
        ON KB.lead_teacher = u.user_id
        LEFT JOIN users ua
        ON KB.assigned_to = ua.user_id
        LEFT JOIN (SELECT 
	        kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
          FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
          INNER JOIN categories c on kc.category_id = c.category_id
          GROUP BY kc.kbrief_id) categories
        ON categories.kbrief_id = kb.kbrief_id
        WHERE KB.kbrief_id = $KBRIEF_ID_EXISTING"
     
     $values = @{
        "ImportBatch" = $importBatch
        "Status" = "Processing"
    }

    $out = Set-PnPListItem -List $listProcess -Identity $spitem["ID"] -Values $values -Connection $connection

    try{
        $kbriefs = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryKBriefs -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 8000000
        processKBrief
    } catch {
        Write-Host "Caught a connection error Main " $_ -ForegroundColor Red
    }  

    $dt = Get-Date
    $values = @{
        "Processed" = $true
        "ProcessedDate" = $dt
        "Status" = "Processed"
    }
    $out = Set-PnPListItem -List $listProcess -Identity $spitem["ID"] -Values $values -Connection $connection
}

$dtOverAllEndTime = Get-Date
$overAllTimeDifference = New-TimeSpan -Start $dtOverAllStartTime -End $dtOverAllEndTime

Write-Host "**********************************************************************"
Write-Host "Overall Processing Time" $overAllTimeDifference.Minutes "minutes" -ForegroundColor Green

if ($items.Count -gt 0){
    Write-Host "Average Processing Time" ($overAllTimeDifference.Seconds / $items.Count) "seconds" -ForegroundColor Green   
}





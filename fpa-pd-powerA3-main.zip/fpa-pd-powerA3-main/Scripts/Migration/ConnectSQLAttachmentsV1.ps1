﻿Import-Module PnP.PowerShell

Write-Host $PSScriptRoot
. "$PSScriptRoot\Functions.ps1"
. "$PSScriptRoot\ProcessKBriefs.ps1"


$KBRIEF_DEBUG = 0 #187075 #195472 # 193745 #187075 #187075
$KBRIEF_DEBUG_MAX = 0 #187094
$KBRIEF_BLOCK_DEBUG = 0 #431076 #433776
$STARTCOUNTER =130363
$ENDCOUNTER = 140000

$RUNBLOCKS = $true
$TOP = 10000
$REPROCESS = $true
$REPROCESSBLOCK = $true
$DELETEBLOCKS = $true
$REMOVEFILES = $true
$ROWLIMIT = 5
$SKIPATTACHMENTS = $false
$WORDMAX = 1

if ($KBRIEF_DEBUG_MAX -gt 0 -and $KBRIEF_DEBUG -gt 0){
    $queryKBriefs = "SELECT 
	        KB.kbrief_id, 
	        kbrief_guid, 
	        kbrief_name, 
	        description, 
	        kbrief_type,
	        creation_date,
	        lead_teacher,
	        u.display_name as TeacherDisplayName,
	        u.email as TeacherEmail,
		    last_edited,
	        last_edited_categories,
	        last_edited_editors,
	        last_edited_teachers,
            status,
		    categories.category,
		    assigned_to,
		    ua.display_name as AssignedDisplayName,
	        ua.email as AssignedToEmail, 
		    document_mode,
		    due_date,
			kxd.kbrief_document,
            ISNULL(kblockcount, 0) as kblockcount
        FROM kbriefs KB
        LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
        LEFT JOIN users u
        ON KB.lead_teacher = u.user_id
        LEFT JOIN users ua
        ON KB.assigned_to = ua.user_id
        LEFT JOIN (SELECT 
	        kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
          FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
          INNER JOIN categories c on kc.category_id = c.category_id
          GROUP BY kc.kbrief_id) categories
        ON categories.kbrief_id = kb.kbrief_id
		LEFT JOIN kbrief_xml_documents kxd on kxd.kbrief_id = kb.kbrief_id
        WHERE KB.kbrief_id >= $KBRIEF_DEBUG and KB.kbrief_id <= $KBRIEF_DEBUG_MAX"

} elseif ($KBRIEF_DEBUG -gt 0) {
    $queryKBriefs = "SELECT 
	        KB.kbrief_id, 
	        kbrief_guid, 
	        kbrief_name, 
	        description, 
	        kbrief_type,
	        creation_date,
	        lead_teacher,
	        u.display_name as TeacherDisplayName,
	        u.email as TeacherEmail,
		    last_edited,
	        last_edited_categories,
	        last_edited_editors,
	        last_edited_teachers,
            status,
		    categories.category,
		    assigned_to,
		    ua.display_name as AssignedDisplayName,
	        ua.email as AssignedToEmail, 
		    document_mode,
		    due_date,
            ISNULL(kblockcount, 0) as kblockcount
        FROM kbriefs KB
        LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
        LEFT JOIN users u
        ON KB.lead_teacher = u.user_id
        LEFT JOIN users ua
        ON KB.assigned_to = ua.user_id
        LEFT JOIN (SELECT 
	        kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
          FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
          INNER JOIN categories c on kc.category_id = c.category_id
          GROUP BY kc.kbrief_id) categories
        ON categories.kbrief_id = kb.kbrief_id
        WHERE KB.kbrief_id = $KBRIEF_DEBUG"

} else {
    If($SKIPATTACHMENTS){
        $queryKBriefs = "SELECT TOP $($TOP) * FROM (	
	    SELECT TOP 50000
	        KB.kbrief_id, 
	        kbrief_guid, 
	        kbrief_name, 
	        description, 
	        kbrief_type,
	        creation_date,
	        lead_teacher,
	        u.display_name as TeacherDisplayName,
	        u.email as TeacherEmail,
		    last_edited,
	        last_edited_categories,
	        last_edited_editors,
	        last_edited_teachers,
            status,
		    categories.category,
		    assigned_to,
		    ua.display_name as AssignedDisplayName,
	        ua.email as AssignedToEmail, 
		    document_mode,
		    due_date,
			ISNULL(kbb.kblockcount, 0) as blockcount
        FROM kbriefs KB 
        LEFT JOIN users u
        ON KB.lead_teacher = u.user_id
        LEFT JOIN users ua
        ON KB.assigned_to = ua.user_id
		LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks WHERE data_guid_id  <> '00000000-0000-0000-0000-000000000000' GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
        LEFT JOIN (SELECT 
	        kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
          FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
          INNER JOIN categories c on kc.category_id = c.category_id
          GROUP BY kc.kbrief_id) categories
        ON categories.kbrief_id = kb.kbrief_id
		WHERE kb.kbrief_id >= $STARTCOUNTER AND kb.kbrief_id in
			(SELECT KBriefID FROM (
					SELECT  
						kbrief_id as KBriefID,
						CASE BlockCount + FileCount + ConvertRequired + HasDoc WHEN 0 THEN 0 ELSE 1 END as IncludeInImport
					FROM (
					SELECT 
					 kb.kbrief_id,
					 ISNULL(kbbs.BlockCount, 0) as BlockCount,
					 ISNULL(kbbs.FileCount, 0) as FileCount, 
					 creation_date, 
					 last_edited,
					 DATEDIFF(DAY, creation_date, last_edited) as daysdiff, 
					 ISNULL(ConvertRequired, 0) as ConvertRequired, 
					 CASE xdoc.Doc WHEN 1 THEN 1 ELSE 0 END as HasDoc
					 from kbriefs kb
					 left join
					 (SELECT kbrief_id, COUNT(kbrief_block_id) as BlockCount, SUM(fileCount) as FileCount FROM (
					 SELECT kbs.kbrief_id, kbbs.kbrief_block_id, ISNULL(att.fileCount, 0) as fileCount FROM kbriefs kbs
					 LEFT JOIN kbrief_blocks kbbs ON kbs.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN 
					 (SELECT attachment_id, COUNT(*) as fileCount FROM attachments GROUP BY attachment_id) as att on att.attachment_id = kbbs.data_guid_id) sumc
					 GROUP BY kbrief_id) kbbs ON kb.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN (SELECT kbrief_id, MAX(ConvertRequired) as ConvertRequired FROM
					 (SELECT KBB.kbrief_id,  CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
					 FROM kbrief_blocks KBB) kbbc
					 GROUP BY kbrief_id) kbbci on kbbci.kbrief_id = kb.kbrief_id
					 LEFT JOIN (SELECT 1 as Doc, kbrief_id from kbrief_xml_documents
					 WHERE kbrief_document IS NOT NULL) xdoc ON xdoc.kbrief_id = kb.kbrief_id
					 WHERE status <> -1 AND kbrief_type NOT IN ('Category', 'Team', 'Unit', 'User')) ac) ac1
					 WHERE ac1.IncludeInImport = 1) 
		ORDER BY KB.kbrief_id ASC) kbl WHERE kbl.blockcount = 0"
    } else {
        #NEED TO UPDATE WITH EXCLUSION RULES
        $queryKBriefs = "SELECT 
                TOP $($TOP)
	            KB.kbrief_id, 
	            kbrief_guid, 
	            kbrief_name, 
	            description, 
	            kbrief_type,
	            creation_date,
	            lead_teacher,
	            u.display_name as TeacherDisplayName,
	            u.email as TeacherEmail,
		        last_edited,
	            last_edited_categories,
	            last_edited_editors,
	            last_edited_teachers,
                status,
		        categories.category,
		        assigned_to,
		        ua.display_name as AssignedDisplayName,
	            ua.email as AssignedToEmail, 
		        document_mode,
		        due_date,
                ISNULL(kblockcount, 0) as kblockcount
            FROM kbriefs KB
            LEFT JOIN (SELECT COUNT(*) as kblockcount, kbrief_id FROM kbrief_blocks GROUP BY kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
            LEFT JOIN users u
            ON KB.lead_teacher = u.user_id
            LEFT JOIN users ua
            ON KB.assigned_to = ua.user_id
            LEFT JOIN (SELECT 
	            kc.kbrief_id, STRING_AGG(category_label, ', ') as category 
              FROM [tcc_sbtdb].[dbo].[kbrief_categories] kc
              INNER JOIN categories c on kc.category_id = c.category_id
              GROUP BY kc.kbrief_id) categories
            ON categories.kbrief_id = kb.kbrief_id WHERE kb.kbrief_id > $STARTCOUNTER and kb.kbrief_id < $ENDCOUNTER and kb.kbrief_id in
			(SELECT KBriefID FROM (
					SELECT  
						kbrief_id as KBriefID,
						CASE BlockCount + FileCount + ConvertRequired + HasDoc WHEN 0 THEN 0 ELSE 1 END as IncludeInImport
					FROM (
					SELECT 
					 kb.kbrief_id,
					 ISNULL(kbbs.BlockCount, 0) as BlockCount,
					 ISNULL(kbbs.FileCount, 0) as FileCount, 
					 creation_date, 
					 last_edited,
					 DATEDIFF(DAY, creation_date, last_edited) as daysdiff, 
					 ISNULL(ConvertRequired, 0) as ConvertRequired, 
					 CASE xdoc.Doc WHEN 1 THEN 1 ELSE 0 END as HasDoc
					 from kbriefs kb
					 left join
					 (SELECT kbrief_id, COUNT(kbrief_block_id) as BlockCount, SUM(fileCount) as FileCount FROM (
					 SELECT kbs.kbrief_id, kbbs.kbrief_block_id, ISNULL(att.fileCount, 0) as fileCount FROM kbriefs kbs
					 LEFT JOIN kbrief_blocks kbbs ON kbs.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN 
					 (SELECT attachment_id, COUNT(*) as fileCount FROM attachments GROUP BY attachment_id) as att on att.attachment_id = kbbs.data_guid_id) sumc
					 GROUP BY kbrief_id) kbbs ON kb.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN (SELECT kbrief_id, MAX(ConvertRequired) as ConvertRequired FROM
					 (SELECT KBB.kbrief_id,  CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
					 FROM kbrief_blocks KBB) kbbc
					 GROUP BY kbrief_id) kbbci on kbbci.kbrief_id = kb.kbrief_id
					 LEFT JOIN (SELECT 1 as Doc, kbrief_id from kbrief_xml_documents
					 WHERE kbrief_document IS NOT NULL) xdoc ON xdoc.kbrief_id = kb.kbrief_id
					 WHERE status <> -1 AND kbrief_type NOT IN ('Category', 'Team', 'Unit', 'User')) ac) ac1
					 WHERE ac1.IncludeInImport = 1) 
                     ORDER BY KB.kbrief_id ASC"
    }
}

Write-Host $queryKBriefs -ForegroundColor Green
$importBatch = (Get-Date).ToString("yyyyMMddHHmm")


$dtOverAllStartTime = Get-Date
$processcounter = 0


$kbriefs = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryKBriefs -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 8000000
processKBrief

$dtOverAllEndTime = Get-Date
$overAllTimeDifference = New-TimeSpan -Start $dtOverAllStartTime -End $dtOverAllEndTime

Write-Host "**********************************************************************"
Write-Host "Overall Processing Time" $overAllTimeDifference.Minutes "minutes" -ForegroundColor Green
if ($processcounter -gt 0){
    Write-Host "Average Processing Time" ($overAllTimeDifference.Seconds / $processcounter) "seconds" -ForegroundColor Green  
}






# Load configuration from config.ps1 (excluded from source control)
$configPath = Join-Path $PSScriptRoot "..\config.ps1"
if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: config.ps1 not found. Copy config.example.ps1 to config.ps1 and fill in your values." -ForegroundColor Red
    exit 1
}
. $configPath

$sharePath = $baseAttachmentPath
$copyPath  = $NETWORKPATH
$KBRIEF_DEBUG = 0
$KBRIEF_DEBUG_START = 150000
$KBRIEF_DEBUG_END =  170000
$OVERRIDE = $true

# 172148 172156
$PATHDOCX = "DOCX"
$PATHATTACHMENTS = "ATTACHMENTS"
$PATHBLOCKS = "BLOCKS"

if ($KBRIEF_DEBUG -ne 0){
    #$queryKBriefs = "SELECT
	#		        KB.kbrief_id,
	#		        ISNULL(kxd.kbrief_document, '') as kbrief_document,
	#		        ISNULL(KBB.KCount, 0) as KCount,
	#				ISNULL(KBBO.KCountO, 0) as KCountO
    #                FROM kbriefs KB 
	#	            LEFT JOIN kbrief_xml_documents KXD on KXD.kbrief_id = KB.kbrief_id
	#		        LEFT JOIN (SELECT COUNT(*) as KCount, kbrief_id FROM kbrief_blocks
	#		        GROUP By kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
	#				LEFT JOIN (SELECT COUNT(*) as KCountO, kbrief_id FROM kbrief_blocks WHERE data_string LIKE '%\conversions\%' and heading = 'The Original K-Brief Document'
	#		        GROUP By kbrief_id) KBBO on KBBO.kbrief_id = KB.kbrief_id
	#		        WHERE KB.kbrief_id = $KBRIEF_DEBUG AND kb.kbrief_type IN ('project', 'information', 'decision', 'k-review')
	#	            ORDER BY KB.kbrief_id ASC"

    $queryKBriefs = "SELECT
			        KB.kbrief_id,
			        ISNULL(kxd.kbrief_document, '') as kbrief_document,
			        ISNULL(KBB.KCount, 0) as KCount,
					ISNULL(KBBO.KCountO, 0) as KCountO
                    FROM kbriefs KB 
		            LEFT JOIN kbrief_xml_documents KXD on KXD.kbrief_id = KB.kbrief_id
			        LEFT JOIN (SELECT COUNT(*) as KCount, kbrief_id FROM kbrief_blocks
			        GROUP By kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
					LEFT JOIN (SELECT COUNT(*) as KCountO, kbrief_id FROM kbrief_blocks WHERE data_string LIKE '%\conversions\%' and heading = 'The Original K-Brief Document'
			        GROUP By kbrief_id) KBBO on KBBO.kbrief_id = KB.kbrief_id
			        WHERE KB.kbrief_id = $KBRIEF_DEBUG AND kb.kbrief_id IN (SELECT KBriefID FROM (
					SELECT  
						kbrief_id as KBriefID,
						CASE BlockCount + FileCount + ConvertRequired + HasDoc WHEN 0 THEN 0 ELSE 1 END as IncludeInImport
					FROM (
					SELECT 
					 kb.kbrief_id,
					 ISNULL(kbbs.BlockCount, 0) as BlockCount,
					 ISNULL(kbbs.FileCount, 0) as FileCount, 
					 creation_date, 
					 last_edited,
					 DATEDIFF(DAY, creation_date, last_edited) as daysdiff, 
					 ISNULL(ConvertRequired, 0) as ConvertRequired, 
					 CASE xdoc.Doc WHEN 1 THEN 1 ELSE 0 END as HasDoc
					 from kbriefs kb
					 left join
					 (SELECT kbrief_id, COUNT(kbrief_block_id) as BlockCount, SUM(fileCount) as FileCount FROM (
					 SELECT kbs.kbrief_id, kbbs.kbrief_block_id, ISNULL(att.fileCount, 0) as fileCount FROM kbriefs kbs
					 LEFT JOIN kbrief_blocks kbbs ON kbs.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN 
					 (SELECT attachment_id, COUNT(*) as fileCount FROM attachments GROUP BY attachment_id) as att on att.attachment_id = kbbs.data_guid_id) sumc
					 GROUP BY kbrief_id) kbbs ON kb.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN (SELECT kbrief_id, MAX(ConvertRequired) as ConvertRequired FROM
					 (SELECT KBB.kbrief_id,  CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
					 FROM kbrief_blocks KBB) kbbc
					 GROUP BY kbrief_id) kbbci on kbbci.kbrief_id = kb.kbrief_id
					 LEFT JOIN (SELECT 1 as Doc, kbrief_id from kbrief_xml_documents
					 WHERE kbrief_document IS NOT NULL) xdoc ON xdoc.kbrief_id = kb.kbrief_id
					 WHERE status <> -1 AND kbrief_type NOT IN ('Category', 'Team', 'Unit', 'User')) ac) ac1
					 WHERE ac1.IncludeInImport = 1)
		ORDER BY KB.kbrief_id ASC"
} else {
     #$queryKBriefs = "SELECT
		#	        KB.kbrief_id,
		#	        ISNULL(kxd.kbrief_document, '') as kbrief_document,
		#	        ISNULL(KBB.KCount, 0) as KCount,
		#			ISNULL(KBBO.KCountO, 0) as KCountO
         #           FROM kbriefs KB 
		  #          LEFT JOIN kbrief_xml_documents KXD on KXD.kbrief_id = KB.kbrief_id
			#        LEFT JOIN (SELECT COUNT(*) as KCount, kbrief_id FROM kbrief_blocks
			 #       GROUP By kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
				#	LEFT JOIN (SELECT COUNT(*) as KCountO, kbrief_id FROM kbrief_blocks WHERE data_string LIKE '%\conversions\%' and heading = 'The Original K-Brief Document'
			     #   GROUP By kbrief_id) KBBO on KBBO.kbrief_id = KB.kbrief_id
			      #  WHERE KB.kbrief_id >= $KBRIEF_DEBUG_START and KB.kbrief_id <= $KBRIEF_DEBUG_END AND kb.kbrief_type IN ('project', 'information', 'decision', 'k-review')
		           # ORDER BY KB.kbrief_id ASC"
        $queryKBriefs = "SELECT
			        KB.kbrief_id,
			        ISNULL(kxd.kbrief_document, '') as kbrief_document,
			        ISNULL(KBB.KCount, 0) as KCount,
					ISNULL(KBBO.KCountO, 0) as KCountO
                    FROM kbriefs KB 
		            LEFT JOIN kbrief_xml_documents KXD on KXD.kbrief_id = KB.kbrief_id
			        LEFT JOIN (SELECT COUNT(*) as KCount, kbrief_id FROM kbrief_blocks
			        GROUP By kbrief_id) KBB on KBB.kbrief_id = KB.kbrief_id
					LEFT JOIN (SELECT COUNT(*) as KCountO, kbrief_id FROM kbrief_blocks WHERE data_string LIKE '%\conversions\%' and heading = 'The Original K-Brief Document'
			        GROUP By kbrief_id) KBBO on KBBO.kbrief_id = KB.kbrief_id
			        WHERE KB.kbrief_id >= $KBRIEF_DEBUG_START and KB.kbrief_id <= $KBRIEF_DEBUG_END AND kb.kbrief_id IN (SELECT KBriefID FROM (
					SELECT  
						kbrief_id as KBriefID,
						CASE BlockCount + FileCount + ConvertRequired + HasDoc WHEN 0 THEN 0 ELSE 1 END as IncludeInImport
					FROM (
					SELECT 
					 kb.kbrief_id,
					 ISNULL(kbbs.BlockCount, 0) as BlockCount,
					 ISNULL(kbbs.FileCount, 0) as FileCount, 
					 creation_date, 
					 last_edited,
					 DATEDIFF(DAY, creation_date, last_edited) as daysdiff, 
					 ISNULL(ConvertRequired, 0) as ConvertRequired, 
					 CASE xdoc.Doc WHEN 1 THEN 1 ELSE 0 END as HasDoc
					 from kbriefs kb
					 left join
					 (SELECT kbrief_id, COUNT(kbrief_block_id) as BlockCount, SUM(fileCount) as FileCount FROM (
					 SELECT kbs.kbrief_id, kbbs.kbrief_block_id, ISNULL(att.fileCount, 0) as fileCount FROM kbriefs kbs
					 LEFT JOIN kbrief_blocks kbbs ON kbs.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN 
					 (SELECT attachment_id, COUNT(*) as fileCount FROM attachments GROUP BY attachment_id) as att on att.attachment_id = kbbs.data_guid_id) sumc
					 GROUP BY kbrief_id) kbbs ON kb.kbrief_id = kbbs.kbrief_id
					 LEFT JOIN (SELECT kbrief_id, MAX(ConvertRequired) as ConvertRequired FROM
					 (SELECT KBB.kbrief_id,  CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
					 FROM kbrief_blocks KBB) kbbc
					 GROUP BY kbrief_id) kbbci on kbbci.kbrief_id = kb.kbrief_id
					 LEFT JOIN (SELECT 1 as Doc, kbrief_id from kbrief_xml_documents
					 WHERE kbrief_document IS NOT NULL) xdoc ON xdoc.kbrief_id = kb.kbrief_id
					 WHERE status <> -1 AND kbrief_type NOT IN ('Category', 'Team', 'Unit', 'User')) ac) ac1
					 WHERE ac1.IncludeInImport = 1)
		ORDER BY KB.kbrief_id ASC"
}
cls


$kbriefs = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryKBriefs -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 80000000
$counter = 0
$processcounter = 0
$word = New-Object -ComObject Word.Application
$word.Visible = $false # Set to $true if you want to see Word open
$saveFormat = [Microsoft.Office.Interop.Word.WdSaveFormat]::wdFormatFilteredHTML
foreach ($kbrief in $kbriefs){
    $hasAction = $false
    $processcounter++
    Write-Host "**********************************"
    Write-Host $processcounter $kbrief.kbrief_id

    $fcopyPath = "$copyPath\$($kbrief.kbrief_id)"
    
    if ((Test-Path $fcopyPath) -eq $false -or $OVERRIDE){
        
        if ($OVERRIDE -and (Test-Path $fcopyPath)){
            Write-Host "Remove $fcopyPath"
            Remove-Item -Path $fcopyPath -Force -Recurse
        }

        New-Item -Path $fcopyPath -ItemType Directory -Force | Out-Null

        Write-Host $fcopyPath
       
        if (Test-Path $fcopyPath){
            $fcopyPathDocx = ""
            $fcopyPathDocx = ""
            $outXMLPath = ""

            $processDocument = $false
            if ($kbrief.kbrief_document -ne ''){
                
                $fcopyPathDocx = "$fcopyPath\$PATHDOCX"
                New-Item -Path $fcopyPathDocx -ItemType Directory -Force | Out-Null

                $fcopyPathDocx = "$fcopyPathDocx"
                $outXMLPath = "$fcopyPathDocx\$($kbrief.kbrief_id).xml"
                $kbrief.kbrief_document | Out-File -FilePath $outXMLPath

                if((Test-Path -Path $outXMLPath)){
                    $processDocument = $true
                }           
            }
            if ($processDocument){
                
                try {                        
                    $hasAction = $true
                    $counter++
                    Write-Host "1. Open " $outXMLPath -ForegroundColor Cyan
                    $document = $word.Documents.Open($outXMLPath)
                
                    $docxPath = $outXMLPath.Replace(".xml", ".docx")
                    Write-Host "2. Save " $docxPath -ForegroundColor Cyan
                    $document.SaveAs([ref]$docxPath, [ref]16) # 16 corresponds to wdFormatDocumentDefault (DOCX)
                    $document.Close()

                    if ($kbrief.KCount -eq 0 -or $kbrief.KCount0 -gt 0){
                        Write-Host "3. Open " $docxPath -ForegroundColor Cyan
                        $document = $word.Documents.Open($docxPath)

                        $htmlPath = $outXMLPath.Replace(".xml", ".html")
                        Write-Host "4. Save " $htmlPath -ForegroundColor Cyan
                        $document.SaveAs([ref]$htmlPath, [ref]$saveFormat)
                        Write-Host "File saved to $htmlPath" -ForegroundColor Green
                        # Close the document
                        $document.Close()
                    }


                    if (Test-Path $outXMLPath){
                        try{
                            Remove-Item $outXMLPath
                        } catch {
                            Start-Sleep -Seconds 5
                            Remove-Item $outXMLPath
                        }
                    }
                } catch {
                    Write-Host $_ -ForegroundColor Red
                }
            }
        }

        $queryKBriefs = "SELECT 
                    kbb.kbrief_id, 
                    kbb.block_id,
                    kbb.explanation,
                    ISNULL(att.file_name, '') as file_name,
                    CASE WHEN kbb.data_string LIKE '%\conversions\%' and kbb.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired,
                    CASE WHEN kbb.explanation LIKE '%?\tab%' or kbb.explanation LIKE '%http%' THEN 1 ELSE 0 END as ConvertBulletRequired
                FROM kbrief_blocks kbb
                LEFT JOIN (SELECT original_file_name, file_name, attachment_id FROM Attachments) att on kbb.data_guid_id = att.attachment_id
                WHERE kbb.kbrief_id = $($kbrief.kbrief_id)"
        
        $blocks = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryKBriefs -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 12000000

        #CHECK FOR ANY ATTACHMENTS THAT MAY BE ZIP FILES
        $blockcounter = 0
        foreach ($block in $blocks){
            $continue = $false

            If ($block.file_name -ne ""){
                $fcopyPathAtt = "$fcopyPath\$PATHATTACHMENTS"
                if ((Test-Path $fcopyPathAtt) -eq $false){
                    New-Item -Path $fcopyPathAtt -ItemType Directory -Force | Out-Null
                }

                $blockcounter++
                $file = $block.file_name
                Write-Host $blockcounter $file
   
                $fileName = $file.Replace(".zip", "")
                $fsharePath = "$sharePath\$($file)"
                Write-Host $fsharePath
                $fcopyPathAttName = "$fcopyPathAtt\$filename"
            
                $zip = [System.IO.Compression.ZipFile]::OpenRead($fsharePath)
                $zip.Entries | ForEach-Object {
                    if ($_.FullName.EndsWith(".xml")){
                        Write-Host $_.FullName -ForegroundColor Green
                        $continue = $true
                    }
                }
                $zip.Dispose()
            }
            if ($continue){
        
                #Create Directory
                New-Item -Path $fcopyPathAttName -ItemType Directory -Force | Out-Null
                Write-Host "Directory Created"
                $item = Copy-Item -Path $fsharePath -Destination $fcopyPathAttName
                Expand-Archive -Path "$fcopyPathAttName\$file" -DestinationPath $fcopyPathAttName -Force

                Remove-Item "$fcopyPathAttName\$file"

                $path = (Get-ChildItem -Path $fcopyPathAttName -Filter *.xml | Select-Object -First 1).Name    
                Write-Host "Path is $path" -ForegroundColor Yellow
                if (![string]::IsNullOrWhiteSpace($path)){
                    $sourceFile = "$fcopyPathAttName\$path"
                    if ($path.EndsWith(".xml")){
                        $hasAction = $true
                        Write-Host "Is an XML file" -ForegroundColor Cyan
                        try {                        
                            #Write-Host $sourceFile
                            $counter++
                            Write-Host "1. Open " $sourceFile -ForegroundColor Cyan
                            $document = $word.Documents.Open($sourceFile)
                
                            $docxPath = $sourceFile.Replace(".xml", ".docx")
                            Write-Host "2. Save " $docxPath -ForegroundColor Cyan
                            $document.SaveAs([ref]$docxPath, [ref]16) # 16 corresponds to wdFormatDocumentDefault (DOCX)
                            $document.Close()

                            if ($block.ConvertRequired){
                                $htmlPath = $sourceFile.Replace(".xml", ".html")
                                Write-Host "3. Open " $sourceFile -ForegroundColor Cyan
                                $document = $word.Documents.Open($docxPath)

                                Write-Host "4. Save " $htmlPath -ForegroundColor Cyan
                                $document.SaveAs([ref]$htmlPath, [ref]$saveFormat)
                                Write-Host "File saved to $htmlPath" -ForegroundColor Green
                                # Close the document
                                $document.Close()
                            }

                            if (Test-Path $sourceFile){
                                try{
                                    Remove-Item $sourceFile
                                } catch {
                                    Start-Sleep -Seconds 5
                                    Remove-Item $sourceFile
                                }
                            }
                        } catch {
                            Write-Host $_ -ForegroundColor Red
                        }
                    }                
                }

               
            }    
            if ($block.ConvertBulletRequired){
                $blockid = $block.block_id
                $fcopyPathBlocks = "$fcopyPath\$PATHBLOCKS"
                if ((Test-Path $fcopyPathBlocks) -eq $false){
                    New-Item -Path $fcopyPathBlocks -ItemType Directory -Force | Out-Null
                }
                $fcopyPathBlocksBlock = "$fcopyPathBlocks\$($blockid)"
                if ((Test-Path $fcopyPathBlocksBlock) -eq $false){
                    New-Item -Path $fcopyPathBlocksBlock -ItemType Directory -Force | Out-Null
                }

                if ((Test-Path $fcopyPathBlocksBlock)){
                    $rtfFilePath = "$fcopyPathBlocksBlock\$blockid.rtf"
                    $htmlFilePath = "$fcopyPathBlocksBlock\$blockid.html"

                    Set-Content -Path $rtfFilePath -Value $block.explanation

                    try{
                        $document = $word.Documents.Open($rtfFilePath)
                        $document.SaveAs([ref]$htmlFilePath, [ref]10) # 16 corresponds to wdFormatDocumentDefault (DOCX)

                        Write-Host "Processed $htmlFilePath" -ForegroundColor Green
                        # Close the document
                        $document.Close()
                        $hasAction = $true
                    } catch {}

                    if (Test-Path -Path $rtfFilePath){
                        Remove-Item -Path $rtfFilePath -Force
                    }
                }

            }
        }
    }

    if ($hasAction -eq $false -and (Test-Path $fcopyPath) -and $OVERRIDE){
        Write-Host "Remove $fcopyPath as No Action" -ForegroundColor Yellow
        Remove-Item -Path $fcopyPath -Force -Recurse
    }

    if ($counter -gt 100){
        Write-Host "Restart Word" -ForegroundColor Yellow
        $word.Quit()
        # Release COM object
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null

        $word = New-Object -ComObject Word.Application
        $word.Visible = $false # Set to $true if you want to see Word open
        $saveFormat = [Microsoft.Office.Interop.Word.WdSaveFormat]::wdFormatFilteredHTML
        $counter = 0
    }
}
$word.Quit()
# Release COM object
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
﻿Import-Module PnP.PowerShell

$NETWORKPATH = "\\AKLVTDBS01\TCCReplacement\TCCFiles"

Add-Type -Path "$PSScriptRoot\RtfPipe.dll"

function Remove-ByTitle {
    param(
        [Parameter(Mandatory)]
        [Object[]]$SourceArray,

        [Parameter(Mandatory)]
        [Object[]]$ExcludeArray
    )

    # Collect titles from the exclude array
    $excludeTitles = $ExcludeArray | ForEach-Object { $_.Title }

    # Return only items not in the exclude list
    $SourceArray | Where-Object { $_.Title -notin $excludeTitles }
}

function Merge-BlankObjects {
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [Object[]]$InputArray
    )

    $result = @()
    for ($i = 0; $i -lt $InputArray.Count; $i++) {
        $current = $InputArray[$i]

        if ($current.Title -eq "Blank" -and $result.Count -gt 0) {
            # Merge into the last object in result
            $previous = $result[-1]

            $previous.Explanation += $current.Explanation
            $previous.BlockTypeID = $current.BlockTypeID
            $previous.BlockType = $current.BlockType
            $previous.TCC_ExplanationText = $current.TCC_ExplanationText
            $previous.TCC_Explanation = $current.TCC_Explanation
            $previous.TCC_BlockTypeID = $current.TCC_BlockTypeID
            $previous.TCC_KBriefBlockID = $current.TCC_KBriefBlockID
            $previous.LinkedKBriefID = $current.LinkedKBriefID
        }
        else {
            # Add as a new object
            $result += $current
        }
    }

    return $result
}


function parseDataString($val){
    $id = 0
    $block = 0
    if ($val -match "id=(\d+).*?block=(\d+)") {
        $id = $matches[1]
        $block = $matches[2]
    }
    return $id, $block
}

function getPlanningActions($kbriefid, $blockid){
    $queryPlans = "SELECT 
	    plan_id,
	    p.kbrief_id,
	    p.block_id,
	    is_pending,
	    activation_status,
	    kbb.kbrief_block_id
    FROM plans p
    INNER JOIN kbrief_blocks kbb ON
    kbb.kbrief_id = p.kbrief_id and kbb.block_id = p.block_id 
    WHERE p.kbrief_id = $kbriefid and p.block_id = $blockid"

    $plans = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryPlans -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000

    foreach ($plan in $plans){
        $activationstatus = $lookupArrayActivation | Where-Object { $_.TCCEnumValue -eq $plan.activation_status }
        $strHTML = "<table style='width:100%;border-collapse: collapse;border: 1px solid' cellpadding=5 cellspacing=0><tr style='border: 1px solid'><td colspan='4'>To do once K-Brief's Status >= <b>$($activationstatus.Title)</b></td></tr>"
        $strHTML += "<tr style='border: 1px solid'><td style='width:15%;border: 1px solid'><b>P</b></td><td style='width:15%;border: 1px solid'><b>When</b></td><td style='width:15%;border: 1px solid'><b>Who</b></td><td style='width:55%;border: 1px solid'><b>What</b></td></tr>"
        $queryPlansActions = "SELECT 
                    block_id,
	                row_id, 
	                [when], 
	                who_id, 
	                who_text, 
	                what_id, 
	                what_text, 
	                progress, 
	                last_progress_date
                FROM planning_actions
                WHERE kbrief_id = $($kbriefid) and block_id = $($blockid) ORDER BY [when] ASC"     
        $actions = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryPlansActions -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 8000000
        
        $decoration = ""
        foreach ($action in $actions){
            $progressstatus = $lookupArrayProgress | Where-Object { $_.TCCEnumValue -eq $action.progress }
            $shortCode = $progressstatus.ShortCode
            $when = $action.when.ToString('yyyy-MM-dd')
            $who = $action.who_text
            $what = $action.what_text
            $decoration = ""
            if ($action.progress -eq 10){
                $decoration = "line-through"
            }
            $backgroundcolor = $progressstatus.BackgroundColor
            $foregroundcolor = $progressstatus.ForegroundColor
            $strHTML += "<tr style='border: 1px solid'><td style='border: 1px solid; border-color: #000000; background-Color: $backgroundcolor; color: $foregroundcolor'><b>$shortCode - $($progressstatus.Title)</b></td><td style='border: 1px solid;text-decoration: $decoration'>$when</td><td style='border: 1px solid;text-decoration: $decoration'>$who</td><td style='border: 1px solid;text-decoration: $decoration'>$what</td></tr>"
        }

    }
    if ($actions.Count -gt 0){
        $strHTML += "</table>"
    } else {
        $strHTML = ""
    }
    return $strHTML
    
}

function getComputationHTML($kbriefid){
    $strHTML = ""

    $query = "SELECT TOP 1
	    relation_label,
	    relation_type, 
	    limit_type
        FROM [tcc_sbtdb].[dbo].[relations]
    WHERE kbrief_id = $kbriefid"
    $computations = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $query -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
    
    foreach ($computation in $computations){
        $strHTML += "<tr><td style='width:200px'><b>Method: </b></td><td>" + $computation.relation_type + "</td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Result: </b></td><td>" + $computation.relation_label + "</td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Limit Type: </b></td><td>" + $computation.limit_type + "</td></tr>"
            
    }

    if ($strHTML -ne ""){
        $strHTML = "<table style='width:100%'>" + $strHTML + "</table>"
    }

    #Write-Host $strHTML -ForegroundColor Yellow

    return $strHTML

}

function getIdeasHTML($kbriefid, $blockid){
    $strHTML = ""
    $strHTMLHeader = ""
    $query = "SELECT TOP 1
	    prompt,
	    grid_width
        FROM [tcc_sbtdb].[dbo].[idea_prompts]
    WHERE kbrief_id = $kbriefid and block_id = $blockid"

    $idea_prompts = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $query -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
    
    foreach ($idea_prompt in $idea_prompts){
        $strHTMLHeader = "<table style='width:99%;border-collapse: collapse;border: 1px solid' cellpadding=5 cellspacing=0>
                            <tr>
                                <td colspan=4 style='background-color: #ededed;border: 1px solid'><b>PROMPT</b>
                                </td>
                            </tr>
                            <tr>
                                <td colspan=4 style='border: 1px solid'><b>" + $idea_prompt.prompt + "</b></td>
                            </tr>"
    }

    if ($strHTMLHeader -ne ""){
        $query = "SELECT
	        level_id,
	        time_id,
            description
            FROM [tcc_sbtdb].[dbo].[idea_boxes]
        WHERE kbrief_id = $kbriefid and block_id = $blockid ORDER BY level_id, time_id ASC"
        $ideas = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $query -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
 
        $strHTMLHeader += "<tr>
                            <td style='width:25%;border: 1px solid'></td>
                            <td style='width:25%;border: 1px solid'><b>Before</b></td>
                            <td style='width:25%;border: 1px solid'><b>During</b></td>
                            <td style='width:25%;border: 1px solid'><b>After</b></td>
                            </tr>"

        $strHTMLRow1Col1 = ""
        $strHTMLRow1Col2 = ""
        $strHTMLRow1Col3 = ""
        $strHTMLRow2Col1 = ""
        $strHTMLRow2Col2 = ""
        $strHTMLRow2Col3 = ""
        $strHTMLRow3Col1 = ""
        $strHTMLRow3Col2 = ""
        $strHTMLRow3Col3 = ""
        foreach ($idea in $ideas){
            if ($idea.level_id -eq 5 -and $idea.time_id -eq 1){
                $strHTMLRow1Col1 = $idea.description    
            }
            if ($idea.level_id -eq 5 -and $idea.time_id -eq 3){
                $strHTMLRow1Col2 = $idea.description    
            }
            if ($idea.level_id -eq 5 -and $idea.time_id -eq 5){
                $strHTMLRow1Col3 = $idea.description    
            }
            if ($idea.level_id -eq 7 -and $idea.time_id -eq 1){
                $strHTMLRow2Col1 = $idea.description    
            }
            if ($idea.level_id -eq 7 -and $idea.time_id -eq 3){
                $strHTMLRow2Col2 = $idea.description    
            }
            if ($idea.level_id -eq 7 -and $idea.time_id -eq 5){
                $strHTMLRow2Col3 = $idea.description    
            }
             if ($idea.level_id -eq 9 -and $idea.time_id -eq 1){
                $strHTMLRow3Col1 = $idea.description    
            }
            if ($idea.level_id -eq 9 -and $idea.time_id -eq 3){
                $strHTMLRow3Col2 = $idea.description    
            }
            if ($idea.level_id -eq 9 -and $idea.time_id -eq 5){
                $strHTMLRow3Col3 = $idea.description    
            }   
        }

        $strHTML += "<tr><td style='border: 1px solid'>Super</td><td style='border: 1px solid'>" + $strHTMLRow1Col1 + "</td><td style='border: 1px solid'>" + $strHTMLRow1Col2 + "</td><td style='border: 1px solid'>" + $strHTMLRow1Col3 + "</td></tr>"
        $strHTML += "<tr><td style='border: 1px solid'>System</td><td style='border: 1px solid'>" + $strHTMLRow2Col1 + "</td><td style='border: 1px solid'>" + $strHTMLRow2Col2 + "</td><td style='border: 1px solid'>" + $strHTMLRow2Col3 + "</td></tr>"
        $strHTML += "<tr><td style='border: 1px solid'>Sub<td style='border: 1px solid'>" + $strHTMLRow3Col1 + "</td><td style='border: 1px solid'>" + $strHTMLRow3Col2 + "</td><td style='border: 1px solid'>" + $strHTMLRow3Col3 + "</td></tr>"

        $strHTML = $strHTMLHeader + $strHTML + "</table>"

    }

    #Write-Host $strHTML -ForegroundColor Yellow

    return $strHTML

}

function getCalculationHTML($kbriefid){
    $strHTML = ""

    $query = "SELECT
        d.formatted_range,
	    d.decision_label,
	    en.enum_label,
		d.uom_display,
		d.min_expected,
		d.max_expected,
		d.default_value
      FROM decisions d
      INNER JOIN (SELECT
          [enum_value],
          [enum_label]
      FROM [tcc_sbtdb].[dbo].[system_enumerations] WHERE enum_type = 'DecisionType') en
      ON en.enum_value = d.decision_type_id
      WHERE d.kbrief_id = $kbriefid"
    $computations = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $query -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
    
    foreach ($computation in $computations){
        $strHTML += "<tr><td colspan=2><b>" + $computation.enum_label + "</b></td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Unit: </b></td><td>" + $computation.uom_display + "</td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Min: </b></td><td>" + $computation.min_expected + "</td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Max: </b></td><td>" + $computation.max_expected + "</td></tr>"
        $strHTML += "<tr><td style='width:200px'><b>Default: </b></td><td>" + $computation.default_value + "</td></tr>"
            
    }

    if ($strHTML -ne ""){
        $strHTML = "<table style='width:100%'>" + $strHTML + "</table>"
    }

    #Write-Host $strHTML -ForegroundColor Yellow

    return $strHTML

}

function getRelatedDecision($kbriefid){
    $query = "SELECT 
        d.formatted_range,
	    short_name,
	    r.decision_id,
	    d.decision_label,
	    en.enum_label,
	    r.same_as_decision,
	    '[' + Trim(Str(r.min_expected)) + ',' + Trim(Str(r.max_expected)) + ']' + ' ' + r.uom_display + CASE same_as_decision WHEN 1 THEN '' ELSE '<br>' + '(' + d.formatted_range + ' ' + d.uom_display + ')' END as decisionrange,
	    Trim(Str(r.default_value)) + ' ' + r.factor_uom_display  + CASE same_as_decision WHEN 1 THEN '' ELSE '<br>' + '(' + d.default_value + ' ' + d.uom_display + ')' END  as defaultrange,
	    CASE is_linear WHEN 1 THEN '' ELSE 'increment = ' + Trim(Str(r.grid_increment)) END as methodsettings
      FROM [tcc_sbtdb].[dbo].[relation_terms] r
      INNER JOIN decisions d on d.decision_id = r.decision_id
      INNER JOIN (SELECT
          [enum_value],
          [enum_label]
      FROM [tcc_sbtdb].[dbo].[system_enumerations] WHERE enum_type = 'DecisionType') en
      ON en.enum_value = d.decision_type_id
      WHERE [relation_id] = $kbriefid"
    $decisions = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $query -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
    
    $strHTMLTable = "<table style='width:99%'>"
    $strHTMLTable += "<tr>
                        <td style='width:10%'><b>Short Name</b></td>
                        <td style='width:20%'><b>Decision Name</b></td>
                        <td style='width:15%'><b>Decision Type</b></td>
                        <td style='width:10%'><b>Same</b></td>
                        <td style='width:15%'><b>Range (Decision Range)</b></td>
                        <td style='width:15%'><b>Default (Decision)</b></td>
                        <td style='width:15%'><b>Method Settings</b></td></tr>"
    foreach ($decision in $decisions){
        $same = "Yes"
        if ($decision.same_as_decision -eq 0){
            $same = "No"
        }

        $strHTML += "<tr>
                        <td>" + $decision.short_name + "</td>
                        <td style='background-color: #D0D0D0'>" + $decision.decision_label + "</td>
                        <td style='background-color: #D0D0D0'>" + $decision.enum_label + "</td>
                        <td>" + $same + "</td>
                        <td style='background-color: #D0D0D0'>" + $decision.decisionrange + "</td>
                        <td style='background-color: #D0D0D0'>" + $decision.defaultrange + "</td>
                        <td style='background-color: #D0D0D0'>" + $decision.methodsettings + "</td>
                     </tr>"
    
    }

    if ($strHTML -ne ""){
        $strHTML = $strHTMLTable + $strHTML + "</table>"
    }

    return $strHTML

}

function parseHTMLFromString($strVal){
    
    $strVal = $strVal -replace "<[^>]+>", ""
    return $strVal
}

function clearUnclosedDiv($strVal){
    $strval = [regex]::Replace($strval, "(?s)<div[^>]*>(?=(?:.(?!</div>))*?(?:<div|$))", "")
    $strval = [regex]::Replace($strval, "(?i)(?<!<div[^>]*>)\s*</div>", "")
    return $strval
}

function cleanHeader($strVal){
    $strVal = $strVal.Trim()
    if ($strVal.StartsWith("<img")){
        $idx = $strVal.IndexOf('>')
        #Write-Host $idx -ForegroundColor Yellow
        $strVal = $strVal.Substring($idx + 1, ($strVal.Length - $idx) - 1)
    }

    return $strVal
}

function cleanString($strVal){
    
    if($strVal -ne ""){
        $strVal = $strVal -replace ([char]0x0B), "&#11;" 
        $strVal = $strVal -replace ([char]0x18), "&#24;" 
        $strVal = $strVal -replace ([char]0x1C), "&#28;" 
        $strVal = $strVal -replace '<a(?![^>]*\btarget=)', '<a target="_blank"' #add target = _blank to all hrefs
        $strVal = $strVal -replace '(?is)<a([^>]*?)href="(?!https)[^"]*"([^>]*)>([^<]+)</a>\s*<u[^>]*>([^<]+)</u>', '<a$1href="$3$4"$2>$3$4</a>' #find out if the url is not correct and move the title to the href
        $strVal = $strVal -replace '(?is)<a([^>]*)>([^<]*)</a>\s*<u[^>]*>([^<]*)</u>', '<a$1>$2$3</a>' #find if a u in p directly after url and move it

        $strVal = [regex]::Replace($strVal,'[ \t]+',' ')
        # Remove spaces before and after tags
        $strVal = [regex]::Replace($strVal,'\s*(<[^>]+>)\s*','$1')

    }
    return $strVal
}

function cleanOwnerName($strVal){

    if($strVal -ne ""){
        $strVal = ($strVal -replace '.*\((.*)\).*','$1')
    }
    return $strVal
}

function addImage($kbriefID, $blockid, $values, $path){
    $imageSPPath = ""
    $folder = $null
    $rootFolder = $null
    try{
        $rootFolder = Get-PnPFolder -Url "$libraryImages/$kbriefID" -Connection $connection
    } catch {}
    if (!$rootFolder){
        $rootFolder = Add-PnPFolder -Name $kbriefID -Folder $libraryImages -Connection $connection
    } 
    if ($rootFolder){
        try{
            $folder = Get-PnPFolder -Url "$libraryImages/$kbriefID/$blockid" -Connection $connection
        } catch {}
        if (!$folder){
            $folder = Add-PnPFolder -Name $blockid -Folder "$libraryImages/$kbriefID" -Connection $connection
        } 
    }
    if ($folder){
        $file = Add-PnPFile -Path $path -Folder "$libraryImages/$kbriefID/$blockid" -Connection $connection
        if ($file){
            #Write-Host $file.ServerRelativeUrl -ForegroundColor Cyan
            $fileItem = Get-PnPFile -Url $file.ServerRelativeUrl -AsListItem -Connection $connection
            $out = Set-PnPListItem -List $libraryImages -Identity $fileItem.Id -Values $values -Connection $connection -UpdateType SystemUpdate
            $imageSPPath = $baseURL + $file.ServerRelativeUrl
            
        }
    }
    Write-Host "Image Path" $imageSPPath -ForegroundColor Cyan
    return $imageSPPath
}

function addAttachment($kbriefID, $values, $path){
    $attachmentPath = ""
    $folder = $null
    try{
        $folder = Get-PnPFolder -Url "$libraryAttachments/$kbriefID" -Connection $connection
    } catch {}
    if ($folder -eq $null){
        $folder = Add-PnPFolder -Name $kbriefID -Folder $libraryAttachments -Connection $connection
    }
    if ($folder){
        $file = Add-PnPFile -Path $path -Folder "$libraryAttachments/$kbriefID" -Connection $connection
        if ($file){
            $fileItem = Get-PnPFile -Url $file.ServerRelativeUrl -AsListItem -Connection $connection
            $out = Set-PnPListItem -List $libraryAttachments -Identity $fileItem.Id -Values $values -Connection $connection -UpdateType SystemUpdate
            $attachmentPath = $baseURL + $file.ServerRelativeUrl 
        }
    }
    return $attachmentPath
}

function updateErrorFound($kbriefID, $errorMessage){
    #Write-Host $kbriefID
    $values = @{
        "ErrorMessage" = $errorMessage
        "Error" = $true
    }

    $output = Set-PnPListItem -Identity $kbriefID -List $listKBrief -Values $values -Connection $connection -UpdateType SystemUpdate 
}

function getLookUpList(){
    $array = @()
    $lookups = Get-PnPListItem -List $listKBriefLookUpList -Connection $connection

    foreach ($lookup in $lookups){
        $array += [PSCustomObject]@{ Title = $lookup["Title"]; TCCValue = $lookup["TCCValue"]}
    }
    return $array

}

function getLookUpListType($type){
    $array = @()
    $camlQuery = "<View>
      <Query>
        <Where>
            <Eq>
                <FieldRef Name='LookupType' />
                <Value Type='Text'>$($type)</Value>
            </Eq>
        </Where>
      </Query>
    </View>"

    $lookups = Get-PnPListItem -List $listKBriefLookUpList -Query $camlQuery -Connection $connection

    foreach ($lookup in $lookups){
        $array += [PSCustomObject]@{ Title = $lookup["Title"]; TCCEnumValue = $lookup["TCCEnumValue"]; ShortCode = $lookup["ShortCode"]; BackgroundColor = $lookup["BackgroundColor"]; ForegroundColor = $lookup["ForegroundColor"]}
    }
    return $array

}

function getBlockTypes(){
    $array = @()
    $lookups = Get-PnPListItem -List $listKBriefBlockType -Connection $connection

    foreach ($lookup in $lookups){
        $array += [PSCustomObject]@{ Title = $lookup["Title"]; ID = $lookup["BlockID"]}
    }
    return $array

}

function getHTMLVal($val, $kbriefID, $kbriefidsql, $blockid, $ignorefile, $imgblockpath){
    $blockPath = "$NETWORKPATH\$kbriefidsql\BLOCKS\$blockid"
    $parsedString = ""
    if ($ignorefile){
        $parsedString = [RtfPipe.Rtf]::ToHtml($val)
    } else {
        if (Test-Path -Path $blockPath){
            $firstHTMLFile = Get-ChildItem -Path $blockPath -Filter *.html -File | Select-Object -First 1
            if ($firstHTMLFile){
                $parsedString = Get-Content -Path $firstHTMLFile.FullName -Raw
                $parsedString = $parsedString.ToString()
            }
        } else {
            $parsedString = [RtfPipe.Rtf]::ToHtml($val)
        }
    }
    try{
        $parsedString = $parsedString -replace "&amp;", "&"
        $parsedString = $parsedString -replace "u?html icon", ""
        $imageSPPath = ""
        $rtfblockpath = 
        if ($parsedString.Contains("img")){
            $pattern = 'src="([^"]+)"'
            $imgs = [regex]::Matches($parsedString, $pattern)
            foreach($img in $imgs){

                $imgstr = $img.Groups[1].Value
                $imgstr = $imgstr.Replace("data:image/png;base64,", "")
                $imgGUID = New-Guid
                $outputImagePath = "$imgblockpath\$imgGUID.png"

                [byte[]]$imageBytes = [Convert]::FromBase64String($imgstr)
                [System.IO.File]::WriteAllBytes($outputImagePath, $imageBytes)

                $values = @{
                    Title = "EmbeddedImage in HTML for $($blockid)"
                    BlockID = $blockid
                    ParentID = $kbriefID
                    TCC_ImageID = 0
                    TCC_XMLID = 0
                }
                $imageSPPath = addImage $kbriefID $blockid $values $outputImagePath
                if ($imageSPPath -ne ""){
                    $parsedString = $parsedString.Replace($img.Groups[1].Value, $imageSPPath)
                }
            }
        }
    } catch {
        $errorMessage += "Error converting document in GetHTML: $($_.Exception.Message)"
        Write-Host $errorMessage -ForegroundColor Red
        updateErrorFound $kbriefID $errorMessage
    }
    return $parsedString
}


function deleteKBlocks($id){
     $camlQuery = "<View>
      <Query>
        <Where>
          <Eq>
            <FieldRef Name='ParentID' />
            <Value Type='Number'>$id</Value>
          </Eq>
        </Where>
      </Query>
    </View>"
    $items = Get-PnPListItem -List $listKBriefBlock -Query $camlQuery -Connection $connection

    if ($items.Count -gt 0){
        $dbatch = New-PnPBatch -Connection $connection
        Write-Host "Deleting $($items.Count)"
        foreach($item in $items){
            Remove-PnPListItem -List $listKBriefBlock -Identity $item["ID"] -Connection $connection -Batch $dbatch
        }
        Invoke-PnPBatch $dbatch -Connection $connection
    }
}

function getImages($kbriefid, $kbriefblockid, $imagesPath){
    $query = "SELECT 
           image, 
          kbrief_block_small_image_id
    FROM [tcc_sbtdb].[dbo].[kbrief_block_small_images]
    WHERE kbrief_id = $kbriefid and block_id = $kbriefblockid and len(image) > 1"

    $connectionString = "Server=$serverInstance;Database=$databaseName;User ID=$sqlUserName;Password=$sqlpassword;"

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()

    # Create command
    $command = $connection.CreateCommand()
    $command.CommandText = $query

    $reader = $command.ExecuteReader()

    $arrImages = @()

    if ($reader.Read()) {
        $bufferSize = 1024 * 4
        do{
            $guid = New-Guid
            $outputPath = "$imagesPath\$guid.jpg" # Specify your desired output path and filename
            
            $outputStream = [System.IO.File]::OpenWrite($outputPath)
            $startIndex = 0
            $bytesRead = 0
            $buffer = New-Object byte[] $bufferSize
            do {
                $bytesRead = $reader.GetBytes(0, $startIndex, $buffer, 0, $bufferSize)
                $outputStream.Write($buffer, 0, $bytesRead)
                $startIndex += $bytesRead
            } while ($bytesRead -eq $bufferSize)

            $outputStream.Close()

            $image = [System.Drawing.Image]::FromFile($($outputPath));
            $filePath = [IO.Path]::ChangeExtension($outputPath, '.png');
            $image.Save($filePath, [System.Drawing.Imaging.ImageFormat]::Png);
            $image.Dispose();

            #Write-Host $filePath -ForegroundColor Yellow

            if (Test-Path -Path $outputPath){
                Remove-Item -Path $outputPath -Force
            }

            $img = [PSCustomObject]@{ Path = $filePath; ID = $reader[1]}

            $arrImages += $img 
            #Write-Host "Image saved to $outputPath"
        } while ($reader.Read())
    }

    # Cleanup
    $reader.Close()
    $connection.Close()
    return $arrImages
}

function getAttachments($dataguid){
    $query = "SELECT 
	    original_file_name,
	    file_name
    FROM Attachments
    WHERE attachment_id = '$dataguid'"

    #Write-Host $query

    $connectionString = "Server=$serverInstance;Database=$databaseName;User ID=$sqlUserName;Password=$sqlpassword;"

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()

    # Create command
    $command = $connection.CreateCommand()
    $command.CommandText = $query

    $reader = $command.ExecuteReader()

    $arrImages = @()

    $filePath = ""
    if ($reader.Read()) {
        $filePath = $reader[1]

    }
    return $filePath
}

function checkKBriefExists($guid){
    $camlQuery = "<View>
      <Query>
        <Where>
          <Eq>
            <FieldRef Name='TCC_GUID' />
            <Value Type='Text'>$guid</Value>
          </Eq>
        </Where>
      </Query>
    </View>"

    $item = Get-PnPListItem -List $listKBrief -Query $camlQuery -Connection $connection

    if ($item.Count -gt 1){
        return $item[0]
    } else {
        return $item
    }
}

function checkKBriefBlockExists($id, $parentid){
    $camlQuery = "<View>
      <Query>
        <Where>
            <And>
                  <Eq>
                    <FieldRef Name='TCC_KBriefBlockID' />
                    <Value Type='Number'>$id</Value>
                  </Eq>
                  <Eq>
                    <FieldRef Name='ParentID' />
                    <Value Type='Number'>$parentid</Value>
                </Eq>
            </And>
        </Where>
      </Query>
    </View>"

    $item = Get-PnPListItem -List $listKBriefBlock -Query $camlQuery -Connection $connection

    if ($item.Count -gt 1){
        return $item[0]
    } else {
        return $item
    }
}


function checkKBriefBlockSectionExists($id, $parentid){
    $camlQuery = "<View>
      <Query>
        <Where>
            <And>
                  <Eq>
                    <FieldRef Name='KBRiefID' />
                    <Value Type='Number'>$id</Value>
                  </Eq>
                  <Eq>
                    <FieldRef Name='ParentID' />
                    <Value Type='Number'>$$parentid</Value>
                </Eq>
            </And>
        </Where>
      </Query>
    </View>"

    $item = Get-PnPListItem -List $listKBriefBlockSections -Query $camlQuery -Connection $connection

    if ($item.Count -gt 1){
        return $item[0]
    } else {
        return $item
    }
}


function checkKBriefBlockExistsSequence($id, $sequence, $parentid){
    $camlQuery = "<View>
      <Query>
        <Where>
          <And>
            <And>
                  <Eq>
                    <FieldRef Name='TCC_KBriefBlockID' />
                    <Value Type='Number'>$id</Value>
                  </Eq>
                  <Eq>
                    <FieldRef Name='Sequence' />
                    <Value Type='Number'>$sequence</Value>
                </Eq>
            </And>
            <Eq>
                <FieldRef Name='ParentID' />
                <Value Type='Number'>$parentid</Value>
            </Eq>
          </And>
        </Where>
      </Query>
    </View>"

    $item = Get-PnPListItem -List $listKBriefBlock -Query $camlQuery -Connection $connection

    return $item
}

function checkImageExists($id, $type, $parentid, $blockid){

    $path = "$pathURL/$libraryImages/$parentid/$blockid"

    if ($type -eq "IMAGE"){
        $camlQuery = "<View Scope='Recursive'>
                        <Query>
                            <Where>
                                <And>
                                    <And>
                                        <Eq>
                                            <FieldRef Name='BlockID' />
                                            <Value Type='Number'>$blockid</Value>
                                        </Eq>
                                        <Eq>
                                            <FieldRef Name='ParentID' />
                                            <Value Type='Number'>$parentid</Value>
                                        </Eq>
                                    </And>
                                    <And>
                                        <Eq>
                                            <FieldRef Name='TCC_ImageID' />
                                            <Value Type='Number'>$id</Value>
                                        </Eq>
                                        <Eq>
                                            <FieldRef Name='FileRef' />
                                            <Value Type='Text'>$path</Value>
                                        </Eq>
                                    </And>
                                </And>
                            </Where>
                        </Query>
                    </View>"
    } else {
        $camlQuery = "<View Scope='Recursive'>
        <Query>
            <Where>
                <And>
                    <And>
                        <Eq>
                            <FieldRef Name='ParentID' />
                            <Value Type='Number'>$parentid</Value>
                        </Eq>
                        <Eq>
                            <FieldRef Name='BlockID' />
                            <Value Type='Number'>$blockid</Value>
                        </Eq>
                    </And>
                  <Eq>
                    <FieldRef Name='TCC_XMLID' />
                    <Value Type='Number'>$id</Value>
                  </Eq>
              </And>
            </Where>
          </Query>
        </View>"

    }
    
    #Write-Host $camlQuery
    $item = Get-PnPListItem -List $libraryImages -Query $camlQuery -Connection $connection
    if ($item.Count -gt 1){
        return $item[0]
    } else {
        return $item
    }
}

function getBlockType($blockid){

    $camlQuery = "<View Scope='Recursive'>
        <Query>
            <Where>
                <Eq>
                    <FieldRef Name='BlockID' />
                    <Value Type='Number'>$blockid</Value>
                </Eq>
            </Where>
          </Query>
        </View>" 
    $item = Get-PnPListItem -List $listKBriefBlockType -Query $camlQuery -Connection $connection
    if ($item.Count -gt 1){
        return $item[0]
    } else {
        return $item
    }
}

function convertFileToBlockImageFound($capture, $extrFilePath, $i, $kbriefID, $heading, $kbrief_block_id, $block_id){

    $pattern = 'src="([^"]+)"'
    $imgs = [regex]::Matches($capture, $pattern)
    $rootFolder = $null
    $folder = $null
    if ($imgs.Count -gt 0){
        $imgCounter = 0
        $blockid = ($i + 1)

        $rootFolder = $null
        $folder = $null
        try{
            $rootFolder = Get-PnPFolder -Url "$libraryImages/$kbriefID" -Connection $connection
        } catch {}
        if (!$rootFolder){
            $rootFolder = Add-PnPFolder -Name $kbriefID -Folder $libraryImages -Connection $connection
        } 
        if ($rootFolder){
            try{
                $folder = Get-PnPFolder -Url "$libraryImages/$kbriefID/$blockid" -Connection $connection
            } catch {}
            if (!$folder){
                $folder = Add-PnPFolder -Name $blockid -Folder "$libraryImages/$kbriefID" -Connection $connection
            } 
        }
    }


    foreach($img in $imgs){
        $imgCounter++

        $imgPath = $img.Groups[1].Value
        #Write-Host $imgCounter $imgPath  -ForegroundColor Cyan
        $imgPath = $imgPath.Replace("/", "\")
        $filePath = "$extrFilePath\$($imgPath)"
        <#$imgExists = checkImageExists $imgCounter "IMAGE" $kbriefID $blockid
        if ($imgExists -eq $null){
            Write-Host "image Doesn't Exsist"
            if ($folder){
                try{
                    $values = @{
                        Title = $heading
                        BlockID = $blockid
                        ParentID = $kbriefID
                        TCC_ImageID = $imgCounter
                        TCC_XMLID = 0
                    }
                    $file = Add-PnPFile -Path $filePath -Folder $folder.ServerRelativeUrl -Values $values -Connection $connection
                    $imageSPPathIcon = $baseURL + $file.ServerRelativeUrl 
                } catch {
                    Write-Host "Error Adding File $filePath to $folder.ServerRelativeUrl" $_ -ForegroundColor Red
                }
            }
        } else {
            $imageSPPathIcon = $baseURL + $imgExists["FileRef"]
            #Write-Host "File Exists $imageSPPathIcon" -ForegroundColor Yellow
        }#>

        $imageBytes = [System.IO.File]::ReadAllBytes($filePath)
        $base64String = [Convert]::ToBase64String($imageBytes)
        $imageSPPathIcon = "data:image/png;base64,$base64String"

        $embeddedfilePath = "$extrFilePath\word\embeddings\"
        $attachmentePath = ""
        if (Test-Path $embeddedfilePath){
            #Write-Host "Found Embedded File " $embeddedfilePath
            $epath = (Get-ChildItem -Path $embeddedfilePath | Sort-Object | Select-Object -First 1).Name
            $epath = "$embeddedfilePath/$epath"
            #Write-Host $epath
            $attachmentePath = ""
            if ($ePath -ne $null){
                
                $values = @{
                    Title = $heading
                    BlockID = $block_id
                    ParentID = $kbriefID
                    TCC_GUID = ""
                    OriginalPath = $epath
                }
                $attachmentePath = addAttachment $kbriefID $values $epath
            }
        }
        #Write-Host $imageSPPathIcon " : " $attachmentePath -ForegroundColor Cyan 
        if ($imageSPPathIcon -ne ""){
            if ($attachmentePath -ne ""){
                $capture =  "<a href='" + $attachmentePath + "' target='_blank'>" + $capture.Replace($($img.Groups[1].Value), $imageSPPathIcon) + "</a>"
            } else {
                $capture = $capture.Replace($($img.Groups[1].Value), $imageSPPathIcon)
            }
        }
    }
    return $capture
}
    
function convertFileToBlock($htmlPath, $htmlFilePath, $kbrief_block_id, $created, $sequence, $block_id, $blocktypesused, $parentid){
    $newblock = $null
    $blockarray = @()
    try{
      
        $htmlContent = Get-Content $htmlFilePath -Raw
        if (![string]::IsNullOrWhiteSpace($htmlContent)){
            $htmlContent = $htmlContent -replace "</?(html|body)[^>]*>", ""
        }
        #Write-Host $htmlContent

        $keyWord = "<div style='border:none;border-top:solid windowtext 1.0pt;"
        #$keyWord = "<div style='border:none;border-top:solid windowtext 1.0pt;"


        $positions = [regex]::Matches($htmlContent, $keyWord , 'IgnoreCase') | ForEach-Object { $_.Index }

        $kbbodies = @()
        $precedinghasBody = $true
        $precedingHTML = ""
        $heading = ""


        $wordSectionRegEx = "<div class=WordSection1>"
        $wordSections = [regex]::Matches($htmlContent, $wordSectionRegEx, 'IgnoreCase') | ForEach-Object { $_.Index }

        $positionArray = @()

        If ($wordSections.Count -gt 0 -and $positions.Count -gt 0){
            $wordSectionFirstCount = $wordSections[0]
            $positionsFirstCount = $positions[0]
            $strVal = $htmlContent.Substring(($wordSectionFirstCount + $wordSectionRegEx.Length), ($positionsFirstCount - $wordSectionFirstCount - $wordSectionRegEx.Length))
    
            if ($strVal.Trim() -ne ""){
                $positionArray += ($strVal)    
            }
        }

        for($i=0; $i -lt $positions.Count; $i++){
            $len = 0
            $strVal = ""
            if($i -eq ($positions.Count - 1)){
                $len = $htmlContent.Length - $positions[$i]
            } else {
                $len = $positions[$i + 1] - $positions[$i]
            }
            $strVal = $htmlContent.Substring($positions[$i], $len)
            if ($strVal.Trim() -ne ""){
                $positionArray += ($strVal)    
            }
        }

        foreach($position in $positionArray){
            Write-Host "++++++++++++++++++++++++++++++++++"
            $strVal = $position
            $strVal = clearUnclosedDiv $strVal

            #Write-Host $strVal -ForegroundColor Cyan
            #Write-Host "================================"
            #EXTRACT TITLE FROM P
            #Write-Host $strVal
            if ($strVal.Contains("KBHeading")){
                #$pattern = '<p\s+class=KBHeading[^>]*>(.*?)</p>'
                $pattern = '<p\s+class=KBHeading[^>]*>([\s\S]*?)</p>'
                    # Use [regex]::Match
                $match = [regex]::Match($strVal, $pattern)
                $tempHeading = $match.Groups[1].Value
                if (![string]::IsNullOrWhiteSpace($tempHeading)){
                    $tempHeading = $tempHeading.Replace("`r`n", " ").Replace("&amp;", "&")
                }
                $tempHeading = cleanHeader $tempHeading
                Write-Host $tempHeading -ForegroundColor Green
                if (![string]::IsNullOrWhiteSpace($strVal)){
                    #Remove Header from String so we don't double up
                    If(![string]::IsNullOrWhiteSpace($match.Captures)){
                        $strVal = $strVal.Replace($match.Captures, "")
                    }
                }
            }

            if ($tempHeading -match "<[^>]+>") {
                $heading = parseHTMLFromString $tempHeading
                if ([string]::IsNullOrWhiteSpace($strVal)) { 
                    $strVal = $tempHeading
                }
            } else {
                $heading = $tempHeading
            }
            $body = $strVal
            if ($body.Contains("img")){
                Write-Host "Has Image" -ForegroundColor Cyan
                $body = convertFileToBlockImageFound $body $htmlPath $i $kbriefID $heading $kbrief_block_id $block_id
            }
            if (![string]::IsNullOrWhiteSpace($body)){
                $body = $body.Replace("<p class=KBNormal>&nbsp;</p>", "")
            }

            $addKBody = $true
            #Write-Host $body -ForegroundColor Cyan
            if ([string]::IsNullOrWhiteSpace($body) -and [string]::IsNullOrWhiteSpace($tempHeading)){
                Write-Host "Do Nothing"
            } else {
                $body = $body.Trim()
                $kbbody = [PSCustomObject]@{ Heading = $tempHeading; Body = $body; Sequence = $sequence}
                $kbbodies += $kbbody 
                #$precedinghasBody = $true
            }
        }
        $blocktype = $blockTypeArray | Where-Object { $_.ID -eq $DEFAULTBLOCKID }
        #$blocktype = getBlockType $DEFAULTBLOCKID
        if (!$blocktypesused.Contains($blocktype.Title)){
            $blocktypesused += $blocktype.Title + ";"
        }
        $blockcreated = $false

        #$batch = New-PnPBatch -Connection $connection

        $titles = ""
        foreach ($kbbody in $kbbodies){
            
            $blockcreated = $true


            $blockheading = if ([string]::IsNullOrWhiteSpace($kbbody.Heading)) { "Blank" } else { $kbbody.Heading }
            #Write-Host $kbrief_block_id $sequence $parentid -ForegroundColor Cyan
            #$kbriefblockseq = checkKBriefBlockExistsSequence $kbrief_block_id $sequence $parentid DOES NOTHING RETURED 16/3/26
        
            $blockheading = cleanString $blockheading
            $blockbody = cleanString $kbbody.Body
            if ([string]::IsNullOrWhiteSpace($blockbody)) { 
                $blockbody = $blockheading
            }
            
            $blockheadingparsed = parseHTMLFromString $blockheading
            $cleanedHeader = cleanString $blockheadingparsed
            $titles += ($cleanedHeader + ";")
            
            $newblock = [PSCustomObject]@{
                Title = $cleanedHeader
                ParentID = $kbriefID
                KBrief = $kbriefID
                BlockTypeID = $blocktype["ID"]
                BlockType = $blocktype.Title
                Explanation = $blockbody
                Sequence = $sequence
                TCC_ExplanationText = ""
                TCC_Explanation = ""
                TCC_BlockTypeID = $DEFAULTBLOCKID
                TCC_Sequence = $sequence
                TCC_KBriefBlockID = $kbrief_block_id
                Hidden = $false
                Created = $created
                LinkedKBriefID = 0
                LinkedKBriefBlockID = 0
                HasBulletedList = ""
                Source = 1
                XMLData = ""
                SPID = 0
            }
            $blockarray += $newblock 
        }
    } catch {
        $errorMessage += "Error converting document in converFileToBlock: $($_.Exception.Message)"
        Write-Host $errorMessage -ForegroundColor Red
        updateErrorFound $kbriefID $errorMessage

    }
    return $blockarray 
}


function Save-HtmlImagesAndRewrite {
    param(
        [string]$HtmlString,
        [string]$FolderPath = ""  # Optional subfolder
    )

    # Connect to SharePoint
    # Extract all <img src="...">
    $imgMatches = [regex]::Matches($HtmlString, '<img[^>]+src=["'']([^"'']+)["'']', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)

    # Dictionary to map original src -> SharePoint URL
    $srcMap = @{}

    foreach ($match in $imgMatches) {
        $src = $match.Groups[1].Value
        $fileName = "Image_" + [guid]::NewGuid() + ".png"


        # Temporary local path
        $tempPath = Join-Path $env:TEMP $fileName

        # Handle base64 images
        if ($src -match '^data:image/(?<ext>\w+);base64,(?<data>.+)$') {
            $ext = $matches['ext']
            $data = $matches['data']
            $fileBytes = [System.Convert]::FromBase64String($data)
            Set-Content -Path $tempPath -Value $fileBytes -Encoding Byte
        }

        # Upload to SharePoint
        try{
            
            $folderServerRelative = if ($FolderPath -ne "") { "$pathURL/$libraryImages/$FolderPath" } else { "$pathURL/$libraryImages" }
            $folder = $null
            try{
                $folder = Get-PnPFolder -Url $folderServerRelative -Connection $connection
            } catch {
            }
            if (-not $folder -and $FolderPath) {
                # Folder doesn’t exist — create it
                $folder = Add-PnPFolder -Name $FolderPath -Folder $libraryImages -Connection $connection
            }
            $uploadedFile = Add-PnPFile -Path $tempPath -Folder $folder.ServerRelativeUrl -Connection $connection
        } catch {
            $srcMap[$src] = ""
        }

        # Clean up temp file
        Remove-Item $tempPath -Force

        # Map original src -> SharePoint URL
        $srcMap[$src] =  $baseURL + $uploadedFile.ServerRelativeUrl
    }

    # Rewrite HTML to point to SharePoint URLs
   
    foreach ($key in $srcMap.Keys) {
        $encodedUrl = $srcMap[$key] -replace ' ', '%20'
        $HtmlString = $HtmlString.Replace($key, $encodedUrl)
    }
    return $HtmlString
}

cls

# Load configuration from config.ps1 (excluded from source control)
$configPath = Join-Path $PSScriptRoot "..\config.ps1"
if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: config.ps1 not found at $configPath" -ForegroundColor Red
    Write-Host "Copy Scripts/config.example.ps1 to Scripts/config.ps1 and fill in your values." -ForegroundColor Yellow
    exit 1
}
. $configPath

# Derive environment-specific settings from $environment in config.ps1
if ($environment -eq "DEV") {
    $powerAppURL = "https://apps.powerapps.com/play/e/ca2d799d-2eb6-e2ab-9f92-9903f04294c9/a/c7272186-b20e-40f0-afc0-1bc3f0a5b379?tenantId=263a7cc6-04d1-402b-9f10-fd15e54c48d6&hidenavbar=true&kbriefid"
    $pathURL = "/sites/app-tcc-dev"
} elseif ($environment -eq "UAT") {
    $powerAppURL = "https://apps.powerapps.com/play/e/4a242bad-05a3-e657-b186-df4e586cb9cc/a/c00751c0-21bc-4242-8f3a-4ab08de78127?tenantId=263a7cc6-04d1-402b-9f10-fd15e54c48d6&hidenavbar=true&kbriefid"
    $pathURL = "/sites/app-tcc-uat"
} else {
    $powerAppURL = "https://apps.powerapps.com/play/e/8e2d98fa-67b2-ea12-bd4a-f79407124ac9/a/7c8ceee3-7983-4534-99bc-f30c85135d4d?tenantId=263a7cc6-04d1-402b-9f10-fd15e54c48d6&hidenavbar=true&kbriefid"
    $pathURL = "/sites/app_powera3"
}

$urlTextToReplace  = "http://localhost:24680/OpenKBrief?id"
$urlTextToReplace2 = "http://localhost:24680/"
$urlTextToReplace3 = "OpenKBrief?id"
$urlTextToReplace3a = "?id"

$baseURL = "https://fisherpaykel.sharepoint.com"

$downloadPathOrig = "$PSScriptRoot\Processing"

$DEFAULTBLOCKID  = 9
$TABLEBLOCKTYPEID = 10
$MINIMG          = 1000
$EXTRACTBLOCK    = "The Original K-Brief Document"

$SecurePassword = ConvertTo-SecureString -String $CertPassword -AsPlainText -Force
$connection = Connect-PnPOnline -Url "$baseURL/$pathURL" -ClientId $clientID -Tenant $tenantName -CertificatePath $CertPath -CertificatePassword $SecurePassword -ReturnConnection

$lookupArray = getLookUpList
$blockTypeArray = getBlockTypes

$lookupArrayActivation = getLookUpListType "Plan Activation Status"
$lookupArrayProgress = getLookUpListType "Plan Progress"
﻿function processKBrief () {
    
    foreach ($kbrief in $kbriefs){
        $guid = New-Guid
        $hasConnection = $true
        $continue = $true
        $blockArray = @()
        $result = @()
        $kbriefhtml = ""
        try{
            $queryTestConnection = "SELECT TOP 1 kbrief_id FROM kbriefs"
            $testConnect = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query  $queryTestConnection -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate 
        } catch {
            Write-Host "Caught a connection error:" -ForegroundColor Red
            $hasConnection = $false
        }

        if (!$hasConnection){
            $continue = $false
            return
        }

        $blocktypesused = ""
        $errorMessage = ""
        $dtStartTime = Get-Date
        $blockmainadded = $false
        $processcounter++
        $kbriefidsql = $kbrief.kbrief_id

        Write-Host "***************************************************" -ForegroundColor Cyan
        Write-Host "$processcounter Processing " $kbriefidsql " : " $kbrief.kbrief_name -ForegroundColor Cyan

        
        $downloadPath = "$downloadPathOrig\kbrief_$($guid)"

        if (Test-Path $downloadPath){
            Remove-Item -Path $downloadPath -Force
        }
        New-Item -Path $downloadPath -ItemType Directory  | Out-Null

        
        $spKbrief = checkKBriefExists $kbrief.kbrief_guid

              
        if ($spKbrief -and !$REPROCESS){
            Write-Host "Ignore as ReProcess = $REPROCESS" $spKbrief["ID"] -ForegroundColor Green
            $continue = $false
        }

        if ($continue -and $hasConnection){
            if ($spKbrief -and $DELETEBLOCKS){
                Write-Host "Delete All Blocks for " $spKbrief["ID"] -ForegroundColor Green
                deleteKBlocks $spKbrief["ID"]
            }
            $kbstatus = ""
            $kbtccStatus = ""
            switch ($kbrief.status){
                -3{ 
                    $kbtccStatus = "Importing";
                    $kbStatus = "Draft" 
                  }
                -2{ 
                    $kbtccStatus = "Creating";
                    $kbStatus = "Draft" 
                  }
                -1{ 
                    $kbtccStatus = "Obsolete"
                    $kbStatus = "Draft"  
                  }
                0 { 
                    $kbtccStatus = "Approved"
                    $kbStatus = "Approved" 
                  }
                1 { 
                    $kbtccStatus = "Draft"
                    $kbStatus = "Draft"  
                  }
                2 { 
                    $kbtccStatus = "Discussion"
                    $kbStatus = "Draft"  
                  }
                3 { 
                    $kbtccStatus = "Completed"
                    $kbStatus = "Approved"  
                  }
                4 { 
                    $kbtccStatus = "Template"
                    $kbStatus = "Draft"  
                  }                
                5 { 
                    $kbtccStatus = "Implemented"
                    $kbStatus = "Approved"  
                  }
                6 { 
                    $kbtccStatus = "Checked" 
                    $kbStatus = "Approved"  
                  }
            }

            


            $kbrieftypevalue = $lookupArray | Where-Object { $_.TCCValue -eq $kbrief.kbrief_type }


            $ownerName = cleanOwnerName $kbrief.TeacherDisplayName
            #TCC Columns are for legacy information
            $dt = Get-Date
            $kbriefobj = @{
                "Title" = $kbrief.kbrief_name
                "KB_Description" = $kbrief.description
                "KB_Type" = $kbrieftypevalue.Title
                "TCC_GUID" = $kbrief.kbrief_guid
                "TCC_ID" = $kbriefidsql
                "Created" = $kbrief.creation_date
                "KB_OwnerDisplayName" = $ownerName
                "KB_OwnerEmail" = $kbrief.TeacherEmail
                "Status" = $kbstatus
                "TCC_Status" = $kbtccstatus
                "TCC_Category" = $kbrief.category
                "TCC_LastModified" = $kbrief.last_edited
                "TCC_DocumentMode" = $kbrief.document_mode
                "Imported_Date" = $dt
                "Error" = $false
                "ErrorMessage" = ""
                "TCC_KBriefType" = $kbrief.kbrief_type
                "TCC_StatusID" = $kbrief.status
                "ImportBatch" = $importBatch
            }


            if (![string]::IsNullOrWhiteSpace($kbrief.due_date)){
                $kbriefobj.Add("KB_DueDate", $kbrief.due_date)
            }

            if (![string]::IsNullOrWhiteSpace($kbrief.last_edited_categories)){
                $kbriefobj.Add("KB_LastModified_Categories", $kbrief.last_edited_categories)
            }

            if (![string]::IsNullOrWhiteSpace($kbrief.last_edited_editors)){
                $kbriefobj.Add("KB_LastModified_Editors", $kbrief.last_edited_editors)
            }

            if (![string]::IsNullOrWhiteSpace($kbrief.last_edited_teachers)){
                $kbriefobj.Add("KB_LastModified_Owners", $kbrief.last_edited_teachers)
            }

            if (![string]::IsNullOrWhiteSpace($kbrief.TeacherEmail)){
                $user = Get-PnPUser -Connection $connection | ? Email -eq $kbrief.TeacherEmail
                if ($user -ne $null){
                    $kbriefobj.Add("KB_Owner", $kbrief.TeacherEmail)
                } else {
                    #Write-Host "$($kbrief.TeacherEmail) Teacher not Found"
                    try{
                        $User = New-PnPUser -Connection $connection -LoginName $kbrief.TeacherEmail
                    } catch {
                    }
                    if ($user -ne $null){
                        $kbriefobj.Add("KB_Owner", $kbrief.TeacherEmail)
                    } else {
                
                    }
                }
            }

            if (![string]::IsNullOrWhiteSpace($kbrief.AssignedToEmail)){
                $kbriefobj.Add("KB_AssignedToDisplayName", $kbrief.AssignedDisplayName)
                $kbriefobj.Add("KB_AssignedToEmail", $kbrief.AssignedToEmail)        
                $user = Get-PnPUser -Connection $connection | ? Email -eq $kbrief.AssignedToEmail
                if ($user -ne $null){
                    $kbriefobj.Add("KB_AssignedTo", $kbrief.AssignedToEmail)
                } else {
                    try{
                        $User = New-PnPUser -Connection $connection -LoginName $kbrief.AssignedToEmail
                    } catch {
                    }
                    if ($user -ne $null){
                        $kbriefobj.Add("KB_AssignedTo", $kbrief.TeacherEmail)
                    } else {
                        #Write-Host "$($kbrief.AssignedToEmail) Assigned To not Found"
                    }
            
                }
            }
            #Write-Host ($kbriefobj | ConvertTo-Json)

            if ($spKbrief -eq $null){
                Write-Host "Add New KBrief"
                $output = Add-PnPListItem -List $listKBrief -Values $kbriefobj -Connection $connection
            } else {
                Write-Host "Update KBrief"
                $output = Set-PnPListItem -Identity $spKbrief["ID"] -List $listKBrief -Values $kbriefobj -Connection $connection -UpdateType SystemUpdate
            }

            $created = $output["Created"]
            $kbriefID = $output["ID"]


            $hasKBriefDocument = $false
            $outXMLPath = ""

            $docxPath = "$NETWORKPATH\$($kbriefidsql)\DOCX"

            #Write-Host $docxPath -ForegroundColor Cyan
            $docxPathFile = ""
            if (Test-Path $docxPath){
            #if (![string]::IsNullOrWhiteSpace($kbrief.kbrief_document)){
                $firstDocxFile = Get-ChildItem -Path $docxPath -Filter *.docx -File | Select-Object -First 1
                $docxPathFile = ""
                
                if ($firstDocxFile -ne $null){
                    $docxPathFile = $firstDocxFile.FullName
                }

                Write-Host "Has KBrief Attachment $docxPathFile so Process" -ForegroundColor Cyan

                if (Test-Path $docxPathFile){
                    $hasKBriefDocument = $true
                    $values = @{
                        Title = "Published Document"
                        BlockID = 0
                        ParentID = $kbriefID
                    }
                    $attachmentXMLPath = addAttachment $kbriefID $values $docxPathFile
                    if ($attachmentXMLPath -ne ""){
                        $values = @{
                            "KB_Document_Path" = $attachmentXMLPath
                        }
                        $output = Set-PnPListItem -Identity $kbriefID -List $listKBrief -Values $values -Connection $connection -UpdateType SystemUpdate
                    }
                    Write-Host "File Uploaded to $attachmentXMLPath"
                }

            }

            if ($RUNBLOCKS){
                 if ($KBRIEF_BLOCK_DEBUG -gt 0){
                    $queryBlocks = "SELECT 
	                    kb.kbrief_id,
	                    kb.kbrief_guid,
	                    kb.kbrief_name,
	                    kb.kbrief_type,
	                    kb.creation_date,
	                    kbb.kbrief_block_id,
	                    kbb.block_id,
	                    kbb.block_type_id,
	                    kbb.data_guid_id,
	                    kbb.heading,
	                    kbb.heading_style,
	                    kbb.sequence,
	                    kbb.explanation_text,
	                    kbb.explanation, 
                        kbb.hidden,
                        kbb.data_string,
                        CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
                    FROM kbriefs KB INNER JOIN 
                    kbrief_blocks KBB ON KB.kbrief_id = KBB.kbrief_id
                    WHERE KB.kbrief_id = $kbriefidsql and kbb.kbrief_block_id = $KBRIEF_BLOCK_DEBUG
                    ORDER BY KBB.sequence"
                } else {
                    $queryBlocks = "SELECT 
	                    kb.kbrief_id,
	                    kb.kbrief_guid,
	                    kb.kbrief_name,
	                    kb.kbrief_type,
	                    kb.creation_date,
	                    kbb.kbrief_block_id,
	                    kbb.block_id,
	                    kbb.block_type_id,
	                    kbb.data_guid_id,
	                    kbb.heading,
	                    kbb.heading_style,
	                    kbb.sequence,
	                    kbb.explanation_text,
	                    kbb.explanation,
                        kbb.hidden,
                        kbb.data_string,
                        CASE WHEN KBB.data_string LIKE '%\conversions\%' and KBB.heading = 'The Original K-Brief Document' THEN 1 ELSE 0 END as ConvertRequired
                    FROM kbriefs KB INNER JOIN 
                    kbrief_blocks KBB ON KB.kbrief_id = KBB.kbrief_id
                    WHERE KB.kbrief_id = $kbriefidsql 
                    ORDER BY KBB.sequence"

                }
                $headers = ""
                $blocks = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query $queryBlocks -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 20000000
                $countRows = 0
                $sequence = 0

                if ($kbrief.kblockcount -eq 0 -and $hasKBriefDocument){
                    #NO BLOCKS BUT HAS ATTACHMENT, TRY CONVERT ATTACHMENT TO BLOCKS
                    #MAKE SURE THE DOCX SCRIPT USES BLOCKCOUNT OF 0    
                    if (Test-Path $docxPath){
                        Write-Host $docxPath -ForegroundColor Yellow
                        $firstHTMLFile = Get-ChildItem -Path $docxPath -Filter *.html -File | Select-Object -First 1
                        if ($firstHTMLFile){
                            $path = "$docxPath\$($firstHTMLFile.Name)"
                            Write-Host "Found $path" -ForegroundColor Yellow
                            $blockArray = convertFileToBlock $docxPath $path  1 $created $sequence 1 $blocktypesused $kbriefID

                            #Write-Host "Sequence: "  $obj.Sequence $obj.Headers -ForegroundColor Cyan
                            #if ($obj){
                            #    if (!$blocktypesused.Contains($obj.BlockType)){
                            #        $blocktypesused = $obj.BlockType
                            #    }
                            #    $sequence = $obj.Sequence
                            #    $headers = $obj.Headers
                            #}    
                        }
                    
                    } 
                }

                #$batch = New-PnPBatch -Connection $connection
                $blockcounter = 0

                $blockcount = $blocks.Count
               
                foreach ($block in $blocks){
                    Write-Host "++++++++++++++++++"
                    $blockHeading =  if ([string]::IsNullOrWhiteSpace($block.heading)) { "Blank" } else { $block.heading }
                 
                    Write-Host $blockHeading

                    $blockcounter++
                    $blocktypeid = $block.block_type_id
                    $blockid = $block.block_id
                    $blockguid = New-Guid
                    $blockpath = "$downloadPath\$($blockguid)"
                    #Write-Host $block.heading -ForegroundColor Cyan
                    $hasBulletedList = $false
                    $dataString = $block.data_string

                    $linkedid = 0
                    $linkedblockid = 0
                    if ($dataString -ne "" -and $blocktypeid -eq 32){
                        $linkedid, $linkedblockid = parseDataString $dataString 
                    }
                
                    New-Item -Path $blockpath -ItemType Directory -Force | Out-Null
                
                    $sequence++
                    $blockcreated = $false
                    $hidden = $false
                    if ($block.hidden -eq 1){
                        $hidden = $true
                    }
                    $blockcontinue = $true
                    $kbriefblock = checkKBriefBlockExists $block.kbrief_block_id $kbriefID
                    if ($kbriefblock -ne $null -and !$REPROCESSBLOCK){
                        $blockcontinue = $false
                    }

                    if ($blockcontinue){

                        $countRows++
                        #Write-Host "Counter $countRows" -ForegroundColor Green
                        #Write-Host "*************************" -ForegroundColor Green
                        $parsedString = ""
                        $strCompHTML = ""
                        $data = ""
                        $val = $block.explanation
                        Write-Host "Block Type ID: " $blocktypeid -ForegroundColor Yellow
                        if ($blocktypeid -eq 5){
                            $strCompHTML = getComputationHTML $kbriefidsql  
                        } elseif($blocktypeid -eq 4){
                            $strCompHTML = getRelatedDecision $kbriefidsql  
                        } elseif($blocktypeid -eq 2){
                            $strCompHTML = getCalculationHTML $kbriefidsql  
                        } elseif($blocktypeid -eq 34){
                            $strCompHTML = getPlanningActions $kbriefidsql $blockid
                        } elseif($blocktypeid -eq 33){
                            $strCompHTML = getIdeasHTML $kbriefidsql $blockid
                        }
                        
                        if ($val.Contains("\u61557 ?\tab")){
                            Write-Host "Has Bulleted List" -ForegroundColor Cyan
                            $hasBulletedList = $true
                        }
                        #$rtfblockpath = "$blockpath\RTF"
                        #New-Item -Path $rtfblockpath -ItemType Directory -Force | Out-Null

                        $imageSPPath = ""
                        $imgblockpath = "$blockpath\Images"
                        New-Item -Path $imgblockpath -ItemType Directory -Force | Out-Null

                        if ([string]::IsNullOrWhiteSpace($val)){
                            $parsedString = $block.explanation_text
                            if (![string]::IsNullOrWhiteSpace($parsedString)){
                                $parsedString = $block.explanation_text.Replace("`r`n", "<br>").Replace("`r", "<br>").Replace("`n", "<br>")
                            }
                        } else {
                            $parsedString = getHTMLVal $val $kbriefID $kbriefidsql $blockid $false $imgblockpath 
                        }

                        #Write-Host "Parsed String:" $parsedString -ForegroundColor Cyan

                        

                        $images = getImages $kbriefidsql $block.block_id $imgblockpath
                        #Write-Host $kbriefidsql $block.block_id $images.Length $block.kbrief_block_id -ForegroundColor White
                        foreach ($image in $images){
                            #Write-Host $image.Path $image.ID -ForegroundColor Green
                            $processimage = $true
                            if ($blocktypeid -eq 33){
                                if ($strCompHTML -ne ""){
                                    $processimage = $false
                                }
                            }

                            if ($processimage){
                                Write-Host "Process Image $($image.Path)" -ForegroundColor Green
                                $imageBytes = [System.IO.File]::ReadAllBytes($image.Path)
                                $base64String = [Convert]::ToBase64String($imageBytes)
                                $imageSPPath = "data:image/png;base64,$base64String"
                                #$imageSPPath = checkImageExists $image.ID "IMAGE" $kbriefID $block.block_id
                                #if ($imgExists -eq $null){
                                #    $values =  @{
                                #       Title = $block.heading
                                #        BlockID = $block.block_id
                                #        ParentID = $kbriefID
                                #        TCC_ImageID = $image.ID
                                #        TCC_XMLID = 0
                                #    }

                                #    $imageSPPath = addImage $kbriefID $blockid $values $image.Path
                                #} else {
                                #    $imageSPPath = $baseURL + $imgExists["FileRef"]                        
                                #}
                            }

                            $hasAttachment = $false
                            if ($imageSPPath -ne ""){
                                if (![string]::IsNullOrWhiteSpace($block.data_guid_id) -and $block.data_guid_id -ne [System.Guid]::Empty){
                                    Write-Host "Has Attachment $($block.data_guid_id)" -ForegroundColor Yellow
                                    $attPath = getAttachments $block.data_guid_id
                                    #Write-Host $attPath -ForegroundColor Yello
                                    if (![string]::IsNullOrWhiteSpace($attPath)){
                                        $parsedFileName = $attPath.Replace(".zip", "")


                                        $checkHTMLPath = "$NETWORKPATH\$($kbriefidsql)\ATTACHMENTS\$parsedFileName"
                                        Write-Host $checkHTMLPath -ForegroundColor Yellow
                                        $path = ""
                                        $extrFilePath = ""
                                        $filepath = ""
                                        if (Test-Path $checkHTMLPath){
                                            $firstHtmlFile = Get-ChildItem -Path $checkHTMLPath -Filter *.html -File | Select-Object -First 1
                                            if ( $firstHtmlFile -ne $null){
                                                $path = $firstHtmlFile.FullName
                                            }
                                            $extrFilePath = $checkHTMLPath 

                                            $firstDocxFile = Get-ChildItem -Path $checkHTMLPath -Filter *.docx -File | Select-Object -First 1
                                            if ($firstDocxFile -ne $null){
                                                $filepath = $firstDocxFile.FullName
                                            }
                                            
                                        } else {
                                            $copyFilePath = "$baseAttachmentPath$attPath"
                                            $guid = New-Guid
                                            $blockpathatt = "$blockpath\Attachments"
                                            #Write-Host $blockpathatt -ForegroundColor Cyan
                                            New-Item -Path $blockpathatt -ItemType Directory -Force | Out-Null

                                            $extrFilePath = "$blockpathatt\$guid"

                                            New-Item -Path $extrFilePath -ItemType Directory -Force | Out-Null

                                            $item = Copy-Item -Path $copyFilePath -Destination $extrFilePath
                                            try{
                                                $zip = [System.IO.Compression.ZipFile]::OpenRead("$extrFilePath\$attPath")
                                                $zipcontinue = $false
                                                $zip.Entries | ForEach-Object {
                                                    if ($_.FullName.EndsWith(".zip")){
                                                        $zipcontinue = $true
                                                    }
                                                }
                                                $zip.Dispose()
                                                if ($zipcontinue){
                                                    Write-Host "Zip file contains a ZIP file" -ForegroundColor Cyan
                                                    $filepath = "$extrFilePath\$attPath"
                                                } else {
                                                    Expand-Archive -Path "$extrFilePath\$attPath" -DestinationPath $extrFilePath -Force
                                                    
                                                    [System.IO.Compression.ZipFile]::ExtractToDirectory("$extrFilePath\$attPath", $extrFilePath) 

                                                    $path = (Get-ChildItem -Path "$extrFilePath" | Where-Object { $_.Extension -ne ".zip" } | Select-Object -First 1).Name
                                                    $path = "$extrFilePath\$path"
                                                    $filepath = $path

                                                }
                                                
                                            } catch {}

                                        }

                                        #Write-Host $path " : " $extrFilePath " : " $filepath -ForegroundColor Cyan
 
                                        if (![string]::IsNullOrWhiteSpace($filepath)){
                                            #Write-Host $block.heading " : " $EXTRACTBLOCK " : " $kbrief.kblockcount                                   
                                            #IF DOCUMENT FOUND IN BLOCK, FOR LEGACY
                                            if ($block.ConvertRequired){
                                                Write-Host "Create Blocks From Document" -ForegroundColor Yellow
                                                $blockArray = convertFileToBlock $extrFilePath $path $block.kbrief_block_id $created $sequence $block.block_id $blocktypesused $kbriefID
                                                <#Write-Host "Sequence: "  $obj.Sequence $headers = $obj.Headers -ForegroundColor Cyan
                                                if ($obj){
                                                    $blockcreated = $obj.BlockedCreated
                                                    $sequence = $obj.Sequence
                                                    if (!$blocktypesused.Contains($obj.BlockType)){
                                                        $blocktypesused = $obj.BlockType + ";"
                                                    }
                                                    $headers = $obj.Headers
                                                }#>


                                                #Write-Host $blockcreated " : " $sequence -ForegroundColor Cyan
                                            }
                                            $values = @{
                                                Title = $block.heading
                                                BlockID = $block.block_id
                                                ParentID = $kbriefID
                                                TCC_GUID = $block.data_guid_id
                                                OriginalPath = $copyFilePath
                                            }
                                            $attachmentSPPath = addAttachment $kbriefID $values $filepath
                                            if ($attachmentSPPath -ne ""){
                                                Write-Host $attachmentSPPath " added"
                                                $hasAttachment = $true
                                            }

                                        }
                                    }
                                    
                                }

                                #CHECK IF TABLE DATA IS REPRESENTED BY THE IMAGE
                                $hasTable = $false
                                if ($blocktypeid -eq $TABLEBLOCKTYPEID){
                                    Write-Host "Process Table" -ForeGroundColor Green
                                    $queryKBriefsXML = "SELECT 
                                           [xml_editor_data_id]
                                          ,[kbrief_id]
                                          ,[block_id]
                                          ,[data]
                                    FROM [tcc_sbtdb].[dbo].[xml_editor_data]
                                    WHERE kbrief_id = $($kbriefidsql) and block_id = $($block.block_id)"


                                    $kbrieftables = Invoke-Sqlcmd -ServerInstance $serverInstance -Database $databaseName -Query  $queryKBriefsXML -Username $sqlUserName -Password $sqlpassword -TrustServerCertificate -MaxCharLength 40000000
                                    $data = ""
                                    foreach($kbrieftable in $kbrieftables){
                                        $data += $kbrieftable.data
                                    }
                                
                                    $strHTML = ""
                                    if(![string]::IsNullOrWhiteSpace($data)){
                                        Write-Host "XML Found" -ForegroundColor Cyan
                                        #CHANGE 10/9
                                        $rowCounter = 0;
                                        $colCounter = 0;
                                        $bufferSize = 1024 * 4
                                        $noCols = 0
                                        $data = $data.Replace("&lt;", "<").Replace("&gt;", ">")
                                        if (![string]::IsNullOrWhiteSpace($data)){
                                            #Write-Host $data -ForegroundColor Yellow
                                            try{
                                                $xmlObject = New-Object -TypeName System.Xml.XmlDocument
                                                $xmlObject.LoadXml($data)

                          
                                                #Write-Host $data
                                                #CHANGE 10/9
                                                if ($xmlObject.TableEditorDataSet){
                                                    #$noCols = $xmlObject.TableEditorDataSet.GridColumnSettings.Count

                                                    #Write-Host $xmlObject.TableEditorDataSet.GridColumnSettings.Count
                                                    #Write-Host $data
                                                    $pattern = '<xs:element\s+name="([^"]+)"[^>]*\sminOccurs="0"'
                                                    $matches = [regex]::Matches($data, $pattern)
                                                    $elementNames = $matches | ForEach-Object { $_.Groups[1].Value }
                                                    $colArraySettings = @()
                                                    if ($elementNames -eq $null){
                                                        Write-Host "Elements empty"
                                                        $noCols = 0
                                                        $tempCols = $xmlObject.TableEditorDataSet.GridColumnSettings.Count
                                                        Write-Host $tempCols
                                                        for($j = 1; $j -le $tempCols; $j++){
                                                            $col = "Column$($j)"
                                                            #Write-Host $col
                                                            if (!$colArraySettings.Contains($col)){
                                                                $colArraySettings += $col
                                                                $noCols++
                                                            }
                                                        }

                                                    } else {
                                                        $noCols = 0
                                                        foreach($col in $elementNames){
                                                            if (!$colArraySettings.Contains($col)){
                                                                $colArraySettings += $col
                                                                $noCols++
                                                            }
                                                        }
                                                    }

                                                    #Write-Host $elementNames
                                                    
                                                    #Write-Host "Elements: " $elementNames -ForegroundColor Cyan
                                                    #$xmlObject.TableEditorDataSet.GridData.SerializedData.NewDataSet.
                                                   
                                                }
                                                #CHANGE 10/9
                                            } catch {
                                                $hasTable = $false
                                                if ($data.Contains("TableEditorDataSet")){
                                                    $errorMessage += "`nError Reading XML: $($_.Exception.Message)"
                                                    Write-Host $errorMessage -ForegroundColor Red
                                                    updateErrorFound $kbriefID $errorMessage
                                                } else {
                                                    $errorMessage += "`nError Reading XML NOT A TABLE: $($_.Exception.Message)"
                                                    Write-Host $errorMessage -ForegroundColor White 
                                                }
                                            }
                                        }
                                        #ENDCHANGE 10/9
                       
                                        if ($noCols -gt 0){
                                            Write-Host "Is Table - Cols" $noCols -ForegroundColor Yellow

                                            $totalWidth = 0
                                            foreach($colw in $xmlObject.TableEditorDataSet.GridColumnSettings){
                                                $totalWidth += $colw.Width
                                            }
                                            Write-Host $totalWidth -ForegroundColor Yellow


                                            $strHTML = "<table style='border-collapse:collapse; width:100%; table-layout: fixed;'  cellpadding=5 cellspacing=0>"
                                            foreach($row in $xmlObject.TableEditorDataSet.GridData.SerializedData.NewDataSet.GridData){
                                            
                                                $gridContent = ""
                                                $arrContent = @()

                                                $imgblockpath = "$blockpath\Images"

                                                if ((Test-Path -Path $imgblockpath) -eq $false){
                                                    New-Item -Path $imgblockpath -ItemType Directory -Force | Out-Null
                                                }

                                                for($i = 0; $i -lt $noCols; $i++){
                                                    
                                                    #Write-Host $colArraySettings
                                                    $element = $colArraySettings[$i];
                                                    try{
                                                        if ($row.$element){
                                                            $gridContent = getHTMLVal $row.$element.ToString() $kbriefID $kbriefidsql $blockid $true $imgblockpath
                                                        }
                                                    } catch {
                                                    }

                                                    $hasImage = $false
                                                    try{
                                                        $img = $xmlObject.TableEditorDataSet.GridData.SerializedData.NewDataSet.CellImages[$rowCounter].$element
                                                        $hasImage = $true
                                                    } catch {
                                                        
                                                    }
                             
                                                    #Write-Host $img.Length $MINIMG -ForegroundColor Yellow
                                                    if ([string]::IsNullOrWhiteSpace($gridContent)){
                                                        $gridContent = "&nbsp;"
                                                    }
                                                    if ($hasImage -and $img.Length -gt $MINIMG){
                                                        #Write-Host "IN IMAGE FOR GRID, SEE IF WORKS" -ForegroundColor Cyan

                                                        $guid = New-Guid
                                                        $blockpathimg = "$imgblockpath\Images"
                                                        New-Item -Path $blockpathimg -ItemType Directory -Force | Out-Null
                                                        $outputPath = "$blockpathimg\$guid.jpg" # Specify your desired output path and filename
            
                                                        $bytes = [System.Convert]::FromBase64String($img)
                                                        # Write bytes to file
                                                        [System.IO.File]::WriteAllBytes($outputPath, $bytes)

                                                        $image = [System.Drawing.Image]::FromFile($($outputPath));
                                                        $filePath = [IO.Path]::ChangeExtension($outputPath, '.png');
                                                        $image.Save($filePath, [System.Drawing.Imaging.ImageFormat]::Png);
                                                        $image.Dispose();
                                                        Remove-Item -Path $outputPath -Force
                                                        $imageBytes = [System.IO.File]::ReadAllBytes($filePath)
                                                        $base64 = [Convert]::ToBase64String($imageBytes)

                                                        # Detect the file type (change this if needed)
                                                        $mimeType = "image/png"  # e.g. image/png, image/gif
                                                        #Remove-Item -Path $filePath -Force
                                                        
                                                        $imageSPPath = "data:$mimeType;base64,$base64"

                                                        #Write-Host $imageSPPath

                                                        if ($imageSPPath -ne ""){
                                                            #$attCol = $xmlObject.TableEditorDataSet.GridColumnSettings | Where-Object { $_.Column -eq $content.Col }
                                                            #$attRow = $xmlObject.TableEditorDataSet.GridRowSettings | Where-Object { $_.Row -eq $rowCounter }
                                                            
                                                            #$imgwidth = [math]::Round(($attCol.Width / $totalWidth) * 100, 0)
                                                            
                                                            #$gridContent = "<img src='$imageSPPath' width='$($attCol.Width)' height='$($attRow.Height)'>"
                                                            $gridContent = "<img src='$imageSPPath' width='100%'>"
                                                        }
                                                    }
                                                    $arrContent += [PSCustomObject]@{ Value = $gridContent; Col = $i; Row = $rowCounter}
                                                }

                                                $rowAtt = $xmlObject.TableEditorDataSet.GridRowSettings | Where-Object { $_.Row -eq $rowCounter }
                                                $rowStyle = "style='height: $($rowAtt.Height); vertical-align:top'"
                                                $strHTML += "<tr $($rowStyle)>"

                                                foreach($content in $arrContent){
                                                    $att = $xmlObject.TableEditorDataSet.GridCellSettings | Where-Object { $_.Row -eq $rowCounter -and $_.Column -eq $content.Col }
                                                    $bgColor = "rgb(" + $att.Background.ToString().Replace("|", ",") + ")"
                                                    $color = "rgb(" + $att.Foreground.ToString().Replace("|", ",") + ")"

                                                    $borderStyle = ""
                                                    if (![string]::IsNullOrWhiteSpace($att.LeftBorderStyle.ToString())){
                                                        $borderStyle = "border-left: 1px solid black;"
                                                    }
                                                    if (![string]::IsNullOrWhiteSpace($att.RightBorderStyle.ToString())){
                                                        $borderStyle += "border-right: 1px solid black;"
                                                    }
                                                    if (![string]::IsNullOrWhiteSpace($att.TopBorderStyle.ToString())){
                                                        $borderStyle += "border-top: 1px solid black;"
                                                    }
                                                    if (![string]::IsNullOrWhiteSpace($att.BottomBorderStyle.ToString())){
                                                        $borderStyle += "border-bottom: 1px solid black;"
                                                    }

                                                    $hdCSS = ""
                                                    if ($rowCounter -eq 0){
                                                        $att = $xmlObject.TableEditorDataSet.GridColumnSettings | Where-Object { $_.Column -eq $content.Col }
                                                        $width = $att.width
                                                        If ($width -gt 0){
                                                            $width = [math]::Round(($width / $totalWidth) * 100, 0)
                                                        }
                                                        $style = "style='background-color:$bgColor; color: $color; width: $($width)%"

                                                        #Write-Host $style -ForegroundColor Yellow
               
                                                    } else {
                                                        $style = "style='background-color:$bgColor; color: $color"
                                                    }
                                                    $borderStyle = "border: 1px solid black;"
                                                    if ($borderStyle  -ne ""){
                                                        $style += ";$($borderStyle)"
                                                    }
                                                    $style += "'"
                                                    $strHTML += "<td $($style)>" + $content.Value + "</td>"
                                                }
                                                $strHTML += "</tr>"
        
                                                $rowCounter++
                                            }
                                            $strHTML += "</table>"

                                            #Write-Host $strHTML

                                            #Set-Content -Value $strHTML -Path "H:\TCCReplacement\HTML.html"
                                            $hasTable = $true
                                        }
                                    }
                                }
                                if ($hasTable){
                                    #Write-Host "Parsed Table XML" -ForegroundColor Green
                                    $parsedString += "<div style='width:99%;text-align: center'>$($strHTML)</div>"
                                } else {
                                    #Write-Host "Has No Table" -ForegroundColor Green
                                    if ($hasAttachment){
                                        $parsedString += "<div style='width:99%;text-align: center'><a href='$attachmentSPPath' target='_blank'><img style='max-width:300px; width:auto; object-fit: cover' src='$imageSPPath'></a></div>"
                                    } else {
                                        $parsedString += "<div style='width:99%;text-align: center'><img style='max-width:300px; width:auto; object-fit: cover' src='$imageSPPath'></div>"
                                    }
                                }
                                #Write-Host $parsedString
                            }
                        }

                        #Replace Links
                        $parsedString = $parsedString.Replace($urlTextToReplace, $powerAppURL)

                        if ($strCompHTML -ne ""){
                            $parsedString = $parsedString + "<p>" + $strCompHTML + "</p>"
                        }


                        $canCreateBlock = $true
                        if ($headers -ne ""){
                            if ($headers.Contains($blockHeading)){
                                $canCreateBlock = $false
                                Write-Host "Block FOund in DOCX"
                            }
                        }
                        
                        if ($blockcreated -eq $false -and $canCreateBlock){
                            $blocktype = $blockTypeArray | Where-Object { $_.ID -eq $block.block_type_id }
                            #$blocktype = getBlockType $block.block_type_id
                            $SPID = 0
                            if ($kbriefblock -ne $null){
                                $SPID = $kbriefblock["ID"]
                            }
                            $blocktype = $blockTypeArray | Where-Object { $_.ID -eq $block.block_type_id }
                            $kbriefblockobj = [PSCustomObject]@{
                                Title = $blockHeading
                                ParentID = $kbriefID
                                KBrief = $kbriefID
                                BlockTypeID = $blocktype.ID
                                BlockType = $blocktype.Title
                                Explanation = $parsedString
                                Sequence = $sequence
                                TCC_ExplanationText = $block.explanation_text
                                TCC_Explanation = $block.explanation
                                TCC_BlockTypeID = $block.block_type_id
                                TCC_Sequence = $block.sequence
                                TCC_KBriefBlockID = $block.kbrief_block_id
                                Hidden = $hidden
                                Created = $created
                                LinkedKBriefID = $linkedid
                                LinkedKBriefBlockID = $linkedblockid
                                HasBulletedList = $hasBulletedList
                                Source = 0
                                XMLData = $data
                                SPID = $SPID
                            }
                            $blockArray+= $kbriefblockobj 
                            $blockmainadded = $true
                        } else {
                            $sequence--
                        }

                    } else {
                        Write-Host "Block Already Processed"
                    }
               
                }
            }
        }

        #Write-Host ($blockArray | ConvertTo-Json)

        $blockItemsSQL = $blockArray | Where-Object { $_.Source -eq 0 }
        $blockItemsHTML = $blockArray | Where-Object { $_.Source -eq 1 }

        $newData = @()
        $newArray = @()
        #MERGE BLANK OBJECTS TO PREVIOUS IF TITLE BLANK
        if ($blockItemsSQL -and $blockItemsHTML){
            $newData = Merge-BlankObjects -InputArray $blockItemsSQL
            foreach ($d in $newData){
                $newArray += $d
            }
            #$newData | Format-Table
            #REMOVE ITEMS WHERE TITLES MATCH - STOPS DUPS BETWEEN WORD DOCUMENT AND BLOCKS
            if ($blockItemsHTML -ne $null -and $newData -ne $null){
                $result = Remove-ByTitle -SourceArray $blockItemsHTML -ExcludeArray $newData
            }
            foreach ($r in $result){
                $newArray += $r
            }
        } else {
            $blockItemsHTML| Format-Table
            if ($blockItemsHTML){
                $newArray = $blockItemsHTML
            }
            if ($blockItemsSQL){
                $newArray = $blockItemsSQL
            }
        }
        $counter = 0
        foreach ($blockitem in $newArray){
            $counter++
            
            $blockbody = $blockitem.Explanation
            if (![string]::IsNullOrWhiteSpace($blockbody)){
                $blockbody = $blockbody.Replace($urlTextToReplace, $powerAppURL)
                $blockbody = $blockbody.Replace($urlTextToReplace2, $powerAppURL)
                $blockbody = $blockbody.Replace($urlTextToReplace3, $urlTextToReplace3a)
            }

            $blockbodyHTML = cleanString $blockbody 
            $kbriefhtml += $blockbodyHTML
            $kbriefblockobj = @{
                "Title" = $blockitem.Title 
                "ParentID" = $blockitem.ParentID 
                "KBrief" = $blockitem.ParentID 
                "BlockTypeID" = $blockitem.BlockTypeID 
                "BlockType" = cleanString $blockitem.BlockType 
                "Explanation" = $blockbodyHTML
                "Sequence" = $counter
                #"TCC_ExplanationText" = cleanString $blockitem.TCC_ExplanationText 
                #"TCC_Explanation" = cleanString $blockitem.TCC_Explanation 
                "TCC_BlockTypeID" = $blockitem.TCC_BlockTypeID 
                "TCC_Sequence" = $blockitem.TCC_Sequence 
                "TCC_KBriefBlockID" = $blockitem.TCC_KBriefBlockID 
                "Hidden" = $blockitem.Hidden 
                "Created" = $blockitem.Created 
                "LinkedKBriefID" = $blockitem.LinkedKBriefID 
                "LinkedKBriefBlockID" = $blockitem.LinkedKBriefBlockID 
                "HasBulletedList" = $blockitem.HasBulletedList
                "ParentTCC_ID" = $kbriefidsql
                "HTMLOnly" = $true
                "DefaultSectionType" = 1
                "HiddenA3" = $false

            }
            if (!$blocktypesused.Contains($blockitem.BlockType)){
                $blocktypesused += $blockitem.BlockType + ";"
            }
            try{
                #Write-Host ($kbriefblockobj | ConvertTo-JSON)
                if ($blockitem.SPID -eq 0){
                    Write-Host "$counter - Add KBrief Block " $blockitem.Title  -ForegroundColor Magenta
                    try{
                        $output = Add-PnPListItem -List $listKBriefBlock -Values $kbriefblockobj -Connection $connection #-Batch $batch
                    } catch {
                        Write-Host "Size to Large Try and Parse"
                        $blockbodyHTML = Save-HtmlImagesAndRewrite $blockbodyHTML $kbriefID
                        $kbriefblockobj = @{
                            "Title" = $blockitem.Title 
                            "ParentID" = $blockitem.ParentID 
                            "KBrief" = $blockitem.ParentID 
                            "BlockTypeID" = $blockitem.BlockTypeID 
                            "BlockType" = cleanString $blockitem.BlockType 
                            "Explanation" = $blockbodyHTML
                            "Sequence" = $counter
                            #"TCC_ExplanationText" = cleanString $blockitem.TCC_ExplanationText 
                            #"TCC_Explanation" = cleanString $blockitem.TCC_Explanation 
                            "TCC_BlockTypeID" = $blockitem.TCC_BlockTypeID 
                            "TCC_Sequence" = $blockitem.TCC_Sequence 
                            "TCC_KBriefBlockID" = $blockitem.TCC_KBriefBlockID 
                            "Hidden" = $blockitem.Hidden 
                            "Created" = $blockitem.Created 
                            "LinkedKBriefID" = $blockitem.LinkedKBriefID 
                            "LinkedKBriefBlockID" = $blockitem.LinkedKBriefBlockID 
                            "HasBulletedList" = $blockitem.HasBulletedList
                            "ParentTCC_ID" = $kbriefidsql
                            "HTMLOnly" = $true
                            "DefaultSectionType" = 1
                            "HiddenA3" = $false

                        }
                        $output = Add-PnPListItem -List $listKBriefBlock -Values $kbriefblockobj -Connection $connection #-Batch $batch
                    }
                    if($output -ne $null){
                        $kbriefblocksectionobj = @{
                            "Title" = $blockitem.Title 
                            "ParentID" = $output["ID"]
                            "Parent" = $output["ID"]
                            "KBriefID" = $blockitem.ParentID 
                            "KBrief" = $blockitem.ParentID 
                            "SectionHTML" = $blockbodyHTML
                            "SectionType" = 1
                            "SectionTypeID" = 1
                            "Order" = 0
                            "Hidden" = $false
                        }
                        try{
                            $output = Add-PnPListItem -List $listKBriefBlockSections -Values $kbriefblocksectionobj -Connection $connection #-Batch $batch
                        } catch {
                        }
                    }

                } else {
                    Write-Host "$counter - Update KBrief Block " -ForegroundColor Magenta
                    $output = Set-PnPListItem -Identity $blockitem.SPID  -List $listKBriefBlock -Values $kbriefblockobj -Connection $connection -UpdateType SystemUpdate #-Batch $batch
                    if($output -ne $null){
                        #NEED TO CHECK IF SECTION EXISTS
                        $kbriefsection = checkKBriefBlockSectionExists $kbriefID $blockitem.SPID #CHECK THIS IS CORRECT
                        $kbriefblocksectionobj = @{
                            "Title" = $blockitem.Title 
                            "ParentID" = $output["ID"]
                            "Parent" = $output["ID"]
                            "KBriefID" = $blockitem.ParentID 
                            "KBrief" = $blockitem.ParentID 
                            "SectionHTML" = $blockbodyHTML
                            "SectionType" = 1
                            "SectionTypeID" = 1
                            "Order" = 0
                            "Hidden" = $false
                        }
                        try{
                            if ($kbriefsection -ne $null){
                                $output = Set-PnPListItem -List $listKBriefBlockSections -Identity $kbriefsection["ID"] -Values $kbriefblocksectionobj -Connection $connection #-Batch $batch
                            } else {
                                $output = Add-PnPListItem -List $listKBriefBlockSections -Values $kbriefblocksectionobj -Connection $connection #-Batch $batch
                            }
                            
                        } catch {
                        }
                    }

                    if ($blockitem.XMLData -ne $null -and $blockitem.XMLData -ne ""){
                        try{
                            $kbriefblockobj = @{
                                "XMLData" = $blockitem.XMLData
                            }
                            $output = Set-PnPListItem -Identity $output["ID"]  -List $listKBriefBlock -Values $kbriefblockobj -Connection $connection -UpdateType SystemUpdate # -Batch $batch
                        } catch {}
                    }
                }

            } catch {
                $errorMessage += "Error in block add/update: $($_.Exception.Message)"
                Write-Host $errorMessage -ForegroundColor Red
                updateErrorFound $kbriefID $errorMessage
            }
        }
        if (Test-Path -Path $downloadPath){
            if ($REMOVEFILES){
                try{
                    Remove-Item -Path $downloadPath -Force -Recurse -ErrorAction Stop
                } catch {
                    Write-Host "Error Removing, pause" -ForegroundColor Magenta
                    Start-Sleep -Seconds 30
                    Remove-Item -Path $downloadPath -Force -Recurse 
                }
            }
        }

        if ($continue){
            $dtProcessed = Get-Date
            $blocktypesused = $blocktypesused.TrimEnd(";")
            $values = @{
                "Block_BlockTypesUsed" = $blocktypesused
                "Processed" = $true
                "Blocks" = $sequence
                "ProcessedDate" = $dtProcessed
                "SectionsFormat" = $true
                "HTML" = $kbriefhtml
            }
            Write-Host $blocktypesused -ForegroundColor Cyan
            $output = Set-PnPListItem -Identity $kbriefID -List $listKBrief -Values $values -Connection $connection -UpdateType SystemUpdate

            $dtEndTime = Get-Date
            $timeDifference = New-TimeSpan -Start $dtStartTime -End $dtEndTime

            Write-Host "Processing Time" $timeDifference.Seconds "seconds" -ForegroundColor Green
        }
    }
}
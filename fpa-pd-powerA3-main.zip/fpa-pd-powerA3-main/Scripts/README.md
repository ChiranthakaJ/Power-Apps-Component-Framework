# PowerA3 Scripts

PowerShell scripts for migrating data from the legacy TCC SQL database into SharePoint / Power Apps, and for processing Windchill design documents.

---

## Prerequisites

- **PowerShell 7+**
- **PnP.PowerShell** module: `Install-Module PnP.PowerShell`
- **SqlServer** module: `Install-Module SqlServer`
- **RtfPipe.dll** placed in `Migration/` (not in source control — obtain from the project team)
- A valid **PnP certificate** (`.pfx`) registered against the Azure App Registration

---

## Configuration Setup

> ⚠️ Never commit real credentials. The `config.ps1` file is excluded from source control.

1. Copy the template:
   ```powershell
   Copy-Item Scripts\config.example.ps1 Scripts\config.ps1
   ```
2. Edit `Scripts\config.ps1` and fill in all values:
   | Variable | Description |
   |---|---|
   | `$serverInstance` | SQL Server hostname (e.g. `Aklvptcc01`) |
   | `$databaseName` | TCC SQL database name |
   | `$sqlUserName` | SQL login username |
   | `$sqlpassword` | SQL login password |
   | `$clientID` | Azure AD App Registration Client ID |
   | `$thumbprint` | Certificate thumbprint for PnP auth |
   | `$CertPath` | Full local path to the `.pfx` certificate file |
   | `$CertPassword` | Certificate password |
   | `$environment` | Target environment: `DEV`, `UAT`, or `PROD` |
   | `$baseAttachmentPath` | UNC path to the SQL file attachments share |
   | `$NETWORKPATH` | UNC path to the TCC file store |

3. Place the `TCCReplacement.pfx` certificate locally at the path set in `$CertPath`.

---

## Certificate / Azure App Setup

The scripts authenticate to SharePoint using a certificate-based App Registration:

- **Tenant**: `fisherpaykel.onmicrosoft.com`
- **App Registration Client ID**: stored in `config.ps1`
- The certificate `.pfx` must be uploaded to the App Registration in Azure Portal
- To test the connection, run:
  ```powershell
  .\Scripts\Certificates\TestConnection.ps1
  ```

---

## Scripts

### Migration/

Migrates K-Brief items from the legacy TCC SQL database into SharePoint lists.

| Script | Purpose |
|---|---|
| `ConnectSQLAttachments.ps1` | Main migration runner — processes a batch range of K-Briefs from SQL |
| `ConnectSQLAttachmentsV1.ps1` | Earlier version of the main runner |
| `ConnectSQLAttachmentsExistingSP.ps1` | Reprocesses K-Briefs that already exist in SharePoint (by TCC_ID) |
| `ConnectSQLAttachmentsReprocessSP.ps1` | Reprocesses items queued in the `Process` SharePoint list |
| `ExtractTCCItems.ps1` | Extracts and copies TCC file attachments from the SQL file share |
| `Functions.ps1` | Shared library — loaded by all migration runners. Also handles SharePoint connection setup |
| `ProcessKBriefs.ps1` | Core processing logic called by the migration runners |
| `RtfPipe.dll` | Binary dependency for RTF→HTML conversion (not in source control) |

**To run a migration batch:**
```powershell
# Edit STARTCOUNTER and ENDCOUNTER in ConnectSQLAttachments.ps1 first
.\Scripts\Migration\ConnectSQLAttachments.ps1
```

### DesignStandardisation/

Processes Windchill `.docx` files, replaces legacy `DOCPROPERTY` field codes with SharePoint Quick Parts content controls, then uploads to the SharePoint `Document Management` library.

| Script | Purpose |
|---|---|
| `MigrateWindchillDocuments.ps1` | Processes all `.docx` files in `WindchillDocuments/` and uploads to SharePoint |
| `WindchillDocuments/` | Source `.docx` files to be migrated (place files here before running) |

**To run:**
```powershell
.\Scripts\DesignStandardisation\MigrateWindchillDocuments.ps1
```

---

## PCF Controls

See [PCF/](../PCF/) for the Power Apps Component Framework controls included in this project:

| Control | Description |
|---|---|
| `TCCA3View` | A3 card view with rich text editing, AI assistant, drag-and-drop |
| `TCCTreeView` | Hierarchical tree selector |
| `TCCHTMLControl` | HTML viewer with zoom/pan |
| `AnnotateAnImage` | Image annotation with marker.js |

**To build a PCF control:**
```powershell
cd PCF\TCCA3View
npm install
npm run build
```

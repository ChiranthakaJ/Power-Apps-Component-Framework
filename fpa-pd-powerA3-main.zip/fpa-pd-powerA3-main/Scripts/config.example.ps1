# =============================================================================
# CONFIGURATION TEMPLATE
# Copy this file to config.ps1 and fill in the real values.
# config.ps1 is excluded from source control (.gitignore).
# NEVER commit config.ps1 or any file containing real credentials.
# =============================================================================

# -------------------------------------
# SQL Server (Legacy TCC Database)
# -------------------------------------
$serverInstance  = "YOUR_SQL_SERVER_INSTANCE"    # e.g. Aklvptcc01
$databaseName    = "YOUR_DATABASE_NAME"          # e.g. tcc_sbtdb
$sqlUserName     = "YOUR_SQL_USERNAME"
$sqlpassword     = "YOUR_SQL_PASSWORD"

# -------------------------------------
# SharePoint / PnP Online
# -------------------------------------
$tenantName      = "YOUR_TENANT.onmicrosoft.com" # e.g. fisherpaykel.onmicrosoft.com
$clientID        = "YOUR_AZURE_APP_CLIENT_ID"    # Azure AD App Registration Client ID
$thumbprint      = "YOUR_CERT_THUMBPRINT"        # Certificate thumbprint (alternative to cert path)

# Certificate-based auth (preferred for unattended runs)
$CertPath        = "C:\Path\To\TCCReplacement.pfx"
$CertPassword    = "YOUR_CERT_PASSWORD"

# -------------------------------------
# SharePoint Site Environment
# Set to "DEV", "UAT", or "PROD"
# -------------------------------------
$environment     = "DEV"

# -------------------------------------
# File Paths
# -------------------------------------
$baseAttachmentPath = "\\YOUR_SERVER\SetBaseFiles\FileTable\Attachments\"
$NETWORKPATH        = "\\YOUR_SERVER\TCCReplacement\TCCFiles"

# -------------------------------------
# SharePoint List Names (rarely change)
# -------------------------------------
$listKBrief             = "KBrief"
$listProcess            = "Process"
$listKBriefBlock        = "KBrief_Blocks"
$listKBriefBlockSections = "KBrief_Blocks_Sections"
$listKBriefBlockType    = "Block_Type"
$listKBriefLookUpList   = "LookUpList"
$libraryImages          = "Block Images"
$libraryAttachments     = "App Attachments"
